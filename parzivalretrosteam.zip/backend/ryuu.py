"""Integração com o repositório Ryuu Fixes (generator.ryuu.lol/files/fixes.json).
Sem autenticação, sem login — JSON público com links diretos de download.
"""

from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional

from http_client import get_client
from logger import logger

RYUU_JSON_URL = "https://generator.ryuu.lol/files/fixes.json"

# Cache em memória
_cache: Optional[List[Dict[str, Any]]] = None
_cache_time: float = 0
_CACHE_TTL = 300  # 5 minutos


def _load() -> List[Dict[str, Any]]:
    global _cache, _cache_time
    now = time.time()
    if _cache is not None and (now - _cache_time) < _CACHE_TTL:
        return _cache
    try:
        client = get_client()
        resp = client.get(RYUU_JSON_URL, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            if isinstance(data, list):
                _cache = data
                _cache_time = now
                logger.log(f"RyuuFix: JSON carregado — {len(data)} jogos")
                return _cache
    except Exception as e:
        logger.warn(f"RyuuFix: falha ao carregar JSON: {e}")
    return _cache or []


def _fix_source(f: Dict[str, Any]) -> str:
    name = f.get("filename", "").lower()
    if "voices38"    in name: return "voices38"
    if "hypervision" in name: return "hypervision"
    return "other"


# Ordem de prioridade: voices38 → Online → Tested → Bypass → hypervision → resto
def _sort_fixes(fixes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    def rank(f):
        src    = _fix_source(f)
        badges = f.get("badges", [])
        if src == "voices38":    return 0
        if "Online"  in badges: return 1
        if "Tested"  in badges: return 2
        if "Bypass"  in badges: return 3
        if src == "hypervision": return 5
        return 4  # sem badge e não é hypervision
    return sorted(fixes, key=rank)


def find_by_appid(appid: int) -> Optional[Dict[str, Any]]:
    """Retorna a entrada do jogo pelo AppID, ou None se não existir."""
    sid = str(appid)
    for entry in _load():
        if str(entry.get("appid", "")) == sid:
            return entry
    return None


def check(appid: int) -> Dict[str, Any]:
    """Verifica se existe fix Ryuu para o appid.
    Retorna a lista ordenada por prioridade para o usuário escolher.
    O primeiro da lista é o recomendado.
    """
    entry = find_by_appid(appid)
    if not entry or not entry.get("fixes"):
        return {"available": False}

    sorted_fixes = _sort_fixes(entry["fixes"])
    best = sorted_fixes[0]
    has_voices38 = _fix_source(best) == "voices38"

    # Enriquece cada fix com metadados úteis para o frontend
    enriched = []
    for i, f in enumerate(sorted_fixes):
        src = _fix_source(f)
        enriched.append({
            "href":        f["href"],
            "filename":    f.get("filename", ""),
            "size":        f.get("size", ""),
            "badges":      f.get("badges", []),
            "extra_steps": f.get("extra_steps", ""),
            "source":      src,
            "recommended": i == 0,
            "label":       "voices38" if src == "voices38" else
                           "Hypervision" if src == "hypervision" else
                           f.get("filename", f"Fix {i+1}"),
        })

    return {
        "available":    True,
        "name":         entry.get("name", ""),
        "fixes":        enriched,
        # Atalhos do melhor fix (compatibilidade com código que usa fix único)
        "url":          best["href"],
        "filename":     best.get("filename", ""),
        "size":         best.get("size", ""),
        "badges":       best.get("badges", []),
        "extra_steps":  best.get("extra_steps", ""),
        "source":       _fix_source(best),
        "has_voices38": has_voices38,
    }
