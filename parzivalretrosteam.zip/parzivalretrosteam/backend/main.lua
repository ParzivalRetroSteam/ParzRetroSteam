-- main.lua — Parzival Retrô Steam
-- Backend Lua para Millennium 2.29+ (sem Python)

local cjson       = require("json")
local m_utils     = require("utils")
local logger      = require("plugin_logger")
local millennium  = require("millennium")
local fs          = require("fs")
local paths       = require("paths")
local steam_utils = require("steam_utils")
local utils       = require("plugin_utils")
local downloads   = require("downloads")
local fixes       = require("fixes")
local config      = require("config")
local http_client = require("http_client")

-- ── JSON helpers ──────────────────────────────────────────────────────────────
local function json_ok(data)
    local ok, s = pcall(cjson.encode, data)
    if ok then return s end
    return '{"success":false,"error":"serialization error"}'
end

local function json_err(msg)
    return json_ok({success=false, error=tostring(msg)})
end

-- ── Webkit (copia JS para steamui/) ──────────────────────────────────────────
local function copy_webkit_files()
    local steam_dir = steam_utils.detect_steam_install_path()
    if not steam_dir or steam_dir == "" then return end
    local webkit_dir = fs.join(steam_dir, "steamui", "webkit")
    if not fs.exists(webkit_dir) then fs.create_directories(webkit_dir) end
    local public_dir = fs.join(paths.get_plugin_dir(), "public")
    local function cp(src_name, dst_name)
        local src = fs.join(public_dir, src_name)
        local dst = fs.join(webkit_dir, dst_name or src_name)
        if fs.exists(src) then
            local content = m_utils.read_file(src)
            if content then m_utils.write_file(dst, content) end
        end
    end
    cp("gamefixer.js")
end

local function inject_webkit_files()
    millennium.add_browser_js("webkit/gamefixer.js")
end

-- ── Lifecycle ─────────────────────────────────────────────────────────────────
local function on_load()
    logger.log(config.PLUGIN_NAME .. " v" .. config.PLUGIN_VERSION .. ": iniciando...")
    steam_utils.detect_steam_install_path()
    utils.ensure_temp_download_dir()
    local data_dir = paths.backend_path("data")
    if not fs.exists(data_dir) then fs.create_directories(data_dir) end
    copy_webkit_files()
    inject_webkit_files()
    millennium.ready()
end

local function on_unload()
    logger.log(config.PLUGIN_NAME .. ": descarregando.")
end

local function on_frontend_loaded()
    logger.log(config.PLUGIN_NAME .. ": frontend carregado.")
    copy_webkit_files()
    pcall(downloads.process_download_queue)
end

-- ── Logger (chamado como "Logger.log" pelo JS) ────────────────────────────────
Logger = {}
function Logger.log(msg)
    local m = type(msg) == "table" and tostring(msg.message or "") or tostring(msg or "")
    logger.log("[Frontend] " .. m)
    return json_ok({success=true})
end
function Logger.warn(msg)
    local m = type(msg) == "table" and tostring(msg.message or "") or tostring(msg or "")
    logger.warn("[Frontend] " .. m)
    return json_ok({success=true})
end
_G["Logger.log"]  = Logger.log
_G["Logger.warn"] = Logger.warn

-- ── API exports ───────────────────────────────────────────────────────────────

-- Downloads
function StartDownload(appid, game_name)
    if type(appid) == "table" then game_name = appid.game_name; appid = appid.appid end
    local ok, res = pcall(downloads.start_download, tonumber(appid), tostring(game_name or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetDownloadStatus(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.get_add_status, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function CancelDownload(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.cancel_download, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetApiList()
    local ok, res = pcall(downloads.get_api_list)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function StartDownloadFromUrl(apiName, appid, contentScriptQuery, url)
    -- Millennium ordena args por chave alfabética: apiName, appid, contentScriptQuery, url
    local ok, res = pcall(downloads.start_download_from_url, tonumber(appid), tostring(url or ""), tostring(apiName or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function CheckApisForApp(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.check_apis_for_app, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function HasLuaForApp(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, exists = pcall(steam_utils.has_lua_for_app, tonumber(appid))
    if not ok then return json_err(exists) end
    return json_ok({success=true, exists=exists==true})
end

function DeleteLuaForApp(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.delete_lua_for_app, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function QueueDownloadAfterRestart(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.queue_download_after_restart, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function CancelQueueDownload(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.cancel_queue_download, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

-- Fixes
function CheckFixes(appid, game_name)
    if type(appid) == "table" then game_name = appid.game_name; appid = appid.appid end
    local ok, res = pcall(fixes.check_for_fixes, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function ApplyFix(appid, contentScriptQuery, downloadUrl, fixType, gameName, installPath)
    -- Millennium ordena por chave: appid, contentScriptQuery, downloadUrl, fixType, gameName, installPath
    local ok, res = pcall(fixes.apply_game_fix,
        tonumber(appid), tostring(downloadUrl or ""),
        tostring(installPath or ""), tostring(fixType or ""), tostring(gameName or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetFixStatus(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(fixes.get_apply_status, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function CancelFix(appid)
    return json_ok({success=true})
end

function DetectDrm(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(fixes.detect_drm, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

-- Steam utils
function GetGameInstallPath(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(steam_utils.get_game_install_path_response, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function RestartSteam()
    local script = paths.backend_path("restart_steam.cmd")
    if not fs.exists(script) then return json_err("restart_steam.cmd não encontrado") end
    pcall(m_utils.exec, 'cmd /C "' .. script .. '"')
    return json_ok({success=true})
end

function GetPluginInfo()
    return json_ok({name=config.PLUGIN_NAME, version=config.PLUGIN_VERSION})
end

-- Loaded apps
function ReadLoadedApps()
    local path = paths.backend_path(config.LOADED_APPS_FILE)
    local apps = {}
    if fs.exists(path) then
        local text = m_utils.read_file(path) or ""
        for line in text:gmatch("[^\r\n]+") do
            local appid = tonumber(line:match("^%s*(%d+)%s*$"))
            if appid then table.insert(apps, appid) end
        end
    end
    return json_ok({success=true, apps=apps})
end

function DismissLoadedApps()
    local path = paths.backend_path(config.LOADED_APPS_FILE)
    if fs.exists(path) then m_utils.write_file(path, "") end
    return json_ok({success=true})
end

-- Atualizar servidores
function FetchFreeApisNow()
    local ok, resp = pcall(http_client.get, config.API_MANIFEST_URL, {timeout=15})
    if not ok or not resp or resp.status ~= 200 then
        ok, resp = pcall(http_client.get, config.API_MANIFEST_PROXY, {timeout=20})
    end
    if not ok or not resp or resp.status ~= 200 then
        return json_err("Falha ao buscar servidores")
    end
    local content = resp.body or ""
    if content == "" then return json_err("Manifesto vazio") end
    m_utils.write_file(paths.backend_path(config.API_JSON_FILE), content)
    local ok_p, data = pcall(cjson.decode, content)
    local count = ok_p and data and #(data.api_list or {}) or 0
    return json_ok({success=true, count=count})
end

-- ── Return lifecycle ──────────────────────────────────────────────────────────
return {
    on_load            = on_load,
    on_unload          = on_unload,
    on_frontend_loaded = on_frontend_loaded,
}
