// GameFixer — Frontend Plugin v1.0
// Layout: abas inferiores (Adicionar / Corrigir / Gerenciar / Config)

(function () {
    'use strict';

    const WEBKIT_DIR_NAME = 'ParzivalRetroSteam';
    const PLUGIN_NAME    = 'Parzival Retrô Steam';
    const PLUGIN_VERSION = '1.0';

    // ── Post-restart: popup de jogos adicionados ──
    function showLoadedAppsPopup(apps) {
        if (document.querySelector('.gf-lap-wrap')) return;

        // ── Estilos do drawer ────────────────────────────────────────────────
        var st = document.createElement('style');
        st.textContent = [
            '@keyframes gf-slide-in{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}',
            '@keyframes gf-slide-out{from{transform:translateX(0);opacity:1}to{transform:translateX(100%);opacity:0}}',
            '@keyframes gf-fade-bg{from{opacity:0}to{opacity:1}}',
            '.gf-lap-wrap{position:fixed;inset:0;z-index:99998;display:flex;justify-content:flex-end;}',
            '.gf-lap-bg{position:absolute;inset:0;background:rgba(0,0,0,.55);backdrop-filter:blur(6px);animation:gf-fade-bg .25s ease;}',
            '.gf-lap-drawer{position:relative;z-index:1;width:360px;height:100vh;background:#111;',
            '  border-left:1px solid rgba(255,255,255,.08);display:flex;flex-direction:column;',
            '  animation:gf-slide-in .3s cubic-bezier(.16,1,.3,1);}',
            '.gf-lap-stripe{height:3px;background:linear-gradient(90deg,#dc0000,#ff4444,#dc0000);background-size:200% 100%;',
            '  animation:shimmer 2s linear infinite;}',
            '@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}',
            '.gf-lap-head{padding:22px 20px 18px;flex-shrink:0;}',
            '.gf-lap-badge{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:20px;',
            '  background:rgba(220,0,0,.15);border:1px solid rgba(220,0,0,.3);margin-bottom:12px;}',
            '.gf-lap-badge span{font-size:9px;font-weight:800;letter-spacing:2.5px;color:#dc0000;text-transform:uppercase;}',
            '.gf-lap-title{font-size:22px;font-weight:900;color:#fff;line-height:1.2;margin-bottom:4px;',
            '  background:linear-gradient(135deg,#fff 60%,rgba(255,255,255,.4));-webkit-background-clip:text;',
            '  -webkit-text-fill-color:transparent;background-clip:text;}',
            '.gf-lap-sub{font-size:11px;color:rgba(255,255,255,.3);line-height:1.5;}',
            '.gf-lap-body{flex:1;overflow-y:auto;padding:4px 16px 16px;}',
            '.gf-lap-body::-webkit-scrollbar{width:3px;}',
            '.gf-lap-body::-webkit-scrollbar-track{background:transparent;}',
            '.gf-lap-body::-webkit-scrollbar-thumb{background:rgba(220,0,0,.4);border-radius:3px;}',
            '.gf-lap-item{display:flex;align-items:center;gap:12px;padding:12px 14px;margin-bottom:6px;',
            '  border-radius:10px;border:1px solid rgba(255,255,255,.05);background:rgba(255,255,255,.02);',
            '  cursor:pointer;transition:all .15s;position:relative;overflow:hidden;}',
            '.gf-lap-item::before{content:"";position:absolute;left:0;top:0;bottom:0;width:2px;',
            '  background:linear-gradient(to bottom,#dc0000,transparent);opacity:0;transition:opacity .15s;}',
            '.gf-lap-item:hover{background:rgba(220,0,0,.07);border-color:rgba(220,0,0,.2);transform:translateX(-2px);}',
            '.gf-lap-item:hover::before{opacity:1;}',
            '.gf-lap-num{width:28px;height:28px;border-radius:50%;background:rgba(220,0,0,.12);border:1px solid rgba(220,0,0,.2);',
            '  display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:11px;font-weight:800;color:rgba(220,0,0,.7);}',
            '.gf-lap-info{flex:1;min-width:0;}',
            '.gf-lap-name{font-size:13px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
            '.gf-lap-appid{font-size:9px;color:rgba(255,255,255,.22);margin-top:2px;letter-spacing:.5px;}',
            '.gf-lap-dl{font-size:18px;color:rgba(220,0,0,.5);transition:all .15s;}',
            '.gf-lap-item:hover .gf-lap-dl{color:rgba(220,0,0,.9);transform:translateX(-2px);}',
            '.gf-lap-foot{padding:14px 16px 18px;flex-shrink:0;border-top:1px solid rgba(255,255,255,.05);}',
            '.gf-lap-dismiss{width:100%;padding:12px;border-radius:8px;background:transparent;border:1px solid rgba(255,255,255,.1);',
            '  color:rgba(255,255,255,.35);font-size:10px;font-weight:800;letter-spacing:1.5px;',
            '  text-transform:uppercase;cursor:pointer;transition:all .15s;}',
            '.gf-lap-dismiss:hover{background:rgba(255,255,255,.06);color:rgba(255,255,255,.6);border-color:rgba(255,255,255,.2);}'
        ].join('\n');
        document.head.appendChild(st);

        // ── Estrutura ────────────────────────────────────────────────────────
        var wrap = document.createElement('div'); wrap.className = 'gf-lap-wrap';
        var bg   = document.createElement('div'); bg.className   = 'gf-lap-bg';
        var drw  = document.createElement('div'); drw.className  = 'gf-lap-drawer';

        // Fechar ao clicar no fundo
        bg.onclick = function () { closeDrawer(); };

        function closeDrawer() {
            drw.style.animation = 'gf-slide-out .25s cubic-bezier(.16,1,.3,1) forwards';
            setTimeout(function () { wrap.remove(); st.remove(); }, 260);
        }

        // Stripe decorativa no topo
        var stripe = document.createElement('div'); stripe.className = 'gf-lap-stripe';

        // Header
        var head = document.createElement('div'); head.className = 'gf-lap-head';
        var badge = document.createElement('div'); badge.className = 'gf-lap-badge';
        badge.innerHTML = '<span>🎮 ' + PLUGIN_NAME + '</span>';
        var title = document.createElement('div'); title.className = 'gf-lap-title';
        title.textContent = apps.length === 1 ? 'Jogo pronto para baixar' : apps.length + ' jogos prontos';
        var sub = document.createElement('div'); sub.className = 'gf-lap-sub';
        sub.textContent = 'Clique no jogo para iniciar o download na Steam';
        head.appendChild(badge); head.appendChild(title); head.appendChild(sub);

        // Body — lista de jogos
        var body = document.createElement('div'); body.className = 'gf-lap-body';
        apps.forEach(function (item, idx) {
            var row = document.createElement('div'); row.className = 'gf-lap-item';
            var num = document.createElement('div'); num.className = 'gf-lap-num';
            num.textContent = idx + 1;
            var info = document.createElement('div'); info.className = 'gf-lap-info';
            var name = document.createElement('div'); name.className = 'gf-lap-name';
            name.textContent = item.name || ('App ' + item.appid);
            var aid = document.createElement('div'); aid.className = 'gf-lap-appid';
            aid.textContent = 'APP ID ' + item.appid;
            var dl = document.createElement('div'); dl.className = 'gf-lap-dl';
            dl.textContent = '↓';
            info.appendChild(name); info.appendChild(aid);
            row.appendChild(num); row.appendChild(info); row.appendChild(dl);
            row.onclick = function () {
                try { window.location.href = 'steam://install/' + item.appid; } catch (_) {}
                dl.textContent = '✓';
                dl.style.color = 'rgba(60,200,90,.8)';
                row.style.borderColor = 'rgba(60,200,90,.2)';
                row.style.background = 'rgba(60,200,90,.05)';
                row.style.cursor = 'default';
                row.onclick = null;
            };
            body.appendChild(row);
        });

        // Footer
        var foot = document.createElement('div'); foot.className = 'gf-lap-foot';
        var dis  = document.createElement('button'); dis.className = 'gf-lap-dismiss';
        dis.textContent = '✕  Dispensar';
        dis.onclick = function () {
            closeDrawer();
            try { call('DismissLoadedApps'); } catch (_) {}
        };
        foot.appendChild(dis);

        drw.appendChild(stripe); drw.appendChild(head); drw.appendChild(body); drw.appendChild(foot);
        wrap.appendChild(bg); wrap.appendChild(drw);
        document.body.appendChild(wrap);
    }

    function checkAndShowLoadedApps() {
        // Mostra o popup de jogos adicionados se houver apps na fila.
        // A checkbox controla se o appid foi ou não enfileirado — se não foi, a lista estará vazia.
        try {
            if (sessionStorage.getItem('gf_loaded_apps_shown')) return;
            sessionStorage.setItem('gf_loaded_apps_shown', '1');
            call('ReadLoadedApps').then(function (res) {
                try {
                    var d = JSON.parse(res);
                    if (d && d.success && d.apps && d.apps.length > 0) {
                        showLoadedAppsPopup(d.apps);
                        call('DismissLoadedApps');
                    }
                } catch (_) {}
            });
        } catch (_) {}
    }

    // Detecta quando o frontend do Steam está pronto
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', checkAndShowLoadedApps);
    } else {
        setTimeout(checkAndShowLoadedApps, 1500);
    }
    const BACKEND        = 'parzivalretrosteam';

    // Mapeamento de nomes reais de APIs para nomes genéricos
    const API_NAME_MAP = {
        'Morrenus':         'Servidor 1',
        'Ryuu':             'Servidor 2',
        'Ryuu Generator':   'Servidor 3',
        'TwentyTwo Cloud':  'Servidor 4',
        'Sushi':            'Servidor 5',
        'Online Fix':       'Servidor 6',
    };
    function maskApiName(name) {
        if (API_NAME_MAP[name]) return API_NAME_MAP[name];
        // Fallback: gera um nome genérico baseado no índice da API
        return name;
    }

    function call(method, args) {
        return Millennium.callServerMethod(BACKEND, method, Object.assign({ contentScriptQuery: '' }, args || {}));
    }

    function $(sel, ctx)  { return (ctx || document).querySelector(sel); }
    function $$(sel, ctx) { return Array.from((ctx || document).querySelectorAll(sel)); }

    function el(tag, css, html) {
        const e = document.createElement(tag);
        if (css)              e.style.cssText = css;
        if (html !== undefined) e.innerHTML = html;
        return e;
    }
    function div(css, html) { return el('div', css, html); }
    function parseJson(r) { try { return typeof r === 'string' ? JSON.parse(r) : r; } catch (_) { return null; } }

    // ── Estilos ────────────────────────────────────────────────────────────────
    function injectStyles() {
        if (document.getElementById('gf-styles')) return;
        const s = document.createElement('style');
        s.id = 'gf-styles';
        s.textContent = `
            @keyframes gf-up   { from{opacity:0;transform:translateY(16px) scale(.97)} to{opacity:1;transform:none} }
            @keyframes gf-in   { from{opacity:0} to{opacity:1} }
            @keyframes gf-spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }

            .gf-o * { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif !important; box-sizing:border-box; }

            /* ── Modal shell ── */
            .gf-modal {
                background:#0d0d0d;
                border-radius:18px;
                overflow:hidden;
                box-shadow:0 32px 90px rgba(0,0,0,.92), 0 0 0 1px rgba(255,255,255,.055);
                animation:gf-up .2s cubic-bezier(.16,1,.3,1);
                display:flex;
                flex-direction:column;
            }

            /* ── Hero ── */
            .gf-hero { position:relative; height:155px; overflow:hidden; flex-shrink:0; }
            .gf-hero-bg { position:absolute;inset:0; background:linear-gradient(120deg,rgba(80,0,0,.5),rgba(15,0,0,.95)); }
            .gf-hero-gl { position:absolute;inset:0;background:linear-gradient(to right,rgba(13,13,13,.96) 0%,rgba(13,13,13,.5) 60%,rgba(13,13,13,.15) 100%); }
            .gf-hero-gb { position:absolute;bottom:0;left:0;right:0;height:70px;background:linear-gradient(to top,#0d0d0d,transparent); }
            .gf-hero-top { position:absolute;top:0;left:0;right:0;z-index:5;display:flex;align-items:center;justify-content:space-between;padding:13px 16px; }
            .gf-hero-logo { font-size:8.5px;font-weight:900;letter-spacing:4px;color:rgba(255,255,255,.22);text-transform:uppercase; }
            .gf-hero-logo span { color:#dc0000; }
            .gf-hero-info { position:absolute;bottom:14px;left:18px;right:18px;z-index:4; }
            .gf-eyebrow { font-size:8.5px;font-weight:700;letter-spacing:4px;color:rgba(220,0,0,.6);text-transform:uppercase;margin-bottom:4px;display:flex;align-items:center;gap:6px; }
            .gf-eyebrow-line { width:12px;height:1px;background:rgba(220,0,0,.45);display:inline-block; }
            .gf-hero-title { font-size:20px;font-weight:900;color:#fff;letter-spacing:-.4px;line-height:1.08; }
            .gf-hero-meta { font-size:10px;color:rgba(255,255,255,.22);margin-top:4px;display:flex;align-items:center;gap:6px; }
            .gf-dot-green { width:5px;height:5px;border-radius:50%;background:#3cb85e;box-shadow:0 0 5px #3cb85e;display:inline-block; }

            /* ── Pane area ── */
            .gf-pane-area { flex:1; overflow-y:auto; min-height:0; }
            .gf-pane { display:none; animation:gf-in .15s ease; flex-direction:column; }
            .gf-pane.on { display:flex; }

            /* ── Bottom tab bar ── */
            .gf-tabbar {
                display:flex;
                border-top:1px solid rgba(255,255,255,.06);
                background:#080808;
                flex-shrink:0;
                padding:2px 0 0;
            }
            .gf-tab {
                flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center;
                padding:9px 4px 10px;
                font-size:9px; font-weight:800; letter-spacing:1.2px; text-transform:uppercase;
                color:rgba(255,255,255,.22); cursor:pointer; transition:all .14s;
                position:relative; gap:4px; border:none; background:none;
            }
            .gf-tab:hover { color:rgba(255,255,255,.45); }
            .gf-tab.on { color:#fff; }
            .gf-tab.on::before {
                content:'';
                position:absolute;top:0;left:50%;transform:translateX(-50%);
                width:28px;height:2px;background:#dc0000;border-radius:0 0 3px 3px;
            }
            .gf-tab-icon { font-size:16px; line-height:1; }

            /* ── Sections ── */
            .gf-sec { padding:16px 18px; }
            .gf-sec + .gf-sec { border-top:1px solid rgba(255,255,255,.04); }
            .gf-sec-ttl {
                font-size:9px;font-weight:800;letter-spacing:2.5px;text-transform:uppercase;
                color:rgba(255,255,255,.18);margin-bottom:13px;
            }
            .gf-divider { height:1px;background:rgba(255,255,255,.04);flex-shrink:0; }

            /* ── Stat cards ── */
            .gf-stat-grid { display:grid;grid-template-columns:1fr 1fr;gap:8px; }
            .gf-stat-card {
                background:#141414;border:1px solid rgba(255,255,255,.055);border-radius:10px;padding:12px 14px;
            }
            .gf-stat-lbl { font-size:8.5px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,.18);margin-bottom:5px; }
            .gf-stat-val { font-size:14px;font-weight:800;color:#fff; }

            /* ── Big action button ── */
            .gf-big-btn {
                width:100%;padding:13px 0;border-radius:10px;
                background:linear-gradient(135deg,#dc0000,#8b0000);
                color:#fff;font-size:11px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase;
                cursor:pointer;transition:all .15s;border:none;
                box-shadow:0 4px 20px rgba(220,0,0,.35);
            }
            .gf-big-btn:hover { box-shadow:0 7px 28px rgba(220,0,0,.6);transform:translateY(-1px); }
            .gf-big-btn:active { transform:none; }

            /* ── Fix cards ── */
            .gf-fix-grid { display:grid;grid-template-columns:1fr 1fr;gap:8px; }
            .gf-fix-card {
                border-radius:11px;padding:14px;transition:all .17s;
                border:1px solid rgba(255,255,255,.06);background:#141414;position:relative;overflow:hidden;
            }
            .gf-fix-card.av  { background:#0e1710;border-color:rgba(60,184,94,.18);cursor:pointer; }
            .gf-fix-card.av:hover { border-color:rgba(60,184,94,.45);transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,.5); }
            .gf-fix-card.no  { opacity:.3;cursor:not-allowed; }
            .gf-fix-card-top { display:flex;align-items:center;justify-content:space-between;margin-bottom:10px; }
            .gf-fix-ico {
                width:30px;height:30px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:13px;
            }
            .gf-badge {
                font-size:8.5px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;
                padding:2px 7px;border-radius:20px;
            }
            .gf-badge.av { background:rgba(60,184,94,.12);color:rgba(60,184,94,.85); }
            .gf-badge.no { background:rgba(255,255,255,.04);color:rgba(255,255,255,.18); }

            /* ── Action rows ── */
            .gf-act {
                display:flex;align-items:center;gap:13px;padding:13px 18px;cursor:pointer;
                transition:background .12s;border-bottom:1px solid rgba(255,255,255,.04);
            }
            .gf-act:last-child { border-bottom:none; }
            .gf-act:hover { background:rgba(255,255,255,.03); }
            .gf-act-ico {
                width:36px;height:36px;border-radius:9px;display:flex;align-items:center;
                justify-content:center;flex-shrink:0;font-size:17px;
            }
            .gf-act-name { font-size:13px;font-weight:600;color:#fff; }
            .gf-act-sub  { font-size:11px;color:rgba(255,255,255,.27);margin-top:1px; }
            .gf-act-chev { font-size:18px;color:rgba(255,255,255,.14);margin-left:auto; }
            .gf-danger-ttl { color:rgba(220,80,80,.45) !important; }

            /* ── Settings rows ── */
            .gf-srow {
                display:flex;align-items:center;justify-content:space-between;
                padding:13px 18px;border-bottom:1px solid rgba(255,255,255,.04);
            }
            .gf-srow:last-child { border:none; }
            .gf-srow-l  { font-size:13px;font-weight:600;color:rgba(255,255,255,.78); }
            .gf-srow-s  { font-size:11px;color:rgba(255,255,255,.24);margin-top:1px; }
            .gf-srow-v  { font-size:12px;font-weight:600;color:#dc0000;display:flex;align-items:center;gap:3px; }

            /* ── DRM warning ── */
            .gf-drm-warn {
                margin:12px 18px 0;
                background:rgba(255,160,0,.06);border:1px solid rgba(255,160,0,.22);border-radius:10px;padding:12px 14px;
            }
            .gf-drm-ttl { font-size:8.5px;font-weight:800;letter-spacing:2px;color:rgba(255,180,0,.8);text-transform:uppercase;margin-bottom:5px; }
            .gf-drm-sub { font-size:11px;color:rgba(255,255,255,.35);line-height:1.5;margin-bottom:7px; }
            .gf-drm-chips { display:flex;flex-wrap:wrap;gap:3px; }
            .gf-drm-chip {
                display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:20px;
                background:rgba(255,160,0,.1);border:1px solid rgba(255,160,0,.28);
                color:rgba(255,180,0,.85);font-size:10px;font-weight:700;
            }

            /* ── API status rows ── */
            .gf-api-row {
                display:flex;align-items:center;justify-content:space-between;padding:9px 12px;
                background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.05);
                border-radius:8px;margin-bottom:5px;
            }
            .gf-api-row:last-child { margin-bottom:0; }
            .gf-api-name { font-size:13px;font-weight:600;color:rgba(255,255,255,.7); }
            .gf-api-st   { font-size:10px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:rgba(255,255,255,.25);display:flex;align-items:center;gap:5px; }

            /* ── Progress ── */
            .gf-pw { height:3px;background:rgba(255,255,255,.06);border-radius:3px;overflow:hidden; }
            .gf-pf { height:100%;background:linear-gradient(90deg,#dc0000,#ff3333);border-radius:3px;transition:width .3s;width:0%; }
            .gf-pt { font-size:10px;color:rgba(255,255,255,.28);margin-top:5px;display:flex;justify-content:space-between; }

            /* ── Spinner ── */
            .gf-spinner {
                width:16px;height:16px;border:2px solid rgba(255,255,255,.1);border-top-color:#dc0000;
                border-radius:50%;animation:gf-spin .8s linear infinite;display:inline-block;flex-shrink:0;
            }

            /* ── Empty state ── */
            .gf-empty { text-align:center;padding:32px 20px;color:rgba(255,255,255,.2);font-size:13px;line-height:1.8; }

            /* ── Buttons (modais) ── */
            .gf-btn {
                padding:11px 0;border-radius:9px;font-size:11px;font-weight:800;letter-spacing:1px;
                text-transform:uppercase;cursor:pointer;transition:all .14s;border:none;width:100%;
            }
            .gf-btn.p { background:linear-gradient(135deg,#dc0000,#8b0000);color:#fff;box-shadow:0 4px 18px rgba(220,0,0,.4); }
            .gf-btn.p:hover { box-shadow:0 6px 26px rgba(220,0,0,.65);transform:translateY(-1px); }
            .gf-btn.s { background:#181818;color:rgba(255,255,255,.38);border:1px solid rgba(255,255,255,.07); }
            .gf-btn.s:hover { background:#222;color:rgba(255,255,255,.6); }

            .gf-status-msg { font-size:12px;color:rgba(255,255,255,.36);text-align:center;min-height:18px;margin-top:10px; }

            ::-webkit-scrollbar { width:3px; }
            ::-webkit-scrollbar-track { background:transparent; }
            ::-webkit-scrollbar-thumb { background:rgba(220,0,0,.3);border-radius:3px; }
        `;
        document.head.appendChild(s);
    }

    // ── Helpers UI ─────────────────────────────────────────────────────────────
    function overlay(z) {
        return div(
            'position:fixed;inset:0;background:rgba(0,0,0,.88);backdrop-filter:blur(22px);' +
            'z-index:' + (z || 99999) + ';display:flex;align-items:center;justify-content:center;'
        );
    }
    function mkBtn(text, pri) {
        const b = el('button');
        b.className = 'gf-btn ' + (pri ? 'p' : 's');
        b.textContent = text;
        return b;
    }
    function xBtn(onClick) {
        const b = div(
            'width:28px;height:28px;border-radius:50%;background:rgba(0,0,0,.55);' +
            'border:1px solid rgba(255,255,255,.08);display:flex;align-items:center;' +
            'justify-content:center;cursor:pointer;transition:all .13s;' +
            'font-size:11px;color:rgba(255,255,255,.45);flex-shrink:0;'
        );
        b.textContent = '✕';
        b.onmouseover = function () { this.style.background = 'rgba(220,0,0,.22)'; this.style.borderColor = 'rgba(220,0,0,.4)'; };
        b.onmouseout  = function () { this.style.background = 'rgba(0,0,0,.55)';   this.style.borderColor = 'rgba(255,255,255,.08)'; };
        b.onclick = onClick;
        return b;
    }

    // ── Game detection ─────────────────────────────────────────────────────────
    function getAppId() {
        const m = window.location.href.match(/\/app\/(\d+)/);
        return m ? parseInt(m[1], 10) : NaN;
    }
    function getGameName() {
        try {
            const e = $('.apphub_AppName') || $('[class*="gameTitle"]') || $('h1');
            return e ? e.textContent.trim() : '';
        } catch (_) { return ''; }
    }

    // ── Hero ───────────────────────────────────────────────────────────────────
    function heroBlock(appid, gameName, onClose) {
        const isApp = !isNaN(appid);
        const wrap = div(''); wrap.className = 'gf-hero';
        const bg = div(''); bg.className = 'gf-hero-bg';
        if (isApp) {
            try {
                const img = $('img.game_header_image_full') || $('[class*="headerImage"] img') || $('img[src*="header"]');
                if (img && img.src) bg.style.background = 'url("' + img.src + '") center/cover';
            } catch (_) {}
        }
        const gl = div(''); gl.className = 'gf-hero-gl';
        const gb = div(''); gb.className = 'gf-hero-gb';
        const top = div(''); top.className = 'gf-hero-top';
        const logo = div(''); logo.className = 'gf-hero-logo';
        logo.innerHTML = '<span>' + PLUGIN_NAME + '</span>';
        top.appendChild(logo);
        top.appendChild(xBtn(onClose));
        const info = div(''); info.className = 'gf-hero-info';
        const eyebrow = div(''); eyebrow.className = 'gf-eyebrow';
        eyebrow.innerHTML = '<span class="gf-eyebrow-line"></span>' + (isApp ? 'Jogo detectado' : 'Configurações');
        const title = div(''); title.className = 'gf-hero-title';
        title.textContent = isApp ? (gameName || 'Jogo ' + appid) : PLUGIN_NAME;
        const meta = div(''); meta.className = 'gf-hero-meta';
        if (isApp) meta.innerHTML = '<span class="gf-dot-green"></span>Instalado';
        else meta.textContent = 'v' + PLUGIN_VERSION;
        info.appendChild(eyebrow); info.appendChild(title); info.appendChild(meta);
        wrap.appendChild(bg); wrap.appendChild(gl); wrap.appendChild(gb);
        wrap.appendChild(top); wrap.appendChild(info);
        return wrap;
    }

    // ── Dialogs ────────────────────────────────────────────────────────────────
    function showAlert(msg) {
        injectStyles();
        const o = overlay(100002); o.classList.add('gf-o');
        const m = div(''); m.className = 'gf-modal'; m.style.width = '340px';
        const h = div('padding:15px 18px 13px;border-bottom:1px solid rgba(255,255,255,.06);background:linear-gradient(90deg,rgba(220,0,0,.1),transparent 70%);');
        h.innerHTML = '<div style="font-size:10px;font-weight:800;letter-spacing:3px;color:#dc0000;text-transform:uppercase;">' + PLUGIN_NAME + '</div>';
        const b = div('padding:18px;font-size:13px;color:rgba(255,255,255,.55);line-height:1.65;'); b.textContent = msg;
        const f = div('padding:10px 18px 16px;');
        const ok = mkBtn('OK', true); ok.onclick = function () { o.remove(); }; f.appendChild(ok);
        o.addEventListener('click', function (e) { if (e.target === o) o.remove(); });
        m.appendChild(h); m.appendChild(b); m.appendChild(f); o.appendChild(m); document.body.appendChild(o);
    }
    function showConfirm(msg, onYes, confirmLabel) {
        injectStyles();
        const o = overlay(100002); o.classList.add('gf-o');
        const m = div(''); m.className = 'gf-modal'; m.style.width = '340px';
        const h = div('padding:15px 18px 13px;border-bottom:1px solid rgba(255,255,255,.06);background:linear-gradient(90deg,rgba(220,0,0,.1),transparent 70%);');
        h.innerHTML = '<div style="font-size:10px;font-weight:800;letter-spacing:3px;color:#dc0000;text-transform:uppercase;">' + PLUGIN_NAME + '</div>';
        const b = div('padding:18px;font-size:13px;color:rgba(255,255,255,.55);line-height:1.65;'); b.textContent = msg;
        const f = div('padding:10px 18px 16px;display:flex;gap:8px;');
        const c = mkBtn('Cancelar', false); const ok = mkBtn(confirmLabel || 'Confirmar', true);
        c.style.flex = ok.style.flex = '1';
        c.onclick = function () { o.remove(); };
        ok.onclick = function () { o.remove(); onYes(); };
        o.addEventListener('click', function (e) { if (e.target === o) o.remove(); });
        f.appendChild(c); f.appendChild(ok);
        m.appendChild(h); m.appendChild(b); m.appendChild(f); o.appendChild(m); document.body.appendChild(o);
    }

    // ── Download popup ──────────────────────────────────────────────────────────
    function showDownloadPopup(appid, gameName) {
        if ($('.gf-dl-o')) return;
        injectStyles();
        const o = overlay(); o.className = 'gf-o gf-dl-o';
        const m = div(''); m.className = 'gf-modal'; m.style.width = '460px'; m.style.maxHeight = '560px';

        const h = div('padding:16px 18px 14px;border-bottom:1px solid rgba(255,255,255,.05);background:linear-gradient(135deg,rgba(220,0,0,.1),transparent 70%);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;');
        const ht = div('');
        ht.innerHTML =
            '<div style="font-size:9px;font-weight:700;letter-spacing:3px;color:rgba(220,0,0,.7);text-transform:uppercase;margin-bottom:3px;">Buscando jogo nos servidores</div>' +
            '<div style="font-size:17px;font-weight:800;color:#fff;">' + (gameName || 'Jogo ' + appid) + '</div>';
        h.appendChild(ht);
        h.appendChild(xBtn(function () { o.remove(); }));

        const body = div('padding:16px 18px;flex:1;overflow-y:auto;');
        const sl = div('font-size:9px;font-weight:800;letter-spacing:2.5px;text-transform:uppercase;color:rgba(255,255,255,.18);margin-bottom:10px;');
        sl.textContent = 'Verificando servidores';
        body.appendChild(sl);

        const apiList = div('');
        body.appendChild(apiList);

        const pw = div('margin-top:14px;'); pw.style.display = 'none';
        const pwB = div('gf-pw'); const pwF = div('gf-pf'); pwB.appendChild(pwF);
        const pwT = div('gf-pt');
        pw.appendChild(pwB); pw.appendChild(pwT); body.appendChild(pw);

        const sm = div('gf-status-msg');
        body.appendChild(sm);

        const f = div('padding:10px 18px 16px;flex-shrink:0;');
        const cancelBtn = mkBtn('Cancelar', false);
        cancelBtn.onclick = function () { call('CancelDownload', { appid: appid }); o.remove(); };
        f.appendChild(cancelBtn);

        m.appendChild(h); m.appendChild(body); m.appendChild(f);
        o.appendChild(m); document.body.appendChild(o);
        o.addEventListener('click', function (e) { if (e.target === o) o.remove(); });

        // Montar lista de servidores (com nomes mascarados)
        call('GetApiList').then(function (res) {
            try {
                const d = parseJson(res);
                if (d && d.apis) {
                    apiList.innerHTML = '';
                    d.apis.forEach(function (api) {
                        const row = div('gf-api-row');
                        const n = div('gf-api-name'); n.textContent = maskApiName(api.name);
                        const st = div('gf-api-st');
                        st.innerHTML = '<span class="gf-spinner" style="width:11px;height:11px;border-width:1.5px;"></span><span>Aguardando</span>';
                        st.dataset.an = api.name;
                        row.appendChild(n); row.appendChild(st); apiList.appendChild(row);
                    });
                }
            } catch (_) {}
        }).catch(function () {});

        call('StartDownload', { appid: appid, game_name: gameName || '' });

        const poll = setInterval(function () {
            if (!document.body.contains(o)) { clearInterval(poll); return; }
            call('GetDownloadStatus', { appid: appid }).then(function (res) {
                try {
                    const d = parseJson(res);
                    const state = (d && d.state) ? d.state : {};
                    const st    = state.status || '';
                    const apiSt = state.apiStatus || {};

                    Object.keys(apiSt).forEach(function (name) {
                        const el = apiList.querySelector('[data-an="' + name + '"]');
                        if (!el) return;
                        const s = apiSt[name];
                        const cols = { encontrado: 'rgba(60,184,94,.9)', 'indisponível': 'rgba(255,255,255,.18)', verificando: 'rgba(255,255,255,.5)' };
                        const ics  = { encontrado: '✓ ', 'indisponível': '— ' };
                        const isErr = s && s.startsWith('erro');
                        el.style.color = isErr ? 'rgba(220,60,60,.7)' : (cols[s] || 'rgba(255,255,255,.28)');
                        const spin = s === 'verificando' ? '<span class="gf-spinner" style="width:11px;height:11px;border-width:1.5px;"></span> ' : '';
                        el.innerHTML = spin + (isErr ? '✕ ' : (ics[s] || '')) + '<span>' + s + '</span>';
                    });

                    const mb = function (b) { return (b / 1048576).toFixed(1) + ' MB'; };
                    if (st === 'downloading') {
                        pw.style.display = 'block';
                        const total = state.totalBytes || 0, read = state.bytesRead || 0;
                        const pct = total > 0 ? Math.min(100, Math.round(read / total * 100)) : 0;
                        pwF.style.width = pct + '%';
                        pwT.innerHTML = '<span>' + pct + '%</span><span>' + mb(read) + ' / ' + (total > 0 ? mb(total) : '?') + '</span>';
                        const curApi = state.currentApi ? maskApiName(state.currentApi) : '...';
                        sm.textContent = 'Baixando via ' + curApi;
                        sl.textContent = 'Baixando';
                    } else if (st === 'extracting') {
                        pwF.style.width = '100%'; sm.textContent = 'Instalando...'; sl.textContent = 'Instalando';
                    } else if (st === 'done') {
                        clearInterval(poll); o.remove();
                        // Reinicia automaticamente para que o _front_end_loaded processe
                        
                        showConfirm('Jogo adicionado com sucesso! Reinicie o Steam para aplicar.', function () {
                            call('RestartSteam', { appid: 0 });
                        }, 'Reiniciar Steam');
                    }
                    else if (st === 'failed')   { clearInterval(poll); o.remove(); showAlert('Nenhum servidor encontrou este jogo. Tente novamente mais tarde.'); }
                    else if (st === 'cancelled') { clearInterval(poll); o.remove(); }
                } catch (_) {}
            }).catch(function () {});
        }, 600);
    }

    // ── Fix progress popup ──────────────────────────────────────────────────────
    function showFixProgress(appid, fixType, fixLabel) {
        if ($('.gf-fix-o')) return;
        injectStyles();
        const o = overlay(); o.className = 'gf-o gf-fix-o';
        const m = div(''); m.className = 'gf-modal'; m.style.width = '400px';

        const h = div('padding:16px 18px 14px;border-bottom:1px solid rgba(255,255,255,.06);background:linear-gradient(90deg,rgba(220,0,0,.1),transparent 70%);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;');
        h.innerHTML = '<div style="font-size:10px;font-weight:800;letter-spacing:3px;color:#dc0000;text-transform:uppercase;">' + fixLabel + '</div>';
        h.appendChild(xBtn(function () { call('CancelFix', { appid: appid }); o.remove(); }));

        const body = div('padding:22px 18px;');
        const sm = div('font-size:13px;color:rgba(255,255,255,.5);margin-bottom:14px;text-align:center;');
        sm.textContent = 'Aplicando ' + fixLabel + '...';
        const pw = div('gf-pw'); const pf = div('gf-pf'); pw.appendChild(pf);
        const pt = div('gf-pt');
        body.appendChild(sm); body.appendChild(pw); body.appendChild(pt);

        const f = div('padding:10px 18px 16px;flex-shrink:0;');
        const cb = mkBtn('Cancelar', false);
        cb.onclick = function () { call('CancelFix', { appid: appid }); o.remove(); };
        f.appendChild(cb);

        m.appendChild(h); m.appendChild(body); m.appendChild(f);
        o.appendChild(m); document.body.appendChild(o);

        call('ApplyFix', { appid: appid, fix_type: fixType });

        const poll = setInterval(function () {
            if (!document.body.contains(o)) { clearInterval(poll); return; }
            call('GetFixStatus', { appid: appid }).then(function (res) {
                try {
                    const d = parseJson(res);
                    const state = (d && d.state) ? d.state : {};
                    const st = state.status || '';
                    const total = state.totalBytes || 0, read = state.bytesRead || 0;
                    const mb = function (b) { return (b / 1048576).toFixed(1) + ' MB'; };
                    if (st === 'downloading') {
                        const pct = total > 0 ? Math.min(100, Math.round(read / total * 100)) : 0;
                        pf.style.width = pct + '%';
                        pt.innerHTML = '<span>' + pct + '%</span><span>' + mb(read) + ' / ' + (total > 0 ? mb(total) : '?') + '</span>';
                        sm.textContent = 'Baixando ' + fixLabel + '...';
                    } else if (st === 'extracting') {
                        pf.style.width = '100%'; sm.textContent = 'Instalando...';
                    } else if (st === 'done')     { clearInterval(poll); o.remove(); showAlert(fixLabel + ' aplicado! Reinicie o Steam para ativar.'); }
                    else if (st === 'failed')  { clearInterval(poll); o.remove(); showAlert('Falha ao aplicar ' + fixLabel + ': ' + (state.error || 'erro desconhecido')); }
                    else if (st === 'cancelled'){ clearInterval(poll); o.remove(); }
                } catch (_) {}
            }).catch(function () {});
        }, 500);
    }

    // ── Fix cards builder ───────────────────────────────────────────────────────
    function buildFixCards(grid, data, appid, mainOverlay) {
        const gen = (data && data.genericFix) ? data.genericFix : {};
        const onl = (data && data.onlineFix)  ? data.onlineFix  : {};

        function fixCard(title, sub, avail, onClick) {
            const card = div(''); card.className = 'gf-fix-card ' + (avail ? 'av' : 'no');
            const top = div(''); top.className = 'gf-fix-card-top';
            const ico = div(''); ico.className = 'gf-fix-ico';
            ico.style.background = avail ? 'rgba(60,184,94,.13)' : 'rgba(255,255,255,.04)';
            ico.style.color      = avail ? '#3cb85e' : 'rgba(255,255,255,.18)';
            ico.textContent = avail ? '✓' : '✕';
            const badge = div(''); badge.className = 'gf-badge ' + (avail ? 'av' : 'no');
            badge.textContent = avail ? 'Disponível' : 'Indisponível';
            top.appendChild(ico); top.appendChild(badge);
            const nm = div('font-size:13px;font-weight:700;margin-bottom:2px;');
            nm.style.color = avail ? '#fff' : 'rgba(255,255,255,.22)'; nm.textContent = title;
            const sb = div('font-size:10px;');
            sb.style.color = avail ? 'rgba(60,184,94,.5)' : 'rgba(255,255,255,.2)'; sb.textContent = sub;
            card.appendChild(top); card.appendChild(nm); card.appendChild(sb);
            if (avail) card.onclick = function () { if (mainOverlay) mainOverlay.remove(); onClick(); };
            return card;
        }

        grid.appendChild(fixCard('Fix Genérico',  'Patch de bypass',      gen.available === true, function () { showFixProgress(appid, 'generic', 'Fix Genérico'); }));
        grid.appendChild(fixCard('Fix Online',    'Multiplayer / Online', onl.available === true, function () { showFixProgress(appid, 'online',  'Fix Online'); }));
    }

    // ── Menu principal ──────────────────────────────────────────────────────────
    function showMainMenu(appid, gameName) {
        if ($('.gf-main-o')) return;
        injectStyles();
        const isApp = !isNaN(appid);
        const o = overlay(); o.className = 'gf-o gf-main-o';
        const m = div(''); m.className = 'gf-modal';
        m.style.width = '432px';
        m.style.maxHeight = Math.min(window.innerHeight * 0.9, 660) + 'px';

        // Hero
        m.appendChild(heroBlock(appid, gameName, function () { o.remove(); }));

        // Pane area
        const paneArea = div(''); paneArea.className = 'gf-pane-area';

        // ══ ABA 1: ADICIONAR ═════════════════════════════════════════════════
        const p1 = div(''); p1.className = 'gf-pane on';

        if (isApp) {
            // ── Botão Adicionar / Remover (depende se .lua já existe) ────────
            const s1 = div(''); s1.className = 'gf-sec';
            const s1ttl = div(''); s1ttl.className = 'gf-sec-ttl'; s1ttl.textContent = 'Adicionar jogo';
            const addBtn = el('button'); addBtn.className = 'gf-big-btn'; addBtn.textContent = 'Verificando...';
            addBtn.disabled = true; addBtn.style.opacity = '0.5';
            // Verifica se o jogo já foi adicionado
            call('HasLuaForApp', { appid: appid }).then(function (res) {
                try {
                    var d = parseJson(res);
                    if (d && d.exists) {
                        // Jogo já adicionado — mostrar botão de remover
                        addBtn.textContent = 'Remover da biblioteca';
                        addBtn.style.background = 'rgba(220,0,0,.15)';
                        addBtn.style.borderColor = 'rgba(220,0,0,.35)';
                        addBtn.style.color = 'rgba(255,80,80,.9)';
                        addBtn.disabled = false; addBtn.style.opacity = '';
                        addBtn.onclick = function () {
                            showConfirm('Remover "' + (gameName || 'este jogo') + '" da biblioteca?', function () {
                                call('DeleteLuaForApp', { appid: appid }).then(function (r) {
                                    try {
                                        var rd = parseJson(r);
                                        if (rd && rd.success && rd.count > 0) {
                                            addBtn.textContent = 'Adicionar';
                                            addBtn.style.background = '';
                                            addBtn.style.borderColor = '';
                                            addBtn.style.color = '';
                                            addBtn.onclick = function () { o.remove(); showDownloadPopup(appid, gameName); };
                                            showConfirm('Jogo removido. Reiniciar Steam agora?', function () {
                                                call('RestartSteam', { appid: 0 });
                                            }, 'Reiniciar');
                                        } else {
                                            showAlert('Nenhum arquivo encontrado para remover.');
                                        }
                                    } catch (_) { showAlert('Erro ao remover.'); }
                                });
                            }, 'Remover');
                        };
                    } else {
                        // Jogo não adicionado — botão de adicionar normal
                        addBtn.textContent = 'Adicionar';
                        addBtn.disabled = false; addBtn.style.opacity = '';
                        addBtn.onclick = function () { o.remove(); showDownloadPopup(appid, gameName); };
                    }
                } catch (_) {
                    addBtn.textContent = 'Adicionar';
                    addBtn.disabled = false; addBtn.style.opacity = '';
                    addBtn.onclick = function () { o.remove(); showDownloadPopup(appid, gameName); };
                }
            }).catch(function () {
                addBtn.textContent = 'Adicionar';
                addBtn.disabled = false; addBtn.style.opacity = '';
                addBtn.onclick = function () { o.remove(); showDownloadPopup(appid, gameName); };
            });

            const restartBtn2 = el('button');
            restartBtn2.style.cssText =
                'width:100%;margin-top:9px;padding:11px 0;border-radius:10px;' +
                'background:rgba(255,200,0,.08);border:1px solid rgba(255,200,0,.22);' +
                'color:rgba(255,210,0,.8);font-size:11px;font-weight:800;letter-spacing:1px;' +
                'text-transform:uppercase;cursor:pointer;transition:all .14s;';
            restartBtn2.textContent = '↺  Reiniciar Steam';
            restartBtn2.onmouseover = function () { this.style.background = 'rgba(255,200,0,.15)'; this.style.borderColor = 'rgba(255,200,0,.4)'; this.style.color = 'rgba(255,220,0,.95)'; };
            restartBtn2.onmouseout  = function () { this.style.background = 'rgba(255,200,0,.08)'; this.style.borderColor = 'rgba(255,200,0,.22)'; this.style.color = 'rgba(255,210,0,.8)'; };
            restartBtn2.onclick = function () {
                showConfirm('Deseja reiniciar o Steam agora?', function () {
                    call('RestartSteam', { appid: 0 });
                }, 'Reiniciar Steam');
            };

            s1.appendChild(s1ttl); s1.appendChild(addBtn); s1.appendChild(restartBtn2);
            // ── Avisos especiais por launcher/franquia (aba Adicionar) ─────
            (function () {
                var gn = (gameName || '').toLowerCase();

                // COD AppIDs conhecidos
                var COD_APPIDS = [42700,42710,202990,209160,209080,311210,476600,476620,1100448,1227430,1743720,1174180,1938090,2744370,2835570];
                var isCOD = COD_APPIDS.indexOf(appid) !== -1 ||
                    ['call of duty','modern warfare','black ops','warzone','vanguard','cold war'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isRockstar = ['grand theft auto','gta','red dead','rdr','max payne','l.a. noire','bully','midnight club'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isEA = ['battlefield','mass effect','dragon age','need for speed','fifa','ea fc','apex legends',
                    'star wars jedi','the sims','plants vs zombies','titanfall','anthem','dead space',
                    'it takes two','a way out','wild hearts','immortals of aveum'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isUbisoft = ['assassin','assassins creed','far cry','watch dogs','watch_dogs','rainbow six',
                    'for honor','the crew','riders republic','anno','just dance','immortals fenyx',
                    'skull and bones','avatar frontiers','prince of persia'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isBattlenet = ['overwatch','diablo','world of warcraft','starcraft','hearthstone',
                    'heroes of the storm','call of duty'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isMicrosoft = ['halo','forza','sea of thieves','gears of war','gears 5','age of empires',
                    'minecraft','flight simulator','pentiment','grounded','psychonauts','hi-fi rush',
                    'ori and','fable'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isSony = ['god of war','spider-man','spiderman','the last of us','horizon',
                    'ghost of tsushima','uncharted','returnal','ratchet','sackboy','days gone',
                    'gran turismo','helldivers'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isNintendo = ['mario','zelda','pokemon','kirby','metroid','donkey kong','splatoon',
                    'animal crossing','fire emblem','xenoblade','pikmin','smash bros'].some(function(k){ return gn.indexOf(k) !== -1; });

                var is2K = ['borderlands','bioshock','civilization','xcom','mafia','nba 2k','wwe 2k',
                    'tiny tina','the quarry','midnight suns','kerbal'].some(function(k){ return gn.indexOf(k) !== -1; });

                // Warn cards: múltiplos podem aparecer ao mesmo tempo
                var warnings = [];

                // Cor única padronizada para todos os avisos
                var WC = { bg: 'rgba(255,160,0,.06)', border: 'rgba(255,160,0,.22)', titleColor: 'rgba(255,185,0,.95)' };

                if (isCOD) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Call of Duty detectado',
                    body: 'Jogos de COD utilizam anti-cheat RICOCHET. Mesmo com fix aplicado, o jogo pode não iniciar ou ser bloqueado. <b style="color:rgba(255,200,80,.7);">Prossiga por sua conta e risco.</b>'
                });
                if (isRockstar) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Rockstar Games detectado',
                    body: 'Jogos da Rockstar exigem o <b style="color:rgba(255,200,80,.7);">Rockstar Games Launcher</b>. Além do fix do Steam, pode ser necessário um fix externo compatível com o launcher para que o jogo funcione.'
                });
                if (isEA && !isCOD) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'EA App detectado',
                    body: 'Jogos da EA exigem o <b style="color:rgba(255,200,80,.7);">EA App</b> instalado. O fix do Steam pode não ser suficiente — um fix externo compatível com o EA App pode ser necessário.'
                });
                if (isUbisoft) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Ubisoft Connect detectado',
                    body: 'Jogos da Ubisoft exigem o <b style="color:rgba(255,200,80,.7);">Ubisoft Connect</b> instalado. Mesmo com fix aplicado, um fix externo compatível com o launcher pode ser necessário.'
                });
                if (isBattlenet && !isCOD) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Battle.net detectado',
                    body: 'Jogos do Battle.net exigem o <b style="color:rgba(255,200,80,.7);">Battle.net</b> instalado e autenticado. Mesmo com fix aplicado, o jogo pode não funcionar sem a plataforma ativa.'
                });
                if (isMicrosoft) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Microsoft / Xbox Game Studios detectado',
                    body: 'Jogos da Microsoft podem exigir o <b style="color:rgba(255,200,80,.7);">Xbox App</b> ou conta Microsoft ativa. Mesmo com fix, o jogo pode não funcionar sem a plataforma.'
                });
                if (isSony) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Sony / PlayStation Studios detectado',
                    body: 'Alguns jogos da Sony exigem conta <b style="color:rgba(255,200,80,.7);">PlayStation Network (PSN)</b>. Mesmo com fix, funcionalidades ou o próprio jogo podem não funcionar sem conta PSN.'
                });
                if (isNintendo) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Nintendo detectado',
                    body: 'Jogos da Nintendo raramente estão disponíveis no Steam. Verifique se é um port ou versão oficial. Mesmo com fix, a compatibilidade pode ser limitada.'
                });
                if (is2K) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: '2K Games detectado',
                    body: 'Alguns jogos da 2K utilizam launcher próprio da <b style="color:rgba(255,200,80,.7);">2K</b>. Mesmo com fix do Steam, o launcher pode bloquear a execução do jogo.'
                });

                if (warnings.length === 0) return;

                warnings.forEach(function(w) {
                    var warn = div('');
                    warn.style.cssText = 'margin:10px 0 0;padding:12px 14px;border-radius:10px;border:1px solid;font-size:11px;line-height:1.6;' +
                        'background:' + w.bg + ';border-color:' + w.border + ';';
                    warn.innerHTML =
                        '<div style="font-weight:800;color:' + w.titleColor + ';margin-bottom:5px;font-size:12px;">' + w.icon + ' ' + w.title + '</div>' +
                        '<div style="color:rgba(255,255,255,.45);">' + w.body + '</div>';
                    s1.appendChild(warn);
                });
            })();
            p1.appendChild(s1);

            p1.appendChild(div('gf-divider'));

            // ── Status real de instalação ────────────────────────────────────
            const s2 = div(''); s2.className = 'gf-sec';
            const s2ttl = div(''); s2ttl.className = 'gf-sec-ttl'; s2ttl.textContent = 'Status';
            const ig = div(''); ig.className = 'gf-stat-grid';

            function statCard(lbl, val, col) {
                const c = div(''); c.className = 'gf-stat-card';
                const l = div(''); l.className = 'gf-stat-lbl'; l.textContent = lbl;
                const v = div(''); v.className = 'gf-stat-val'; v.style.color = col || '#fff'; v.textContent = val;
                c.appendChild(l); c.appendChild(v); return c;
            }

            const appIdCard  = statCard('App ID', appid, '#dc0000');
            const statusCard = statCard('Instalado', '...', 'rgba(255,255,255,.3)');
            ig.appendChild(appIdCard); ig.appendChild(statusCard);
            s2.appendChild(s2ttl); s2.appendChild(ig);
            p1.appendChild(s2);

            // Verificar instalação real via backend
            call('GetGameInstallPath', { appid: appid }).then(function (res) {
                try {
                    const d = parseJson(res);
                    const installed = d && d.success === true;
                    const sv = statusCard.querySelector('.gf-stat-val');
                    if (sv) {
                        sv.textContent = installed ? 'Sim' : 'Não';
                        sv.style.color  = installed ? '#3cb85e' : 'rgba(255,255,255,.35)';
                    }
                } catch (_) {}
            }).catch(function () {
                const sv = statusCard.querySelector('.gf-stat-val');
                if (sv) { sv.textContent = '?'; sv.style.color = 'rgba(255,255,255,.25)'; }
            });

            p1.appendChild(div('gf-divider'));

            // ── Proteção do jogo (DRM) ───────────────────────────────────────
            const s3 = div(''); s3.className = 'gf-sec';
            const s3ttl = div(''); s3ttl.className = 'gf-sec-ttl'; s3ttl.textContent = 'Proteção';
            const drmBox = div('');
            drmBox.innerHTML = '<div style="display:flex;align-items:center;gap:7px;color:rgba(255,255,255,.2);font-size:12px;">' +
                '<span class="gf-spinner" style="width:12px;height:12px;border-width:1.5px;"></span>Verificando proteções...</div>';
            s3.appendChild(s3ttl); s3.appendChild(drmBox);
            p1.appendChild(s3);

            // DRM info map: proteção → { can_fix, can_online }
            const DRM_COMPAT = {
                'Steam DRM':     { fixOk: true,  onlineOk: true,  note: 'Proteção leve, compatível com fixes.' },
                'Denuvo':        { fixOk: false, onlineOk: false, note: 'Proteção forte, fixes podem não funcionar.' },
                'EasyAntiCheat': { fixOk: true,  onlineOk: false, note: 'Fix offline funciona, online pode falhar.' },
                'BattlEye':      { fixOk: true,  onlineOk: false, note: 'Fix offline funciona, online bloqueado.' },
                'CEG':           { fixOk: true,  onlineOk: true,  note: 'Compatível com fixes na maioria dos casos.' },
                'SecuROM':       { fixOk: true,  onlineOk: true,  note: 'Geralmente compatível com fixes.' },
                'SKIDROW':       { fixOk: true,  onlineOk: true,  note: 'Compatível.' },
                'VMProtect':     { fixOk: false, onlineOk: false, note: 'Proteção avançada, fixes raramente funcionam.' },
            };

            call('DetectDrm', { appid: appid }).then(function (res) {
                try {
                    const data = parseJson(res);
                    drmBox.innerHTML = '';

                    if (!data || !data.drm || data.drm.length === 0) {
                        // Nenhuma proteção detectada
                        const ok = div('background:rgba(60,184,94,.07);border:1px solid rgba(60,184,94,.2);border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:10px;');
                        ok.innerHTML = '<div style="font-size:18px;line-height:1;">✓</div>' +
                            '<div>' +
                            '<div style="font-size:13px;font-weight:700;color:#3cb85e;margin-bottom:2px;">Sem proteção detectada</div>' +
                            '<div style="font-size:11px;color:rgba(255,255,255,.35);line-height:1.5;">Este jogo deve funcionar normalmente com os fixes disponíveis.</div>' +
                            '</div>';
                        drmBox.appendChild(ok);
                        return;
                    }

                    data.drm.forEach(function (d) {
                        const name = d.name || 'Desconhecida';
                        const compat = DRM_COMPAT[name] || { fixOk: null, onlineOk: null, note: 'Compatibilidade desconhecida com fixes.' };

                        const card = div('background:#141414;border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:13px 14px;margin-bottom:8px;');

                        // Header
                        const hdr = div('display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;');
                        const nameEl = div('font-size:13px;font-weight:700;color:#fff;display:flex;align-items:center;gap:7px;');
                        nameEl.innerHTML = '<span style="font-size:15px;">🔒</span>' + name;
                        hdr.appendChild(nameEl);

                        // Compatibilidade badges
                        const badges = div('display:flex;gap:5px;flex-wrap:wrap;margin-bottom:7px;');
                        function mkCompBadge(label, ok) {
                            const b = div('font-size:9px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;padding:3px 8px;border-radius:20px;');
                            if (ok === true) {
                                b.style.background = 'rgba(60,184,94,.12)'; b.style.color = 'rgba(60,184,94,.85)';
                                b.textContent = '✓ ' + label;
                            } else if (ok === false) {
                                b.style.background = 'rgba(220,60,60,.1)'; b.style.color = 'rgba(220,100,100,.8)';
                                b.textContent = '✕ ' + label;
                            } else {
                                b.style.background = 'rgba(255,255,255,.05)'; b.style.color = 'rgba(255,255,255,.3)';
                                b.textContent = '? ' + label;
                            }
                            return b;
                        }
                        badges.appendChild(mkCompBadge('Fix Offline', compat.fixOk));
                        badges.appendChild(mkCompBadge('Fix Online',  compat.onlineOk));

                        // Nota
                        const note = div('font-size:11px;color:rgba(255,255,255,.35);line-height:1.55;');
                        note.textContent = compat.note;

                        card.appendChild(hdr); card.appendChild(badges); card.appendChild(note);
                        drmBox.appendChild(card);
                    });
                } catch (_) {
                    drmBox.innerHTML = '<div style="font-size:12px;color:rgba(255,255,255,.2);padding:4px 0;">Não foi possível verificar as proteções.</div>';
                }
            }).catch(function () {
                drmBox.innerHTML = '<div style="font-size:12px;color:rgba(255,255,255,.2);padding:4px 0;">Sem conexão para verificar proteções.</div>';
            });

        } else {
            p1.innerHTML = '<div class="gf-empty">Abra a página de um jogo<br>na Steam Store para<br>adicionar o jogo.</div>';
        }

        // ══ ABA 2: CORRIGIR ══════════════════════════════════════════════════
        const p2 = div(''); p2.className = 'gf-pane';

        if (isApp) {
            const s3 = div(''); s3.className = 'gf-sec';
            const s3ttl = div(''); s3ttl.className = 'gf-sec-ttl'; s3ttl.textContent = 'Fixes Disponíveis';
            const grid = div(''); grid.className = 'gf-fix-grid';
            grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:26px 0;color:rgba(255,255,255,.2);font-size:12px;display:flex;align-items:center;justify-content:center;gap:8px;"><span class="gf-spinner"></span>Verificando...</div>';
            s3.appendChild(s3ttl); s3.appendChild(grid);
            p2.appendChild(s3);

            call('CheckFixes', { appid: appid, game_name: gameName || '' }).then(function (res) {
                try {
                    const data = parseJson(res);
                    grid.innerHTML = '';
                    buildFixCards(grid, data, appid, o);
                } catch (_) {
                    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:24px 0;color:rgba(220,60,60,.55);font-size:12px;">Erro ao verificar.</div>';
                }
            }).catch(function () {
                grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:24px 0;color:rgba(220,60,60,.55);font-size:12px;">Sem conexão com os servidores.</div>';
            });

            // ── Botões de fix externos ────────────────────────────────────────
            p2.appendChild(div('gf-divider'));
            var secExtFix = div(''); secExtFix.className = 'gf-sec';
            var secExtTitle = div(''); secExtTitle.className = 'gf-sec-ttl'; secExtTitle.textContent = 'Fixes Externos';
            var extDesc = div('font-size:11px;color:rgba(255,255,255,.32);line-height:1.55;margin-bottom:12px;');
            extDesc.textContent = 'Para jogos não suportados pelos servidores acima, você pode buscar manualmente nesses sites:';
            secExtFix.appendChild(secExtTitle);
            secExtFix.appendChild(extDesc);

            function extFixBtn(label, sub, url, color) {
                var btn = div('');
                btn.style.cssText = 'display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);cursor:pointer;transition:all .14s;margin-bottom:8px;';
                var ico = div('width:34px;height:34px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:16px;');
                ico.style.background = color;
                ico.textContent = '🔗';
                var txt = div('flex:1;');
                txt.innerHTML = '<div style="font-size:13px;font-weight:700;color:#fff;">' + label + '</div>' +
                    '<div style="font-size:10px;color:rgba(255,255,255,.3);margin-top:1px;">' + sub + '</div>';
                var arr = div('font-size:16px;color:rgba(255,255,255,.15);');
                arr.textContent = '↗';
                btn.appendChild(ico); btn.appendChild(txt); btn.appendChild(arr);
                btn.onmouseover = function () { this.style.background = 'rgba(255,255,255,.07)'; this.style.borderColor = 'rgba(255,255,255,.14)'; arr.style.color = 'rgba(255,255,255,.4)'; };
                btn.onmouseout  = function () { this.style.background = 'rgba(255,255,255,.04)'; this.style.borderColor = 'rgba(255,255,255,.07)'; arr.style.color = 'rgba(255,255,255,.15)'; };
                btn.onclick = function () {
                    // Abre no navegador externo da pessoa (não no browser da Steam)
                    try {
                        if (window.SteamClient && window.SteamClient.System && window.SteamClient.System.OpenLocalURL) {
                            window.SteamClient.System.OpenLocalURL(url);
                        } else {
                            window.open('steam://openurl/' + url, '_self');
                        }
                    } catch (_) {
                        try { window.open('steam://openurl/' + url, '_self'); } catch (__) {}
                    }
                };
                return btn;
            }

            secExtFix.appendChild(extFixBtn('Online Fix', 'online-fix.me — fixes multiplayer e online', 'https://online-fix.me', 'rgba(60,120,255,.15)'));
            secExtFix.appendChild(extFixBtn('Ryuu Fix', 'generator.ryuu.lol/fixes — gerador de fixes', 'https://generator.ryuu.lol/fixes', 'rgba(180,60,220,.15)'));
            p2.appendChild(secExtFix);

            // Avisos de franquia movidos para aba Adicionar (p1)

            // ── Botão Remover, Fixar e Reparar ─────────────────────────────
            p2.appendChild(div('gf-divider'));
            const sRepair = div(''); sRepair.className = 'gf-sec';
            const sRepairTtl = div(''); sRepairTtl.className = 'gf-sec-ttl'; sRepairTtl.textContent = 'Remover Fix';
            sRepair.appendChild(sRepairTtl);

            const repairBtn = el('button');
            repairBtn.style.cssText =
                'width:100%;padding:13px 0;border-radius:10px;' +
                'background:rgba(255,140,0,.08);border:1px solid rgba(255,140,0,.22);' +
                'color:rgba(255,160,0,.85);font-size:11px;font-weight:800;letter-spacing:1px;' +
                'text-transform:uppercase;cursor:pointer;transition:all .14s;display:flex;' +
                'align-items:center;justify-content:center;gap:8px;';
            repairBtn.innerHTML = '<span style="font-size:14px;">🔧</span><span>Remover Fix</span>';
            repairBtn.onmouseover = function () {
                this.style.background = 'rgba(255,140,0,.15)';
                this.style.borderColor = 'rgba(255,160,0,.4)';
                this.style.color = 'rgba(255,180,0,.95)';
            };
            repairBtn.onmouseout = function () {
                this.style.background = 'rgba(255,140,0,.08)';
                this.style.borderColor = 'rgba(255,140,0,.22)';
                this.style.color = 'rgba(255,160,0,.85)';
            };
            repairBtn.onclick = function () {
                showConfirm(
                    'Remover Fix de "' + (gameName || 'este jogo') + '"?\n\n' +
                    'Os arquivos do fix serão removidos e a Steam iniciará a verificação de integridade automaticamente.',
                    function () {
                        repairBtn.disabled = true;
                        repairBtn.style.opacity = '0.5';
                        repairBtn.innerHTML = '<span class="gf-spinner" style="width:13px;height:13px;border-width:2px;"></span><span>Removendo...</span>';
                        Promise.all([
                            call('RemoveFix', { appid: appid }),
                            call('DeleteLuaForApp', { appid: appid })
                        ]).then(function (results) {
                            try {
                                var d = parseJson(results[0]);
                                var luaD = parseJson(results[1]);
                                var parts = [];
                                if (d && d.count > 0) parts.push(d.count + ' arquivo(s) de fix removido(s)');
                                if (luaD && luaD.count > 0) parts.push(luaD.count + ' arquivo(s) de jogo removido(s)');
                                var msg = parts.length > 0 ? parts.join(', ') + '.' : 'Nenhum arquivo encontrado.';
                                // Abre verificação de integridade diretamente — mesmo jeito que o LuaTools faz
                                try { window.location.href = 'steam://validate/' + appid; } catch (_) {}
                                showAlert(msg + '\n\nA verificação de integridade foi iniciada na Steam.');
                            } catch (_) {
                                try { window.location.href = 'steam://validate/' + appid; } catch (__) {}
                                showAlert('Verificação de integridade iniciada na Steam.');
                            }
                            repairBtn.disabled = false;
                            repairBtn.style.opacity = '';
                            repairBtn.innerHTML = '<span style="font-size:14px;">🔧</span><span>Remover Fix</span>';
                        }).catch(function () {
                            try { window.location.href = 'steam://validate/' + appid; } catch (_) {}
                            showAlert('Verificação de integridade iniciada na Steam.');
                            repairBtn.disabled = false;
                            repairBtn.style.opacity = '';
                            repairBtn.innerHTML = '<span style="font-size:14px;">🔧</span><span>Remover Fix</span>';
                        });
                    },
                    'Confirmar'
                );
            };
            sRepair.appendChild(repairBtn);
            p2.appendChild(sRepair);

        } else {
            p2.innerHTML = '<div class="gf-empty">Abra a página de um jogo<br>para ver os fixes disponíveis.</div>';
        }

        // ══ ABA 3: GERENCIAR ═════════════════════════════════════════════════
        const p3 = div(''); p3.className = 'gf-pane';

        function actRow(bg, icon, name, sub, onClick) {
            const r = div(''); r.className = 'gf-act';
            const ic = div(''); ic.className = 'gf-act-ico'; ic.style.background = bg; ic.textContent = icon;
            const tx = div('flex:1;');
            tx.innerHTML = '<div class="gf-act-name">' + name + '</div><div class="gf-act-sub">' + sub + '</div>';
            const ch = div(''); ch.className = 'gf-act-chev'; ch.textContent = '›';
            r.appendChild(ic); r.appendChild(tx); r.appendChild(ch);
            r.onclick = onClick;
            return r;
        }

        const s4 = div(''); s4.className = 'gf-sec';
        const s4ttl = div(''); s4ttl.className = 'gf-sec-ttl'; s4ttl.textContent = 'Ferramentas';
        s4.appendChild(s4ttl);
        if (isApp) {
            s4.appendChild(actRow('rgba(220,0,0,.1)', '⬇', 'Adicionar jogo', 'Buscar e instalar via servidores', function () {
                o.remove(); showDownloadPopup(appid, gameName);
            }));
        }
        s4.appendChild(actRow('rgba(255,200,0,.1)', '↺', 'Reiniciar Steam', 'Aplicar alterações pendentes', function () {
            showConfirm('Deseja reiniciar o Steam agora?', function () { call('RestartSteam'); });
        }));
        s4.appendChild(actRow('rgba(60,130,255,.1)', '⟳', 'Atualizar Servidores', 'Busca e atualiza a lista de servidores disponíveis', function () {
            const btn = this;
            btn.style.opacity = '0.5'; btn.style.pointerEvents = 'none';
            call('FetchFreeApisNow').then(function (res) {
                btn.style.opacity = ''; btn.style.pointerEvents = '';
                try {
                    var d = parseJson(res);
                    if (d && d.success) {
                        showAlert('Servidores atualizados! ' + (d.count || 0) + ' servidor(es) disponível(is).');
                    } else {
                        showAlert('Falha ao atualizar servidores: ' + (d && d.error ? d.error : 'erro desconhecido'));
                    }
                } catch (_) { showAlert('Erro ao processar resposta dos servidores.'); }
            }).catch(function () {
                btn.style.opacity = ''; btn.style.pointerEvents = '';
                showAlert('Sem conexão com os servidores. Tente novamente.');
            });
        }));
        if (isApp) {
            s4.appendChild(actRow('rgba(220,60,60,.1)', '🗑', 'Remover jogo da biblioteca', 'Remove o jogo adicionado pelo plugin', function () {
                showConfirm(
                    'Remover "' + (gameName || 'este jogo') + '" da biblioteca?\n\nO jogo será desvinculado da sua conta Steam.',
                    function () {
                        call('DeleteLuaForApp', { appid: appid }).then(function (res) {
                            try {
                                var d = parseJson(res);
                                if (d && d.success && d.count > 0) {
                                    showConfirm('Jogo removido da biblioteca.\n\nReinicie a Steam para aplicar as alterações.', function () {
                                        call('RestartSteam', { appid: 0 });
                                    }, 'Reiniciar Steam');
                                } else if (d && d.success) {
                                    showAlert('Nenhum arquivo encontrado para este jogo.');
                                } else {
                                    showAlert('Não foi possível remover: ' + (d && d.error ? d.error : 'erro desconhecido'));
                                }
                            } catch (_) {
                                showAlert('Ocorreu um erro ao remover o jogo.');
                            }
                        }).catch(function () {
                            showAlert('Sem conexão com o backend. Tente novamente.');
                        });
                    },
                    'Remover'
                );
            }));
        }
        p3.appendChild(s4);

        p3.appendChild(div('gf-divider'));

        // Info do plugin na aba Gerenciar
        const s4b = div(''); s4b.className = 'gf-sec';
        const s4bttl = div(''); s4bttl.className = 'gf-sec-ttl'; s4bttl.textContent = 'Informações';
        const infoGrid2 = div(''); infoGrid2.className = 'gf-stat-grid';
        function infoCard(lbl, val, col) {
            const c = div(''); c.className = 'gf-stat-card';
            const l = div(''); l.className = 'gf-stat-lbl'; l.textContent = lbl;
            const v = div(''); v.className = 'gf-stat-val'; v.style.color = col || 'rgba(255,255,255,.6)'; v.textContent = val;
            c.appendChild(l); c.appendChild(v); return c;
        }
        infoGrid2.appendChild(infoCard('Versão', 'v' + PLUGIN_VERSION));
        infoGrid2.appendChild(infoCard('Idioma', 'PT-BR'));
        s4b.appendChild(s4bttl); s4b.appendChild(infoGrid2);
        p3.appendChild(s4b);

        // Aba Config removida — informações movidas para Gerenciar

        // ── Montar estrutura ─────────────────────────────────────────────────
        paneArea.appendChild(p1);
        paneArea.appendChild(p2);
        paneArea.appendChild(p3);

        // ── Tab bar inferior ─────────────────────────────────────────────────
        const tabBar = div(''); tabBar.className = 'gf-tabbar';

        const tabDefs = [
            { icon: '＋', label: 'Adicionar', pane: p1 },
            { icon: '🛠', label: 'Corrigir',  pane: p2 },
            { icon: '⚙', label: 'Gerenciar', pane: p3 },
        ];

        tabDefs.forEach(function (td, i) {
            const tab = div(''); tab.className = 'gf-tab';
            tab.innerHTML = '<div class="gf-tab-icon">' + td.icon + '</div><div>' + td.label + '</div>';
            if (i === 0) tab.classList.add('on');
            tab.onclick = function () {
                $$('.gf-tab', tabBar).forEach(function (t) { t.classList.remove('on'); });
                [p1, p2, p3].forEach(function (p) { p.classList.remove('on'); });
                tab.classList.add('on');
                td.pane.classList.add('on');
            };
            tabBar.appendChild(tab);
        });

        m.appendChild(paneArea);
        m.appendChild(tabBar);
        o.appendChild(m);
        document.body.appendChild(o);
        o.addEventListener('click', function (e) { if (e.target === o) o.remove(); });
    }

    // ── Botão injetado ─────────────────────────────────────────────────────────
    var _lu = '', _hdrIns = false;

    function injectButton() {
        const url = window.location.href;
        if (url !== _lu) { _lu = url; _hdrIns = false; }

        injectStyles();

        // ── Botão no header (em QUALQUER página, igual ao LuaTools) ──────────
        // Container: ._1wn1lBlAzl3HMRqS1llwie — barra de topo da Steam Store
        if (!_hdrIns) {
            const hdrContainer = document.querySelector('._1wn1lBlAzl3HMRqS1llwie');
            if (hdrContainer && !document.querySelector('.gf-hdr-btn')) {
                _hdrIns = true;

                const hdrBtn = document.createElement('a');
                hdrBtn.href = '#';
                hdrBtn.className = 'gf-hdr-btn';

                // Botão com nome completo do plugin visível
                hdrBtn.innerHTML =
                    '<span style="font-size:11px;font-weight:900;letter-spacing:.4px;' +
                    'color:#fff;text-shadow:0 1px 4px rgba(0,0,0,.5);white-space:nowrap;">' +
                    PLUGIN_NAME + '</span>';

                // Match altura e alinhamento dos outros botões do header Steam
                var hdrParentH = hdrBtn.parentElement ? hdrBtn.parentElement.offsetHeight : 0;
                hdrBtn.style.cssText =
                    'position:relative;display:inline-flex;align-items:center;justify-content:center;' +
                    'padding:0 14px;height:36px;border-radius:6px;cursor:pointer;flex-shrink:0;' +
                    'background:linear-gradient(135deg,#dc0000,#8b0000);' +
                    'border:1px solid rgba(255,255,255,.12);' +
                    'box-shadow:0 2px 10px rgba(220,0,0,.4);' +
                    'transition:all .15s;text-decoration:none;' +
                    'align-self:center;margin-top:0;line-height:1;';

                hdrBtn.onmouseover = function () {
                    this.style.background = 'linear-gradient(135deg,#f50000,#a00000)';
                    this.style.boxShadow = '0 4px 20px rgba(220,0,0,.7),0 2px 6px rgba(0,0,0,.5)';
                    this.style.transform = 'translateY(-1px)';
                };
                hdrBtn.onmouseout = function () {
                    this.style.background = 'linear-gradient(135deg,#dc0000,#8b0000)';
                    this.style.boxShadow = '0 2px 12px rgba(220,0,0,.45),0 1px 3px rgba(0,0,0,.4)';
                    this.style.transform = 'none';
                };
                hdrBtn.onclick = function (e) {
                    e.preventDefault();
                    showMainMenu(getAppId(), getGameName());
                };

                // Centraliza no container: insere como primeiro filho
                // O container usa flex row; inserindo antes dos outros filhos
                // e com margin:auto ele fica visualmente centrado
                hdrContainer.insertBefore(hdrBtn, hdrContainer.firstChild);
            }
        }


    }

    // ── Init ───────────────────────────────────────────────────────────────────
    function init() {
        injectStyles(); injectButton();
        const obs = new MutationObserver(function () { injectButton(); });
        obs.observe(document.body, { childList: true, subtree: true });
        setTimeout(injectButton, 1000);
        setTimeout(injectButton, 3000);
        setTimeout(injectButton, 6000);
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();

})();
