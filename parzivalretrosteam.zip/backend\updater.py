"""Auto-updater do ParzivalRetroSteam via GitHub Releases."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import threading
import zipfile
from typing import Optional

from config import (
    PLUGIN_VERSION,
    GITHUB_REPO,
    GITHUB_API_RELEASES,
    HTTP_TIMEOUT,
    WEBKIT_DIR_NAME,
    WEB_UI_JS_FILE,
    WEB_UI_ICON_FILE,
    RELEASE_CHECKSUMS,
)
from http_client import get_client
from logger import logger
from paths import plugin_dir, public_path
from steam_utils import restart_steam

# ── Estado interno ────────────────────────────────────────────────────────────

_state: dict = {
    "checking": False,
    "updating": False,
    "update_available": False,
    "latest_version": None,
    "update_applied": False,
    "error": None,
}
_lock = threading.Lock()


def get_update_status() -> str:
    with _lock:
        return json.dumps(_state.copy())


# ── Comparação de versão ──────────────────────────────────────────────────────

def _parse_version(v: str) -> tuple:
    v = v.lstrip("v").strip()
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def _is_newer(remote: str, local: str) -> bool:
    return _parse_version(remote) > _parse_version(local)


# ── Busca a última release no GitHub ─────────────────────────────────────────

def _fetch_latest_release() -> Optional[dict]:
    try:
        client = get_client()
        resp = client.get(GITHUB_API_RELEASES, timeout=HTTP_TIMEOUT)
        resp.raise_for_status()
        releases = resp.json()
        if not releases:
            return None
        for rel in releases:
            if not rel.get("draft") and not rel.get("prerelease"):
                return rel
        return releases[0]
    except Exception as e:
        logger.warn(f"Updater: erro ao buscar releases: {e}")
        return None


def _find_zip_asset(release: dict) -> Optional[str]:
    assets = release.get("assets", [])
    for asset in assets:
        name: str = asset.get("name", "")
        if name.endswith(".zip"):
            return asset.get("browser_download_url")
    return release.get("zipball_url")


# ── Download + substituição de arquivos ──────────────────────────────────────

def _apply_update(zip_url: str, tag: str, steam_path: str) -> bool:
    """Baixa o zip e substitui os arquivos. steam_path passado pelo main.py."""
    plugin_root = plugin_dir()

    try:
        logger.log(f"Updater: baixando {zip_url} ...")
        client = get_client()
        resp = client.get(zip_url, timeout=60)
        resp.raise_for_status()

        zip_bytes = resp.content

        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
            tmp.write(zip_bytes)
            tmp_path = tmp.name

        # ── SHA-256 verification ──────────────────────────────────────────────
        sha256 = hashlib.sha256(zip_bytes).hexdigest()
        expected = RELEASE_CHECKSUMS.get(tag)
        if expected is not None:
            if sha256 != expected:
                logger.warn(f"Updater: SHA-256 mismatch para {tag} — abortando.")
                logger.warn(f"Updater: esperado={expected[:16]}..., recebido={sha256[:16]}...")
                os.unlink(tmp_path)
                return False
            logger.log(f"Updater: SHA-256 verificado OK para {tag}")
        else:
            logger.warn(f"Updater: sem checksum cadastrado para {tag} — prosseguindo sem verificação.")

        logger.log(f"Updater: extraindo update para {plugin_root} ...")

        with zipfile.ZipFile(tmp_path, "r") as zf:
            names = zf.namelist()

            prefix = ""
            if names:
                first = names[0]
                if "/" in first:
                    candidate = first.split("/")[0] + "/"
                    if all(n.startswith(candidate) for n in names):
                        prefix = candidate

            for member in names:
                rel_path = member[len(prefix):]
                if not rel_path:
                    continue

                dest = os.path.join(plugin_root, rel_path)

                if member.endswith("/"):
                    os.makedirs(dest, exist_ok=True)
                    continue

                protected = ["backend/data/"]
                if any(rel_path.startswith(p) for p in protected):
                    logger.log(f"Updater: preservando {rel_path}")
                    continue

                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with zf.open(member) as src, open(dest, "wb") as dst:
                    shutil.copyfileobj(src, dst)

        os.unlink(tmp_path)
        logger.log(f"Updater: plugin atualizado para {tag} com sucesso!")

        # Copia JS para steamui usando o steam_path recebido do main.py
        # (sem importar Millennium aqui, evita crash na thread)
        try:
            steam_ui_dir = os.path.join(steam_path, "steamui", WEBKIT_DIR_NAME)
            os.makedirs(steam_ui_dir, exist_ok=True)
            js_src = public_path(WEB_UI_JS_FILE)
            if os.path.exists(js_src):
                shutil.copy(js_src, os.path.join(steam_ui_dir, WEB_UI_JS_FILE))
                logger.log("Updater: JS copiado para steamui apos update.")
            icon_src = public_path(WEB_UI_ICON_FILE)
            if os.path.exists(icon_src):
                shutil.copy(icon_src, os.path.join(steam_ui_dir, WEB_UI_ICON_FILE))
        except Exception as e:
            logger.warn(f"Updater: nao foi possivel copiar JS para steamui: {e}")

        # Salva info do update para mostrar changelog na proxima inicializacao
        try:
            update_info_path = os.path.join(plugin_root, "backend", "data", "last_update.json")
            os.makedirs(os.path.dirname(update_info_path), exist_ok=True)
            with open(update_info_path, "w", encoding="utf-8") as f:
                json.dump({"previous_version": PLUGIN_VERSION, "new_version": tag}, f)
        except Exception as e:
            logger.warn(f"Updater: falha ao salvar info de update: {e}")

        return True

    except Exception as e:
        logger.warn(f"Updater: falha ao aplicar update: {e}")
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
        return False


# ── Ponto de entrada público ──────────────────────────────────────────────────

def check_and_update(silent: bool = True, steam_path: str = "", force_restart: bool = True) -> threading.Thread:
    """Verifica e aplica updates em background. Retorna a thread para que o
    chamador possa dar .join() e esperar o update terminar antes de continuar.

    steam_path deve ser passado pelo main.py (Millennium.steam_path())
    para evitar importar Millennium dentro da thread.

    force_restart: se True (padrao), reinicia a Steam automaticamente
    assim que o update for aplicado com sucesso, sem perguntar ao usuario.
    """

    def _run() -> None:
        with _lock:
            if _state["checking"] or _state["updating"]:
                return
            _state["checking"] = True
            _state["error"] = None

        try:
            release = _fetch_latest_release()
            if release is None:
                with _lock:
                    _state["error"] = "Nao foi possivel contatar o GitHub."
                return

            tag = release.get("tag_name", "")
            with _lock:
                _state["latest_version"] = tag

            if not _is_newer(tag, PLUGIN_VERSION):
                logger.log(f"Updater: ja na versao mais recente ({PLUGIN_VERSION}).")
                with _lock:
                    _state["update_available"] = False
                return

            logger.log(f"Updater: update disponivel {PLUGIN_VERSION} -> {tag}")
            with _lock:
                _state["update_available"] = True

            zip_url = _find_zip_asset(release)
            if not zip_url:
                with _lock:
                    _state["error"] = "Release sem arquivo .zip para download."
                return

            with _lock:
                _state["updating"] = True

            ok = _apply_update(zip_url, tag, steam_path)

            with _lock:
                _state["updating"] = False
                _state["update_applied"] = ok
                if not ok:
                    _state["error"] = "Falha ao aplicar o update."

            if ok and force_restart:
                logger.log("Updater: reiniciando a Steam automaticamente apos update...")
                restart_steam()

        finally:
            with _lock:
                _state["checking"] = False

    t = threading.Thread(target=_run, name="parz-updater", daemon=True)
    t.start()
    return t
