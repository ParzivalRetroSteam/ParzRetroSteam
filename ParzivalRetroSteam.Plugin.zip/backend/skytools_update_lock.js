// ParzivalRetroSteam game update lock editor for Windows Script Host.
(function () {
  var fso = new ActiveXObject("Scripting.FileSystemObject");

  function arg(index) {
    return WScript.Arguments.length > index ? String(WScript.Arguments.Item(index)) : "";
  }

  function ensureDir(path) {
    if (!path || fso.FolderExists(path)) return;
    var parent = fso.GetParentFolderName(path);
    if (parent && !fso.FolderExists(parent)) ensureDir(parent);
    if (!fso.FolderExists(path)) fso.CreateFolder(path);
  }

  function readTextWithCharset(path, charset) {
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = charset;
    stream.Open();
    stream.LoadFromFile(path);
    var text = stream.ReadText();
    stream.Close();
    return text;
  }

  function readText(path) {
    var charsets = ["utf-8", "windows-1252", "unicode"];
    for (var i = 0; i < charsets.length; i += 1) {
      try {
        return readTextWithCharset(path, charsets[i]);
      } catch (_) {
      }
    }
    var file = fso.OpenTextFile(path, 1, false);
    var text = file.ReadAll();
    file.Close();
    return text;
  }

  function writeUtf8NoBom(path, text) {
    ensureDir(fso.GetParentFolderName(path));
    var textStream = new ActiveXObject("ADODB.Stream");
    textStream.Type = 2;
    textStream.Charset = "utf-8";
    textStream.Open();
    textStream.WriteText(String(text || ""));
    textStream.Position = 0;
    textStream.Type = 1;
    if (textStream.Size >= 3) textStream.Position = 3;

    var binaryStream = new ActiveXObject("ADODB.Stream");
    binaryStream.Type = 1;
    binaryStream.Open();
    textStream.CopyTo(binaryStream);
    binaryStream.SaveToFile(path, 2);
    binaryStream.Close();
    textStream.Close();
  }

  function writeResult(path, success, data, error) {
    ensureDir(fso.GetParentFolderName(path));
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = "utf-8";
    stream.Open();
    stream.WriteText("{"
      + "\"success\":" + (success ? "true" : "false") + ","
      + "\"data\":" + (data || "{}") + ","
      + "\"error\":\"" + jsonEscape(error || "") + "\""
      + "}");
    stream.SaveToFile(path, 2);
    stream.Close();
  }

  function jsonEscape(value) {
    return String(value == null ? "" : value)
      .replace(/\\/g, "\\\\")
      .replace(/"/g, "\\\"")
      .replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\t/g, "\\t");
  }

  function escapeRegex(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function stripLuaComments(text) {
    text = String(text || "").replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, "");
    return text.replace(/--[^\r\n]*/g, "");
  }

  function hasActiveManifest(text, depotId) {
    var clean = stripLuaComments(text);
    var pattern = new RegExp("setmanifestid\\s*\\(\\s*" + escapeRegex(depotId) + "\\s*,", "i");
    return pattern.test(clean);
  }

  function appendLuaLine(text, line, newline) {
    var output = String(text || "");
    if (output.length > 0 && !/[\r\n]$/.test(output)) {
      output += newline;
    }
    return output + line + newline;
  }

  function insertManifestAfterDepotKey(lines, depotId, manifestId) {
    var escapedId = escapeRegex(depotId);
    var activeKeyPattern = new RegExp(
      "^\\s*addappid\\s*\\(\\s*" + escapedId + "\\s*,[^\\r\\n)]*,\\s*[\"'][^\"']+[\"']",
      "i"
    );
    var commentedKeyPattern = new RegExp(
      "^\\s*--\\s*addappid\\s*\\(\\s*" + escapedId + "\\s*,[^\\r\\n)]*,\\s*[\"'][^\"']+[\"']",
      "i"
    );
    var fallbackPattern = new RegExp(
      "^\\s*(?:--\\s*)?addappid\\s*\\(\\s*" + escapedId + "(?:\\s*[,\\)])",
      "i"
    );
    var insertionIndex = -1;
    var fallbackIndex = -1;
    for (var i = 0; i < lines.length; i += 1) {
      if (activeKeyPattern.test(lines[i])) {
        insertionIndex = i;
        break;
      }
      if (insertionIndex < 0 && commentedKeyPattern.test(lines[i])) {
        insertionIndex = i;
      }
      if (fallbackIndex < 0 && fallbackPattern.test(lines[i])) {
        fallbackIndex = i;
      }
    }
    if (insertionIndex < 0) insertionIndex = fallbackIndex;
    if (insertionIndex < 0) return false;

    var indent = (lines[insertionIndex].match(/^(\s*)/) || ["", ""])[1];
    lines.splice(insertionIndex + 1, 0, indent + 'setManifestid(' + depotId + ', "' + manifestId + '")');
    return true;
  }

  function splitInlineManifestLines(lines, depotId) {
    var changed = false;
    var pattern = new RegExp("^(.*?\\))[ \\t]+(setmanifestid\\s*\\(\\s*" + escapeRegex(depotId) + "\\s*,.*)$", "i");
    for (var i = 0; i < lines.length; i += 1) {
      var match = lines[i].match(pattern);
      if (!match) continue;
      lines[i] = match[1];
      lines.splice(i + 1, 0, match[2]);
      changed = true;
      i += 1;
    }
    return changed;
  }

  var resultPath = arg(0);
  var scriptPath = arg(1);
  var requestedLocked = arg(2).toLowerCase() === "true";
  var depotId = arg(3);
  var manifestId = arg(4);

  try {
    if (!resultPath) throw new Error("Caminho de resultado ausente.");
    if (!scriptPath || !fso.FileExists(scriptPath)) throw new Error("Arquivo Lua do jogo não encontrado.");
    if (!/^\d+$/.test(depotId)) throw new Error("DepotID inválido.");
    if (!/^\d+$/.test(manifestId)) throw new Error("ManifestID inválido.");

    var original = readText(scriptPath);
    var newline = original.indexOf("\r\n") >= 0 ? "\r\n" : "\n";
    var lines = original.split(/\r\n|\n|\r/);
    var activePattern = new RegExp("^(\\s*)setmanifestid\\s*\\(\\s*" + escapeRegex(depotId) + "\\s*,[^\\r\\n]*$", "i");
    var commentedPattern = new RegExp("^(\\s*)--\\s*setmanifestid\\s*\\(\\s*" + escapeRegex(depotId) + "\\s*,[^\\r\\n]*$", "i");
    var replacement = 'setManifestid(' + depotId + ', "' + manifestId + '")';
    var changed = splitInlineManifestLines(lines, depotId);
    var found = false;

    for (var i = 0; i < lines.length; i += 1) {
      var active = lines[i].match(activePattern);
      var commented = lines[i].match(commentedPattern);
      if (requestedLocked && (active || commented)) {
        if (commented) {
          var indent = commented[1] || "";
          var uncommented = lines[i].slice(indent.length + 2);
          if (/^[ \t]/.test(uncommented)) uncommented = uncommented.slice(1);
          lines[i] = indent + uncommented;
          changed = true;
        }
        found = true;
      } else if (!requestedLocked && active) {
        lines[i] = active[1] + "-- " + lines[i].slice(active[1].length);
        changed = true;
        found = true;
      }
    }

    if (requestedLocked && !found) {
      if (insertManifestAfterDepotKey(lines, depotId, manifestId)) {
        original = lines.join(newline);
      } else {
        original = appendLuaLine(lines.join(newline), replacement, newline);
      }
      changed = true;
    } else {
      original = lines.join(newline);
    }

    if (changed) writeUtf8NoBom(scriptPath, original);
    var locked = hasActiveManifest(readText(scriptPath), depotId);
    if (locked !== requestedLocked) {
      throw new Error("A alteração do bloqueio não foi confirmada no arquivo Lua.");
    }

    writeResult(resultPath, true, "{"
      + "\"locked\":" + (locked ? "true" : "false") + ","
      + "\"changed\":" + (changed ? "true" : "false") + ","
      + "\"depotId\":\"" + depotId + "\","
      + "\"manifestId\":\"" + manifestId + "\""
      + "}", "");
  } catch (error) {
    writeResult(resultPath, false, "{}", error && error.message ? error.message : String(error));
  }
})();
