local config = {
    PLUGIN_NAME         = "Parzival Retrô Steam",
    PLUGIN_VERSION      = "1.2",
    WEBKIT_DIR_NAME     = "ParzivalRetroSteam",
    WEB_UI_JS_FILE      = "gamefixer.js",
    WEB_UI_ICON_FILE    = "gamefixer-icon.png",
    API_JSON_FILE       = "api.json",
    API_MANIFEST_URL    = "https://raw.githubusercontent.com/madoiscool/lt_api_links/refs/heads/main/load_free_manifest_apis",
    API_MANIFEST_PROXY  = "https://luatools.vercel.app/load_free_manifest_apis",
    FIXES_INDEX_URL     = "https://index.luatools.work/fixes-index.json",
    GENERIC_FIX_BASE    = "https://files.luatools.work/GameBypasses/%d.zip",
    ONLINE_FIX_BASE     = "https://files.luatools.work/OnlineFix1/%d.zip",
    HTTP_TIMEOUT_SECONDS = 15,
    USER_AGENT          = "discord(dot)gg/luatools",
    LOADED_APPS_FILE    = "loadedappids.txt",
}
return config
