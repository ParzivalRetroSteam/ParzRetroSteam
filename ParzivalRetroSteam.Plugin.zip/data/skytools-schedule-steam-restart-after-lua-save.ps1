$ErrorActionPreference = 'Stop'
$LogPath = 'c:/program files (x86)/steam\millennium/plugins\ParzivalRetroSteam.Plugin\data\skytools-steam-restart.log'
$TaskName = 'SkyTools.RestartSteamAfterLuaSave'
$RestartScript = 'c:/program files (x86)/steam\millennium/plugins\ParzivalRetroSteam.Plugin\data\skytools-restart-steam-after-lua-save.ps1'
function Write-RestartLog([string]$Message) {
  try { Add-Content -LiteralPath $LogPath -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Message) -Encoding UTF8 } catch {}
}
try {
  $ActionArguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $RestartScript + '"'
  $Action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $ActionArguments
  $Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddHours(1)
  $Principal = New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
  Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Force | Out-Null
  Start-ScheduledTask -TaskName $TaskName
  Write-RestartLog 'Tarefa destacada registrada e iniciada.'
} catch {
  Write-RestartLog ('Falha ao agendar reinício: ' + $_.Exception.Message)
  throw
}