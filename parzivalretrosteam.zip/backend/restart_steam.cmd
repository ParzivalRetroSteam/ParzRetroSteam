@echo off
setlocal enableextensions enabledelayedexpansion

rem ── Resolver path do Steam via registro ──────────────────────────────────────
set "STEAM_EXE="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamExe 2^>nul ^| find "SteamExe"') do set "STEAM_EXE=%%B"

if not defined STEAM_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| find "SteamPath"') do set "STEAM_DIR=%%B"
    if defined STEAM_DIR set "STEAM_EXE=!STEAM_DIR!\steam.exe"
)

if not defined STEAM_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKLM\SOFTWARE\WOW6432Node\Valve\Steam" /v InstallPath 2^>nul ^| find "InstallPath"') do set "STEAM_DIR=%%B"
    if defined STEAM_DIR set "STEAM_EXE=!STEAM_DIR!\steam.exe"
)

rem ── Appid opcional pra auto-instalar após reinício ───────────────────────────
set "AUTO_APPID=%~1"

rem ── Matar TODOS os processos do Steam ────────────────────────────────────────
taskkill /IM steam.exe        /F >nul 2>&1
taskkill /IM steamwebhelper.exe /F >nul 2>&1
taskkill /IM steamservice.exe   /F >nul 2>&1
taskkill /IM GameOverlayUI.exe  /F >nul 2>&1

rem ── Aguardar até todos os processos morrerem de verdade (até 15s) ────────────
set /a tries=0
:waitloop
tasklist /FI "IMAGENAME eq steam.exe" 2>nul | find /I "steam.exe" >nul 2>&1
if not errorlevel 1 (
    set /a tries+=1
    if !tries! lss 15 (
        timeout /t 1 /nobreak >nul
        goto waitloop
    )
)

rem ── Pequena pausa extra pra liberar handles de arquivo ───────────────────────
timeout /t 2 /nobreak >nul

rem ── Abrir o Steam ────────────────────────────────────────────────────────────
if defined STEAM_EXE (
    if exist "!STEAM_EXE!" (
        start "" "!STEAM_EXE!"
    ) else (
        start "" steam.exe
    )
) else (
    start "" steam.exe
)

rem ── Aguardar Steam carregar antes de abrir URLs ──────────────────────────────
timeout /t 12 /nobreak >nul

rem ── Auto-instalar appid se solicitado ────────────────────────────────────────
if defined AUTO_APPID (
    if not "!AUTO_APPID!"=="0" (
        start "" "steam://install/!AUTO_APPID!"
    )
)

exit
