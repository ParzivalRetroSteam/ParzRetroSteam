-- downloads.lua — Parzival Retrô Steam
-- Usa o mesmo padrão do LuaTools: PowerShell/bash assíncrono para download
local m_utils     = require("utils")
local fs          = require("fs")
local http_client = require("http_client")
local config      = require("config")
local logger      = require("plugin_logger")
local paths       = require("paths")
local steam_utils = require("steam_utils")
local utils       = require("plugin_utils")
local cjson       = require("json")

local downloads = {}
local DOWNLOAD_STATE = {}

local function _set(appid, update)
    appid = tonumber(appid)
    if not DOWNLOAD_STATE[appid] then DOWNLOAD_STATE[appid] = {} end
    for k, v in pairs(update) do DOWNLOAD_STATE[appid][k] = v end
end

local function _get(appid)
    appid = tonumber(appid)
    local state = DOWNLOAD_STATE[appid] or {}
    local copy = {}
    for k, v in pairs(state) do copy[k] = v end
    return copy
end

-- ── Carregar APIs ─────────────────────────────────────────────────────────────
local DEFAULT_APIS = {
    {name="SkyApi",         url="https://github.com/skyflarefox/Skyapi/raw/refs/heads/main/<appid>.zip",           success_code=200, unavailable_code=404, enabled=true},
    {name="Ryuu",           url="http://167.235.229.108/<appid>",                                                  success_code=200, unavailable_code=404, enabled=true},
    {name="Ryuu Generator", url="https://generator.ryuu.lol/fixes/<appid>.zip",                                   success_code=200, unavailable_code=404, enabled=true},
    {name="TwentyTwo Cloud",url="https://twentytwocloud.com/secure_download?auth=1771526723_73652ce834428eea993e88dd1ccbe5be_442b8efb5c05f1bf8ea5ca46&appid=<appid>", success_code=200, unavailable_code=404, enabled=true},
    {name="Sushi",          url="https://raw.githubusercontent.com/sushi-dev55-alt/sushitools-games-repo-alt/refs/heads/main/<appid>.zip", success_code=200, unavailable_code=404, enabled=true},
    {name="Online Fix",     url="https://online-fix.me/steam/<appid>.zip",                                        success_code=200, unavailable_code=404, enabled=true},
    {name="Morrenus",       url="https://manifest.morrenus.xyz/api/v1/manifest/<appid>?api_key=<moapikey>",        success_code=200, unavailable_code=404, enabled=true},
}

local function load_apis()
    local api_file = paths.backend_path(config.API_JSON_FILE)
    if fs.exists(api_file) then
        local content = m_utils.read_file(api_file) or ""
        if content ~= "" then
            local ok, data = pcall(cjson.decode, content)
            if ok and data and data.api_list and #data.api_list > 0 then
                local enabled = {}
                for _, api in ipairs(data.api_list) do
                    if api.enabled ~= false then table.insert(enabled, api) end
                end
                return enabled
            end
        end
    end
    return DEFAULT_APIS
end

-- ── Async download via script externo (igual ao LuaTools) ────────────────────
local function launch_async_download(appid, url, dest_path, extract_dir, state_file)
    local is_windows = (m_utils.getenv("OS") or ""):find("Windows") ~= nil
    if not fs.exists(extract_dir) then fs.create_directories(extract_dir) end
    m_utils.write_file(state_file, '{"status": "downloading"}')

    if is_windows then
        local ps1 = fs.join(paths.get_plugin_dir(), "backend", "scripts", "downloader.ps1")
        local cmd = string.format(
            'powershell -WindowStyle Hidden -Command "Start-Process -FilePath powershell -WindowStyle Hidden -ArgumentList \'-ExecutionPolicy Bypass -File \\"%s\\" -Url \\"%s\\" -DestPath \\"%s\\" -ExtractDir \\"%s\\" -StateFile \\"%s\\"\'"',
            ps1, url, dest_path, extract_dir, state_file
        )
        m_utils.exec(cmd)
    else
        local sh = fs.join(paths.get_plugin_dir(), "backend", "scripts", "downloader.sh")
        m_utils.exec('chmod +x "' .. sh .. '"')
        local cmd = string.format(
            'nohup bash "%s" "%s" "%s" "%s" "%s" > /dev/null 2>&1 &',
            sh, url, dest_path, extract_dir, state_file
        )
        m_utils.exec(cmd)
    end
end

-- ── Finalizar instalação após download ───────────────────────────────────────
local function finalize_install(appid, extract_dir, dest_path, api_name)
    _set(appid, {status="processing"})
    local base = steam_utils.detect_steam_install_path()
    local stplug  = fs.join(base, "config", "stplug-in")
    local lua_dir = fs.join(base, "config", "lua")
    if not fs.exists(stplug)  then fs.create_directories(stplug)  end
    if not fs.exists(lua_dir) then fs.create_directories(lua_dir) end

    local target_lua = fs.join(stplug, tostring(appid) .. ".lua")
    local extracted_lua = nil

    local ok_list, files = pcall(fs.list_recursive, extract_dir)
    if ok_list and files then
        for _, entry in ipairs(files) do
            if not entry.is_directory then
                if entry.name == tostring(appid) .. ".lua" then
                    extracted_lua = entry.path
                elseif not extracted_lua and entry.name:match("^%d+%.lua$") then
                    extracted_lua = entry.path
                end
            end
        end
    end

    if extracted_lua and fs.exists(extracted_lua) then
        local text = m_utils.read_file(extracted_lua) or ""
        -- Salva em stplug-in
        m_utils.write_file(target_lua, text)
        -- Salva também em lua/
        m_utils.write_file(fs.join(lua_dir, tostring(appid) .. ".lua"), text)
        _set(appid, {installedPath=target_lua})
        logger.log("Instalado: " .. target_lua)
    end

    -- Registrar no loadedappids
    local loaded = paths.backend_path(config.LOADED_APPS_FILE)
    local existing = fs.exists(loaded) and (m_utils.read_file(loaded) or "") or ""
    m_utils.write_file(loaded, existing .. tostring(appid) .. "\n")

    pcall(fs.remove_all, extract_dir)
    pcall(fs.remove, dest_path)
    _set(appid, {status="done", success=true, api=api_name})
end

-- ── GetDownloadStatus — verifica state_file do script externo ────────────────
function downloads.get_add_status(appid)
    appid = tonumber(appid)
    local dest_root = utils.ensure_temp_download_dir()
    local state_file = fs.join(dest_root, tostring(appid) .. "_state.json")

    if fs.exists(state_file) then
        local content = m_utils.read_file(state_file) or ""
        local ok_p, data = pcall(cjson.decode, content)
        if ok_p and data and data.status then
            _set(appid, {status=data.status, error=data.error})
            if data.status == "extracted" then
                local dest_path  = fs.join(dest_root, tostring(appid) .. ".zip")
                local extract_dir = fs.join(dest_root, "extracted_" .. tostring(appid))
                local api_name   = _get(appid).currentApi or "Unknown"
                local ok_fin, e  = pcall(finalize_install, appid, extract_dir, dest_path, api_name)
                if not ok_fin then
                    _set(appid, {status="failed", error=tostring(e)})
                end
                pcall(fs.remove, state_file)
            elseif data.status == "failed" then
                pcall(fs.remove, state_file)
            end
        end
    end

    return {success=true, state=_get(appid)}
end

-- ── StartDownload ─────────────────────────────────────────────────────────────
function downloads.start_download(appid, game_name)
    appid = tonumber(appid)
    if not appid then return {success=false, error="appid inválido"} end

    _set(appid, {status="queued", gameName=game_name or "", bytesRead=0, totalBytes=0})

    local apis = load_apis()
    if not apis or #apis == 0 then
        _set(appid, {status="failed", error="Nenhuma API disponível"})
        return {success=true}
    end

    local dest_root   = utils.ensure_temp_download_dir()
    local dest_path   = fs.join(dest_root, tostring(appid) .. ".zip")
    local extract_dir = fs.join(dest_root, "extracted_" .. tostring(appid))

    local target_url  = nil
    local target_name = nil

    for _, api in ipairs(apis) do
        local name     = api.name or "Unknown"
        local template = api.url  or ""
        local scode    = tonumber(api.success_code) or 200

        if template:find("<moapikey>") then goto continue end  -- sem chave, pula

        local url = template:gsub("<appid>", tostring(appid))

        local resp = http_client.head(url, {
            headers = {["User-Agent"] = config.USER_AGENT},
            timeout = 5
        })
        local ok_resp = resp and resp.status == scode
        if not ok_resp then
            resp = http_client.get(url, {
                headers = {["User-Agent"] = config.USER_AGENT},
                timeout = 5
            })
            ok_resp = resp and resp.status == scode
        end

        if ok_resp then
            target_url  = url
            target_name = name
            break
        end

        ::continue::
    end

    if not target_url then
        _set(appid, {status="failed", error="Nenhuma API encontrou o jogo"})
        return {success=true}
    end

    _set(appid, {status="downloading", currentApi=target_name})
    local state_file = fs.join(dest_root, tostring(appid) .. "_state.json")
    launch_async_download(appid, target_url, dest_path, extract_dir, state_file)

    return {success=true}
end

-- ── StartDownloadFromUrl (usado quando o JS já sabe qual API escolheu) ────────
function downloads.start_download_from_url(appid, url, api_name)
    appid = tonumber(appid)
    if not appid then return {success=false, error="appid inválido"} end

    _set(appid, {status="downloading", currentApi=api_name, bytesRead=0, totalBytes=0})

    local dest_root   = utils.ensure_temp_download_dir()
    local dest_path   = fs.join(dest_root, tostring(appid) .. ".zip")
    local extract_dir = fs.join(dest_root, "extracted_" .. tostring(appid))
    local state_file  = fs.join(dest_root, tostring(appid) .. "_state.json")

    launch_async_download(appid, url, dest_path, extract_dir, state_file)
    return {success=true}
end

-- ── CancelDownload ────────────────────────────────────────────────────────────
function downloads.cancel_download(appid)
    appid = tonumber(appid)
    if not appid then return {success=false} end
    _set(appid, {status="cancelled"})
    return {success=true}
end

-- ── GetApiList ────────────────────────────────────────────────────────────────
function downloads.get_api_list()
    local apis  = load_apis()
    local names = {}
    for _, a in ipairs(apis) do table.insert(names, {name=a.name}) end
    return {success=true, apis=names}
end

-- ── Verificar disponibilidade por API ────────────────────────────────────────
function downloads.check_apis_for_app(appid)
    appid = tonumber(appid)
    if not appid then return {success=false, error="appid inválido"} end

    local apis    = load_apis()
    local results = {}

    for _, api in ipairs(apis) do
        local name     = api.name or "Unknown"
        local template = api.url  or ""
        local scode    = tonumber(api.success_code) or 200

        if template:find("<moapikey>") then goto continue end

        local url = template:gsub("<appid>", tostring(appid))
        local available = false

        local resp = http_client.head(url, {headers={["User-Agent"]=config.USER_AGENT}, timeout=5})
        if resp and resp.status == scode then
            available = true
        else
            resp = http_client.get(url, {headers={["User-Agent"]=config.USER_AGENT}, timeout=5})
            if resp and resp.status == scode then available = true end
        end

        table.insert(results, {name=name, available=available, url=available and url or nil})
        ::continue::
    end

    return {success=true, results=results}
end

-- ── Fila pós-reinício ─────────────────────────────────────────────────────────
function downloads.queue_download_after_restart(appid)
    appid = tonumber(appid)
    if not appid then return {success=false} end
    local path     = paths.backend_path("data/download_queue.txt")
    local existing = fs.exists(path) and (m_utils.read_file(path) or "") or ""
    if not existing:find(tostring(appid)) then
        m_utils.write_file(path, existing .. tostring(appid) .. "\n")
    end
    return {success=true}
end

function downloads.cancel_queue_download(appid)
    appid = tonumber(appid)
    if not appid then return {success=false} end
    local path = paths.backend_path("data/download_queue.txt")
    if not fs.exists(path) then return {success=true} end
    local content = m_utils.read_file(path) or ""
    local lines = {}
    for line in content:gmatch("[^\r\n]+") do
        if line ~= tostring(appid) then table.insert(lines, line) end
    end
    m_utils.write_file(path, table.concat(lines, "\n") .. "\n")
    return {success=true}
end

function downloads.process_download_queue()
    local path = paths.backend_path("data/download_queue.txt")
    if not fs.exists(path) then return end
    local content = m_utils.read_file(path) or ""
    local pending = {}
    for line in content:gmatch("[^\r\n]+") do
        local appid = tonumber(line:match("^%s*(%d+)%s*$"))
        if appid then table.insert(pending, appid) end
    end
    if #pending == 0 then return end
    m_utils.write_file(path, "")
    for _, appid in ipairs(pending) do
        logger.log("Download pós-reinício para appid " .. appid)
        pcall(downloads.start_download, appid, "App " .. appid)
    end
end

-- ── Remover Lua ───────────────────────────────────────────────────────────────
function downloads.delete_lua_for_app(appid)
    appid = tonumber(appid)
    if not appid then return {success=false, error="appid inválido"} end
    local base    = steam_utils.detect_steam_install_path()
    local stplug  = fs.join(base, "config", "stplug-in")
    local lua_dir = fs.join(base, "config", "lua")
    local sid     = tostring(appid)
    local deleted = {}
    for _, p in ipairs({
        fs.join(stplug,  sid .. ".lua"),
        fs.join(stplug,  sid .. ".lua.disabled"),
        fs.join(lua_dir, sid .. ".lua"),
        fs.join(lua_dir, sid .. ".lua.disabled"),
    }) do
        if fs.exists(p) then
            pcall(fs.remove, p)
            table.insert(deleted, p)
        end
    end
    -- Remove do loadedappids
    local loaded_path = paths.backend_path(config.LOADED_APPS_FILE)
    if fs.exists(loaded_path) then
        local text  = m_utils.read_file(loaded_path) or ""
        local lines = {}
        for line in text:gmatch("[^\r\n]+") do
            if not line:match("^" .. sid) then table.insert(lines, line) end
        end
        m_utils.write_file(loaded_path, table.concat(lines, "\n") .. "\n")
    end
    return {success=true, deleted=deleted, count=#deleted,
        message=(#deleted > 0) and (#deleted .. " arquivo(s) removido(s)") or "Nenhum arquivo encontrado"}
end

return downloads
