local m_http = require("http")
local config = require("config")

local http_client = {}

function http_client.get(url, options)
    options = options or {}
    options.timeout = options.timeout or config.HTTP_TIMEOUT_SECONDS
    return m_http.get(url, options)
end

function http_client.head(url, options)
    options = options or {}
    options.timeout = options.timeout or config.HTTP_TIMEOUT_SECONDS
    if type(m_http.head) == "function" then
        return m_http.head(url, options)
    end
    options.method = "HEAD"
    return m_http.get(url, options)
end

return http_client
