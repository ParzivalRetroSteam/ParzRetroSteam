"""Fix genérico e online — download, extração e detecção de DRM."""

from __future__ import annotations

import json
import os
import threading
import time
import zipfile
from typing import Any, Dict, Optional

from config import (
    FIXES_INDEX_URL,
    GENERIC_FIX_BASE,
    ONLINE_FIX_BASE,
    TEMP_DL_DIR,
    UNSUPPORTED_DRM,
    USER_AGENT,
)
from http_client import get_client
from logger import logger
from paths import backend_path
from steam_utils import get_game_install_path

# ── Estado ───────────────────────────────────────────────────────────────────
_FIX_STATE: Dict[int, Dict[str, Any]] = {}
_FIX_LOCK = threading.Lock()

# ── Fixes index cache ─────────────────────────────────────────────────────────
_index_cache: Optional[Dict] = None
_index_time: float = 0
_INDEX_TTL = 300


def _set(appid: int, upd: dict) -> None:
    with _FIX_LOCK:
        s = _FIX_STATE.get(appid, {})
        s.update(upd)
        _FIX_STATE[appid] = s


def _get(appid: int) -> dict:
    with _FIX_LOCK:
        return _FIX_STATE.get(appid, {}).copy()


def _cancelled(appid: int) -> bool:
    return _get(appid).get("status") == "cancelled"


def _temp_dir() -> str:
    path = backend_path(TEMP_DL_DIR)
    os.makedirs(path, exist_ok=True)
    return path


def _safe_path(base: str, member: str) -> bool:
    abs_base = os.path.abspath(base)
    abs_target = os.path.abspath(os.path.join(base, member))
    return abs_target.startswith(abs_base + os.sep) or abs_target == abs_base


# ── Fixes index ───────────────────────────────────────────────────────────────

def _fetch_index() -> Optional[Dict]:
    global _index_cache, _index_time
    now = time.time()
    if _index_cache is not None and (now - _index_time) < _INDEX_TTL:
        return _index_cache
    try:
        client = get_client()
        resp = client.get(FIXES_INDEX_URL, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            _index_cache = {
                "generic": set(map(str, data.get("genericFixes", []))),
                "online":  set(map(str, data.get("onlineFixes", []))),
            }
            _index_time = time.time()
            logger.log(f"GameFixer: fixes index carregado ({len(_index_cache['generic'])} genérico, {len(_index_cache['online'])} online)")
            return _index_cache
    except Exception as e:
        logger.warn(f"GameFixer: falha ao buscar fixes index: {e}")
    return _index_cache  # stale cache


# ── Check available fixes ─────────────────────────────────────────────────────

def check_fixes(appid: int, game_name: str = "") -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    result = {
        "success": True,
        "appid": appid,
        "gameName": game_name or f"App {appid}",
        "genericFix": {"available": False, "status": 0},
        "onlineFix":  {"available": False, "status": 0, "url": ""},
    }

    index = _fetch_index()
    if index:
        sid = str(appid)
        if sid in index["generic"]:
            result["genericFix"] = {"available": True, "status": 200, "url": GENERIC_FIX_BASE.format(appid=appid)}
        if sid in index["online"]:
            result["onlineFix"]  = {"available": True, "status": 200, "url": ONLINE_FIX_BASE.format(appid=appid)}
    else:
        # Fallback: HEAD request
        client = get_client()
        for key, url_tpl in [("genericFix", GENERIC_FIX_BASE), ("onlineFix", ONLINE_FIX_BASE)]:
            url = url_tpl.format(appid=appid)
            try:
                r = client.head(url, timeout=8)
                if r.status_code == 200:
                    result[key] = {"available": True, "status": 200, "url": url}
            except Exception:
                pass

    return json.dumps(result)


# ── DRM Detection ─────────────────────────────────────────────────────────────

def detect_drm(appid: int) -> str:
    """Detecta DRM via Steam store API, buscando em campos específicos por proteção."""
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    from config import STEAM_APP_DETAILS_URL
    detected = []

    try:
        client = get_client()
        url = STEAM_APP_DETAILS_URL.format(appid=appid)
        resp = client.get(url, timeout=12)
        if resp.status_code == 200:
            data = resp.json()
            app_data = data.get(str(appid), {}).get("data", {})

            for drm in UNSUPPORTED_DRM:
                pattern = drm["pattern"].lower()
                fields  = drm.get("fields")

                if fields:
                    # Busca apenas nos campos especificados
                    found = False
                    for field in fields:
                        val = app_data.get(field)
                        if val is None:
                            continue
                        if isinstance(val, str) and pattern in val.lower():
                            found = True
                            break
                        if isinstance(val, list):
                            for item in val:
                                text = json.dumps(item).lower() if not isinstance(item, str) else item.lower()
                                if pattern in text:
                                    found = True
                                    break
                        if found:
                            break
                else:
                    # Fallback: busca em tudo (mais impreciso)
                    found = pattern in json.dumps(app_data).lower()

                if found:
                    detected.append({"id": drm["id"], "name": drm["name"]})
                    logger.log(f"GameFixer: DRM detectado para {appid}: {drm['name']}")

    except Exception as e:
        logger.warn(f"GameFixer: erro ao detectar DRM para {appid}: {e}")

    return json.dumps({"success": True, "appid": appid, "drm": detected})


# ── Fix download + extract ────────────────────────────────────────────────────

def _fix_worker(appid: int, url: str, install_path: str, fix_type: str) -> None:
    client = get_client()
    dest_zip = os.path.join(_temp_dir(), f"fix_{appid}_{fix_type}.zip")
    _set(appid, {"status": "downloading", "bytesRead": 0, "totalBytes": 0, "fixType": fix_type})

    try:
        with client.stream("GET", url, headers={"User-Agent": USER_AGENT}, timeout=30) as resp:
            resp.raise_for_status()
            total = int(resp.headers.get("Content-Length", "0") or "0")
            _set(appid, {"totalBytes": total})

            with open(dest_zip, "wb") as out:
                for chunk in resp.iter_bytes():
                    if not chunk:
                        continue
                    if _cancelled(appid):
                        raise RuntimeError("cancelled")
                    out.write(chunk)
                    read = _get(appid).get("bytesRead", 0) + len(chunk)
                    _set(appid, {"bytesRead": read})

        _set(appid, {"status": "extracting"})
        extracted = []
        appid_folder = f"{appid}/"

        with zipfile.ZipFile(dest_zip, "r") as zf:
            all_names = zf.namelist()
            top_levels = {n.split("/")[0] for n in all_names if n.split("/")[0]}

            # If zip has single folder named after appid, extract its contents
            if len(top_levels) == 1 and str(appid) in top_levels:
                for member in all_names:
                    if member.startswith(appid_folder) and member != appid_folder:
                        rel = member[len(appid_folder):]
                        if not rel or not _safe_path(install_path, rel):
                            continue
                        target = os.path.join(install_path, rel)
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        if not member.endswith("/"):
                            with zf.open(member) as src, open(target, "wb") as dst:
                                dst.write(src.read())
                            extracted.append(rel)
            else:
                for member in all_names:
                    if member.endswith("/") or not _safe_path(install_path, member):
                        continue
                    target = os.path.join(install_path, member)
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with zf.open(member) as src, open(target, "wb") as dst:
                        dst.write(src.read())
                    extracted.append(member)

        try:
            os.remove(dest_zip)
        except Exception:
            pass

        # Save manifest of installed files for later removal
        try:
            from paths import backend_path
            data_dir = backend_path("data")
            os.makedirs(data_dir, exist_ok=True)
            manifest_path = os.path.join(data_dir, f"fix_manifest_{appid}.json")
            with open(manifest_path, "w", encoding="utf-8") as mf:
                json.dump({"appid": appid, "fix_type": fix_type, "files": extracted}, mf)
        except Exception as e:
            logger.warn(f"GameFixer: falha ao salvar manifesto: {e}")

        _set(appid, {"status": "done", "success": True, "extractedFiles": extracted})
        logger.log(f"GameFixer: fix {fix_type} aplicado para {appid} ({len(extracted)} arquivos)")

    except RuntimeError as e:
        if "cancelled" in str(e):
            _set(appid, {"status": "cancelled"})
            return
        _set(appid, {"status": "failed", "error": str(e)})
        logger.warn(f"GameFixer: fix {fix_type} falhou para {appid}: {e}")
    except Exception as e:
        try:
            os.remove(dest_zip)
        except Exception:
            pass
        _set(appid, {"status": "failed", "error": str(e)})
        logger.warn(f"GameFixer: fix {fix_type} falhou para {appid}: {e}")


def apply_fix(appid: int, fix_type: str) -> str:
    """Aplica fix genérico ou online."""
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    install_path = get_game_install_path(appid)
    if not install_path:
        return json.dumps({"success": False, "error": "Caminho de instalação não encontrado"})

    url_map = {
        "generic": GENERIC_FIX_BASE.format(appid=appid),
        "online":  ONLINE_FIX_BASE.format(appid=appid),
    }
    url = url_map.get(fix_type)
    if not url:
        return json.dumps({"success": False, "error": f"Tipo de fix desconhecido: {fix_type}"})

    _set(appid, {"status": "queued", "fixType": fix_type})
    t = threading.Thread(target=_fix_worker, args=(appid, url, install_path, fix_type), daemon=True)
    t.start()
    return json.dumps({"success": True})


def apply_fix_url(appid: int, url: str, fix_type: str) -> str:
    """Aplica fix a partir de URL customizada."""
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    install_path = get_game_install_path(appid)
    if not install_path:
        return json.dumps({"success": False, "error": "Caminho de instalação não encontrado"})

    _set(appid, {"status": "queued", "fixType": fix_type})
    t = threading.Thread(target=_fix_worker, args=(appid, url, install_path, fix_type), daemon=True)
    t.start()
    return json.dumps({"success": True})


def get_fix_status(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})
    return json.dumps({"success": True, "state": _get(appid)})


def cancel_fix(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})
    _set(appid, {"status": "cancelled"})
    return json.dumps({"success": True})


def remove_fix(appid: int) -> str:
    """Remove arquivos de fix instalados pelo GameFixer para este jogo."""
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    install_path = get_game_install_path(appid)
    if not install_path:
        return json.dumps({"success": False, "error": "Jogo não encontrado instalado"})

    # Look for a manifest file that tracks what was installed
    from paths import backend_path
    manifest_path = backend_path("data", f"fix_manifest_{appid}.json")

    removed = []
    errors = []

    # Remove tracked files from game install dir
    if os.path.exists(manifest_path):
        try:
            with open(manifest_path, "r", encoding="utf-8") as mf:
                manifest = json.load(mf)
            files_to_remove = manifest.get("files", [])
            for rel_path in files_to_remove:
                full_path = os.path.join(install_path, rel_path)
                if os.path.exists(full_path):
                    try:
                        os.remove(full_path)
                        removed.append(rel_path)
                        logger.log(f"GameFixer: removido {full_path}")
                    except Exception as e:
                        errors.append(str(e))
                        logger.warn(f"GameFixer: falha ao remover {full_path}: {e}")
            os.remove(manifest_path)
        except Exception as e:
            logger.warn(f"GameFixer: erro ao ler manifesto {appid}: {e}")

    # Also scan install dir for common fix file patterns if no manifest
    if not removed and not errors:
        common_fix_patterns = [
            "steam_api64.dll",
            "steam_api.dll",
            "steamclient64.dll",
            "steamclient.dll",
            "SteamworksFix.ini",
            "Unsteam.ini",
            "codex.ini",
            "cream_api.ini",
        ]
        for fname in common_fix_patterns:
            fpath = os.path.join(install_path, fname)
            if os.path.exists(fpath):
                # Check file size — real Steam DLLs are large, crack DLLs are small
                size = os.path.getsize(fpath)
                if size < 5 * 1024 * 1024:  # < 5MB = likely a crack file
                    try:
                        os.remove(fpath)
                        removed.append(fname)
                        logger.log(f"GameFixer: removido crack file {fpath}")
                    except Exception as e:
                        errors.append(str(e))
                        logger.warn(f"GameFixer: falha ao remover {fpath}: {e}")

    if errors and not removed:
        return json.dumps({"success": False, "error": "Falha ao remover arquivos: " + "; ".join(errors)})

    return json.dumps({
        "success": True,
        "removed": removed,
        "count": len(removed),
        "message": f"{len(removed)} arquivo(s) removido(s)" if removed else "Nenhum arquivo de fix encontrado"
    })
