"""Cache do catálogo completo de jogos Steam (inclui delistados).

Adaptado de sff/game_list_fallback.py + sff/gui/web_bridge.py:_load_steam_applist
(SteaMidra — Midrags).

Carrega dados de 3 fontes GitHub (sem API key):
  1. games.json         (SteamTools-Team, 64k jogos, traz header_image + tags + DRM)
  2. games_appid.json   (GitHub mirror, 173k apps, só nome)
  3. software_appid.json (GitHub mirror, software titles)

Cache infinito no disco (baixa uma vez, nunca deleta).
Thread-safe com threading.Lock e carregamento lazy.
"""

from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Dict, List, Optional

from config import (
    GAMES_APPID_FILE,
    GAMES_APPID_URL,
    GAMES_CACHE_FILE,
    GAMES_CACHE_URL,
    SOFTWARE_APPID_FILE,
    SOFTWARE_APPID_URL,
)
from http_client import get_client
from logger import logger
from paths import backend_path
from search_engine import (
    is_game_entry,
    normalize_for_search,
    search_all_apps,
)

ETAG_CACHE_FILE = "etag_cache.json"
_etag_cache: Dict[str, str] = {}
_etag_lock = threading.Lock()

# ── Estado em memória ──────────────────────────────────────────────────────────

# Dict unificado: appid(str) -> {name, header_image, type, drm, tags}
_apps_cache: Dict[str, dict] = {}

_loaded = False
_loading = False
_load_lock = threading.Lock()


def _data_dir() -> str:
    """Diretório backend/data/ para cache."""
    d = backend_path("data")
    os.makedirs(d, exist_ok=True)
    return d


# ── ETag cache ─────────────────────────────────────────────────────────────────

def _load_etag_cache() -> Dict[str, str]:
    global _etag_cache
    cache_path = os.path.join(_data_dir(), ETAG_CACHE_FILE)
    if os.path.exists(cache_path):
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                _etag_cache = json.load(f)
        except Exception:
            _etag_cache = {}
    return _etag_cache


def _save_etag(url: str, etag: str) -> None:
    with _etag_lock:
        _etag_cache[url] = etag
        try:
            cache_path = os.path.join(_data_dir(), ETAG_CACHE_FILE)
            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump(_etag_cache, f)
        except Exception as e:
            logger.warn(f"GameCache: falha ao salvar etag_cache.json: {e}")


def _get_etag(url: str) -> Optional[str]:
    with _etag_lock:
        return _etag_cache.get(url)


# ── Download + cache no disco ──────────────────────────────────────────────────

def _download_and_cache(url: str, cache_file: str, label: str) -> Optional[object]:
    """Baixa JSON de URL e salva no disco. Usa ETag para download condicional."""
    path = os.path.join(_data_dir(), cache_file)

    # Carrega etag cache no primeiro uso
    _load_etag_cache()

    # Se já existe no disco, carrega do disco (cache infinito)
    if os.path.exists(path):
        try:
            size = os.path.getsize(path)
            if size > 0:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                logger.log(f"GameCache: {label} carregado do disco ({size:,} bytes)")

                # Download condicional: verifica se o arquivo remoto mudou usando ETag
                try:
                    client = get_client()
                    headers = {}
                    saved_etag = _get_etag(url)
                    if saved_etag:
                        headers["If-None-Match"] = saved_etag
                    cond_resp = client.get(url, timeout=60, follow_redirects=True, headers=headers)
                    if cond_resp.status_code == 304:
                        logger.log(f"GameCache: {label} nao modificado (ETag 304) — usando cache local.")
                    elif cond_resp.status_code == 200:
                        new_data = cond_resp.json()
                        new_etag = cond_resp.headers.get("ETag") or cond_resp.headers.get("etag")
                        if new_etag:
                            _save_etag(url, new_etag)
                        with open(path, "w", encoding="utf-8") as f:
                            json.dump(new_data, f, ensure_ascii=False)
                        logger.log(f"GameCache: {label} atualizado do servidor ({len(cond_resp.content):,} bytes)")
                        data = new_data
                    else:
                        logger.warn(f"GameCache: download condicional de {label} retornou {cond_resp.status_code}")
                except Exception as e:
                    logger.log(f"GameCache: download condicional de {label} falhou ({e}) — usando cache local.")
                return data
        except Exception as e:
            logger.warn(f"GameCache: falha ao ler {cache_file}: {e}")

    # Baixar (primeira vez — sem cache no disco)
    logger.log(f"GameCache: baixando {label} de {url} ...")
    try:
        client = get_client()
        resp = client.get(url, timeout=60, follow_redirects=True)
        if resp.status_code != 200:
            logger.warn(f"GameCache: {label} retornou {resp.status_code}")
            return None

        data = resp.json()

        etag = resp.headers.get("ETag") or resp.headers.get("etag")
        if etag:
            _save_etag(url, etag)

        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            logger.log(f"GameCache: {label} salvo no disco ({len(resp.content):,} bytes)")
        except Exception as e:
            logger.warn(f"GameCache: falha ao salvar {cache_file}: {e}")

        return data

    except Exception as e:
        logger.warn(f"GameCache: falha ao baixar {label}: {e}")
        return None


# ── Normalização dos dados ─────────────────────────────────────────────────────

def _normalize_games_json(data: Any) -> Dict[str, dict]:
    """Normaliza games.json (lista ou dict) → {appid(str) -> {name, header_image, ...}}."""
    if isinstance(data, dict):
        return {
            str(k): v for k, v in data.items()
            if isinstance(v, dict)
        }
    if isinstance(data, list):
        return {
            str(item.get("appid")): item
            for item in data
            if isinstance(item, dict) and item.get("appid")
        }
    logger.warn(f"GameCache: games.json formato inesperado: {type(data).__name__}")
    return {}


def _normalize_appid_data(data: Any) -> Dict[str, str]:
    """Normaliza games_appid.json / software_appid.json → {appid(str) -> name}."""
    if isinstance(data, dict):
        out: Dict[str, str] = {}
        for appid, value in data.items():
            if isinstance(value, str):
                name = value
            elif isinstance(value, dict):
                name = value.get("name", "")
            else:
                continue
            if str(appid).isdigit() and name:
                out[str(appid)] = str(name)
        return out
    if isinstance(data, list):
        out = {}
        for item in data:
            if isinstance(item, dict):
                appid = item.get("appid") or item.get("app_id") or item.get("id")
                name = item.get("name")
            elif isinstance(item, (list, tuple)) and len(item) >= 2:
                appid, name = item[0], item[1]
            else:
                continue
            if str(appid).isdigit() and name:
                out[str(appid)] = str(name)
        return out
    return {}


# ── Merge das fontes ──────────────────────────────────────────────────────────

def _merge_all(
    games_data: Optional[Dict[str, dict]],
    appid_names: Dict[str, str],
    software_names: Dict[str, str],
) -> Dict[str, dict]:
    """Merge as 3 fontes em um dict unificado.

    Prioridade: games.json (tem header_image) > appid.json > software.json.
    """
    merged: Dict[str, dict] = {}

    # 1. games.json — entrada principal (tem header_image, tags, drm)
    if games_data:
        for appid_str, info in games_data.items():
            if not appid_str.isdigit():
                continue
            name = str(info.get("name", "")).strip()
            if not name:
                continue
            merged[appid_str] = {
                "name": name,
                "header_image": info.get("header_image", ""),
                "type": str(info.get("type", "game")),
                "drm": info.get("drm", []),
                "tags": info.get("tags", []),
                "nsfw": bool(info.get("nsfw", False)),
            }

    # 2. appid_names — preenche os que faltam (sem foto, mas com nome)
    for appid_str, name in appid_names.items():
        if appid_str in merged:
            continue
        if not name:
            continue
        merged[appid_str] = {
            "name": name,
            "header_image": "",
            "type": "game",
            "drm": [],
            "tags": [],
            "nsfw": False,
        }

    # 3. software_names — preenche software que faltou
    for appid_str, name in software_names.items():
        if appid_str in merged:
            continue
        if not name:
            continue
        merged[appid_str] = {
            "name": name,
            "header_image": "",
            "type": "software",
            "drm": [],
            "tags": [],
            "nsfw": False,
        }

    return merged


# ── Carregamento lazy ────────────────────────────────────────────────────────

def ensure_loaded() -> bool:
    """Carrega o catálogo (lazy, thread-safe). Retorna True se há dados."""
    global _apps_cache, _loaded, _loading

    if _loaded:
        return bool(_apps_cache)

    with _load_lock:
        if _loaded:
            return bool(_apps_cache)
        if _loading:
            # Outra thread já está carregando — não bloqueia, retorna vazio
            return False
        _loading = True

        try:
            games_data = None
            appid_names: Dict[str, str] = {}
            software_names: Dict[str, str] = {}

            # games.json (SteamTools — 64k jogos com header_image)
            raw_games = _download_and_cache(
                GAMES_CACHE_URL, GAMES_CACHE_FILE, "games.json"
            )
            if raw_games:
                games_data = _normalize_games_json(raw_games)

            # games_appid.json (173k apps — só nome)
            raw_appid = _download_and_cache(
                GAMES_APPID_URL, GAMES_APPID_FILE, "games_appid.json"
            )
            if raw_appid:
                appid_names = _normalize_appid_data(raw_appid)

            # software_appid.json (software titles)
            raw_soft = _download_and_cache(
                SOFTWARE_APPID_URL, SOFTWARE_APPID_FILE, "software_appid.json"
            )
            if raw_soft:
                software_names = _normalize_appid_data(raw_soft)

            # Merge
            _apps_cache = _merge_all(games_data, appid_names, software_names)
            _loaded = True

            games_count = len(games_data) if games_data else 0
            appid_count = len(appid_names)
            soft_count = len(software_names)
            logger.log(
                f"GameCache: catálogo carregado — "
                f"{len(_apps_cache):,} apps total "
                f"(games.json={games_count:,}, appid={appid_count:,}, software={soft_count:,})"
            )

        except Exception as e:
            logger.warn(f"GameCache: falha ao carregar catálogo: {e}")
            _apps_cache = {}
            _loaded = True  # não tenta de novo
        finally:
            _loading = False

    return bool(_apps_cache)


def preload_in_background() -> None:
    """Inicia o carregamento em background (thread daemon)."""
    def _worker():
        try:
            ensure_loaded()
        except Exception as e:
            logger.warn(f"GameCache: preload falhou: {e}")

    t = threading.Thread(target=_worker, daemon=True, name="game-cache-preload")
    t.start()


# ── API pública ──────────────────────────────────────────────────────────────

def search_in_cache(term: str, limit: int = 20) -> List[dict]:
    """Busca jogos delistados no games.json (token matching + substring fallback).

    Adaptado de sff/game_list_fallback.py search_games_json + search_name_fallback.
    Retorna [{app_id, name, header_image, source}].
    """
    ensure_loaded()
    if not _apps_cache:
        return []

    return search_all_apps(term, _apps_cache, limit=limit)


def is_ready() -> bool:
    """O catálogo já está carregado em memória?"""
    return _loaded and bool(_apps_cache)


def get_cache_info() -> dict:
    """Retorna informações sobre o cache para o frontend."""
    info = {
        "ready": is_ready(),
        "loading": _loading,
        "total_apps": len(_apps_cache),
    }
    cache_path = os.path.join(_data_dir(), GAMES_CACHE_FILE)
    if os.path.exists(cache_path):
        try:
            mtime = os.path.getmtime(cache_path)
            info["cached_at"] = time.strftime(
                "%d/%m/%Y %H:%M", time.localtime(mtime)
            )
        except Exception:
            pass
    return info
