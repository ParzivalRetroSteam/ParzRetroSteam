"""Cliente HTTP compartilhado."""

import httpx
from config import HTTP_TIMEOUT, USER_AGENT
from logger import logger

_client: httpx.Client | None = None


def get_client() -> httpx.Client:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.Client(
            timeout=HTTP_TIMEOUT,
            headers={"User-Agent": USER_AGENT},
            follow_redirects=True,
        )
    return _client


def close_client() -> None:
    global _client
    if _client and not _client.is_closed:
        try:
            _client.close()
        except Exception as e:
            logger.warn(f"GameFixer: erro ao fechar cliente HTTP: {e}")
    _client = None
