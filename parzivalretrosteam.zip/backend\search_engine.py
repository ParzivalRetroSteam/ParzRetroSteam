"""Motor de busca com scoring e alias expansions.

Adaptado de sff/gui/web_bridge.py (SFF — Midrags).
Implementa o mesmo sistema de scoring em camadas e expansão de abreviações
para que buscas como "gta san andreas" encontrem
"Grand Theft Auto: San Andreas", mesmo em jogos delistados.
"""

from __future__ import annotations

import unicodedata
from typing import Dict, List, Tuple

# ── Alias expansions (copiadas fielmente do SFF _ALIAS_EXPANSIONS) ──────────────
# Permite que o usuário digite abreviações comuns e o sistema expanda
# para o nome completo da franquia antes de buscar.

_ALIAS_EXPANSIONS: Dict[str, List[str]] = {
    "gta":   ["grand theft auto"],
    "rdr":   ["red dead redemption"],
    "cod":   ["call of duty"],
    "re":    ["resident evil"],
    "tf2":   ["team fortress 2"],
    "csgo":  ["counter strike global offensive", "counter-strike global offensive"],
    "cs2":   ["counter strike 2", "counter-strike 2"],
    "css":   ["counter strike source", "counter-strike source"],
    "cs":    ["counter strike", "counter-strike"],
    "kh":    ["kingdom hearts"],
    "mh":    ["monster hunter"],
    "ff":    ["final fantasy"],
    "ds":    ["dark souls"],
    "ds1":   ["dark souls"],
    "ds2":   ["dark souls 2", "dark souls ii"],
    "ds3":   ["dark souls 3", "dark souls iii"],
    "er":    ["elden ring"],
    "mk":    ["mortal kombat"],
    "ac":    ["assassins creed", "assassin s creed"],
    "btd":   ["bloons td"],
    "tw":    ["total war"],
    "wh":    ["warhammer"],
    "sf":    ["street fighter"],
    "tk":    ["tekken"],
    "p5":    ["persona 5"],
    "p4":    ["persona 4"],
    "p3":    ["persona 3"],
    "lol":   ["league of legends"],
    "pubg":  ["playerunknown s battlegrounds", "playerunknowns battlegrounds"],
    "wow":   ["world of warcraft"],
    "hots":  ["heroes of the storm"],
    "sc2":   ["starcraft 2", "starcraft ii"],
    "d2":    ["diablo 2", "diablo ii", "destiny 2"],
    "d3":    ["diablo 3", "diablo iii"],
    "d4":    ["diablo 4", "diablo iv"],
    "wukong": ["black myth wukong"],
}

# Palavras-chave que indicam que o app NÃO é um jogo jogável
_NONGAME_NAME_KW = (
    "soundtrack", "art book", "artbook", " ost",
    "music pack", "digital artbook",
)

# Tipos Steam que não são jogos (DLC=2, demo=3 mas demos são ok, etc)
_NON_GAME_TYPES = frozenset({2, 4, 6, 7, 9, 10, 11, 12, 13})


def normalize_for_search(text: str) -> str:
    """Remove ®™©©, acentos e pontuação → ASCII lowercase com espaços.

    Adaptado de sff/gui/web_bridge.py _normalize_for_search.
    Garante que "LEGO® Batman™: Legacy" vire "lego batman legacy".
    """
    if not text or not isinstance(text, str):
        return ""

    # Remove trademark / registered / copyright marks ANTES de NFKD.
    # NFKD transforma ™ nas letras literais "TM", que colam na palavra.
    for mark in ("\u2122", "\u00ae", "\u00a9", "\u2117", "\u2120"):
        text = text.replace(mark, "")

    decomposed = unicodedata.normalize("NFKD", text)
    out_chars: list[str] = []
    for ch in decomposed:
        cat = unicodedata.category(ch)
        # Drop combining marks (Mn) e símbolos decorativos (S)
        if cat.startswith("M") or cat.startswith("S"):
            continue
        # Tudo não-alfanumérico vira espaço
        if not ch.isalnum():
            out_chars.append(" ")
            continue
        out_chars.append(ch.lower())

    collapsed = "".join(out_chars).split()
    return " ".join(collapsed)


def _store_words(text_norm: str) -> List[str]:
    """Split normalizado em tokens não-vazios."""
    return [w for w in (text_norm or "").split() if w]


def _store_token_match(token: str, name_norm: str) -> bool:
    """Token curto (<3 chars) precisa ser palavra inteira; longo pode ser substring."""
    if len(token) < 3:
        return token in _store_words(name_norm)
    return token in name_norm


def _store_all_tokens_match(query_norm: str, name_norm: str) -> bool:
    """Todos os tokens da query devem aparecer no nome (com alias expansion)."""
    tokens = _store_words(query_norm)
    if not tokens:
        return True
    for token in tokens:
        if _store_token_match(token, name_norm):
            continue
        # Tenta expansão de alias
        alts = _ALIAS_EXPANSIONS.get(token)
        if alts and any(
            _store_all_tokens_match(normalize_for_search(alt), name_norm)
            for alt in alts
        ):
            continue
        return False
    return True


def _store_word_start_match(query_norm: str, name_norm: str) -> bool:
    """Cada token da query deve ser prefixo de alguma palavra do nome (em ordem)."""
    tokens = _store_words(query_norm)
    if not tokens:
        return True
    words = _store_words(name_norm)
    pos = 0
    for token in tokens:
        found = False
        for idx in range(pos, len(words)):
            if words[idx].startswith(token):
                pos = idx + 1
                found = True
                break
        if not found:
            return False
    return True


def _store_query_has_alias(query_norm: str) -> bool:
    """A query contém algum token que tem alias?"""
    if query_norm in _ALIAS_EXPANSIONS:
        return True
    return any(token in _ALIAS_EXPANSIONS for token in _store_words(query_norm))


def _store_short_loose_query(query_norm: str) -> bool:
    """Query muito curta (<3 chars compactados) sem alias → matching frouxo."""
    compact = (query_norm or "").replace(" ", "")
    return (
        len(compact) < 3
        and not compact.isdigit()
        and not _store_query_has_alias(query_norm)
    )


def _store_alias_score(query_norm: str, name_norm: str) -> int | None:
    """Tenta match via alias expansion. Retorna score ou None."""
    candidates: list[str] = []
    seen: set[str] = set()
    for candidate in alias_expanded_queries(query_norm):
        cand_norm = normalize_for_search(candidate)
        if not cand_norm or cand_norm == query_norm or cand_norm in seen:
            continue
        seen.add(cand_norm)
        candidates.append(cand_norm)

    for cand_norm in candidates:
        if name_norm == cand_norm:
            return 0
        if name_norm.startswith(cand_norm):
            return 1
        if _store_word_start_match(cand_norm, name_norm):
            return 2
        if _store_all_tokens_match(cand_norm, name_norm):
            return 3
        if cand_norm in name_norm:
            return 4
    return None


def store_search_score(
    query: str, name: str, appid: Any = None
) -> Tuple[int, ...]:
    """Scoring em camadas — mesma lógica do SFF.

    Retorna tupla ordenável: (score, ...tiebreakers).
    Score 0 = appid exato, 1 = nome exato, 2 = prefixo,
    4 = word-start, 5 = alias, 8 = token-match, 9 = substring,
    99 = sem match.
    """
    query_norm = normalize_for_search(query or "")
    name_norm = normalize_for_search(name or "")
    appid_text = str(appid or "").strip()

    if not query_norm:
        return (50, name_norm, appid_text)

    compact = query_norm.replace(" ", "")

    # App ID exato ou prefixo de appid
    if compact.isdigit() and appid_text:
        if appid_text == compact:
            return (0, "", appid_text)
        if len(compact) >= 3 and appid_text.startswith(compact):
            return (3, appid_text, name_norm)

    # Nome exato
    if name_norm == query_norm:
        return (1, name_norm, appid_text)

    has_alias = _store_query_has_alias(query_norm)
    short_alias = has_alias and len(compact) < 3

    # Prefixo do nome
    if not short_alias and name_norm.startswith(query_norm):
        return (2, name_norm, appid_text)

    # Query curta e sem alias → matching frouxo (word-start mínimo)
    if _store_short_loose_query(query_norm):
        if len(compact) >= 2 and _store_word_start_match(query_norm, name_norm):
            return (4, name_norm, appid_text)
        return (99, name_norm, appid_text)

    # Word-start match
    if not short_alias and _store_word_start_match(query_norm, name_norm):
        return (4, name_norm, appid_text)

    # Alias expansion
    alias_score = _store_alias_score(query_norm, name_norm)
    if alias_score is not None:
        return (5, alias_score, name_norm, appid_text)

    # Prefixo curto com alias
    if short_alias and name_norm.startswith(query_norm):
        return (6, name_norm, appid_text)
    if short_alias and _store_word_start_match(query_norm, name_norm):
        return (7, name_norm, appid_text)

    # Token match (todos os tokens estão no nome)
    if _store_all_tokens_match(query_norm, name_norm):
        return (8, name_norm, appid_text)

    # Substring
    if (
        not short_alias
        and not _store_short_loose_query(query_norm)
        and query_norm in name_norm
    ):
        return (9, name_norm, appid_text)

    # Sem match
    return (99, name_norm, appid_text)


def alias_expanded_queries(query: str) -> list[str]:
    """Expande abreviações ("gta" → "grand theft auto").

    Adaptado de sff/gui/web_bridge.py _alias_expanded_queries.
    Retorna lista com query original + expansões (max 6).
    """
    if not query or not isinstance(query, str):
        return []
    raw = query.strip()
    if not raw:
        return []

    out = [raw]
    seen = {raw.lower()}

    tokens = raw.split()
    if not tokens:
        return out

    # Alias de query inteira ("gta" sozinho → "grand theft auto")
    full_alts = _ALIAS_EXPANSIONS.get(raw.lower())
    if full_alts:
        for alt in full_alts:
            if alt.lower() not in seen:
                seen.add(alt.lower())
                out.append(alt)

    # Alias por token
    for i, tok in enumerate(tokens):
        alts = _ALIAS_EXPANSIONS.get(tok.lower())
        if not alts:
            continue
        for alt in alts:
            new_tokens = list(tokens)
            new_tokens[i] = alt
            cand = " ".join(new_tokens)
            key = cand.lower()
            if key in seen:
                continue
            seen.add(key)
            out.append(cand)
            if len(out) >= 6:
                return out

    return out


def is_game_entry(name: str, app_type: str = "") -> bool:
    """Filtra DLCs/soundtracks/artbooks.

    Adaptado de sff/game_list_fallback.py _is_game_entry.
    """
    gtype = (app_type or "").lower().strip()
    if gtype not in ("game", "demo", ""):
        return False
    name_lc = (name or "").lower()
    for kw in (
        "soundtrack", "art book", "artbook", "ost",
        "music pack", "digital artbook",
    ):
        if kw in name_lc:
            return False
    return True


def _fast_filter(query_raw: str, name_raw: str) -> bool:
    """Pré-filtro rápido SEM normalização Unicode.

    Faz um substring check básico no nome cru (lowercase).
    É ~100x mais rápido que normalize_for_search + store_search_score
    e elimina ~95% dos candidatos que não têm chance de match.
    """
    q = query_raw.lower().strip()
    n = name_raw.lower()
    compact = q.replace(" ", "")

    # AppID puro: busca no nome e no appid diretamente
    if compact.isdigit():
        return compact in n or compact in query_raw

    # Query curta (<3 chars): precisa estar em alguma palavra do nome
    if len(compact) < 3:
        return any(compact in w for w in n.split())

    # Query normal: substring check no nome todo
    if all(tok in n for tok in q.split()):
        return True

    # Tenta word-start match rápido
    words = n.split()
    tokens = q.split()
    pos = 0
    for tok in tokens:
        found = False
        for i in range(pos, len(words)):
            if words[i].startswith(tok):
                pos = i + 1
                found = True
                break
        if not found:
            return False
    return True


def search_all_apps(
    query: str,
    apps_dict: Dict[str, dict],
    limit: int = 20,
) -> list[dict]:
    """Busca no catálogo completo usando scoring + aliases.

    Performance: primeiro aplica _fast_filter (rápido, ~95% eliminação),
    depois scoring completo apenas nos candidatos restantes.

    Args:
        query: termo de busca (nome ou appid)
        apps_dict: dict {appid(str) -> {name, header_image, ...}}
        limit: máximo de resultados

    Returns:
        Lista de dicts [{appid, name, image, source}] ordenados por relevância.
    """
    query = (query or "").strip()
    if not query:
        return []

    query_norm = normalize_for_search(query)
    query_compact = query_norm.replace(" ", "")

    # Cache para alias expansions (evita recalcular)
    alias_queries: list[str] = []
    if not query_compact.isdigit() and _store_query_has_alias(query_norm):
        alias_queries = alias_expanded_queries(query)
        alias_queries = [q for q in alias_queries if q.lower() != query.lower()]

    scored: list[tuple] = []

    for appid_str, info in apps_dict.items():
        name = info.get("name", "")
        if not name:
            continue
        if not is_game_entry(name, info.get("type", "")):
            continue

        # PRÉ-FILTRO RÁPIDO: elimina ~95% sem normalização
        if not _fast_filter(query, name):
            # Se falhou, tenta com alias expansion
            if not alias_queries or not any(
                _fast_filter(aq, name) for aq in alias_queries
            ):
                continue

        score = store_search_score(query, name, appid_str)
        if score[0] >= 99:
            continue

        scored.append((score, appid_str, name, info))

    # Ordena por score (melhor primeiro)
    scored.sort(key=lambda x: x[0])

    results: list[dict] = []
    for score, appid_str, name, info in scored[:limit]:
        appid = int(appid_str) if appid_str.isdigit() else 0
        if not appid:
            continue

        image = (
            info.get("header_image", "")
            or info.get("image", "")
            or ""
        )

        results.append({
            "appid": appid,
            "name": name,
            "image": image,
            "source": "catalog",
        })

    return results
