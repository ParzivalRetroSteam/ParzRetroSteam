"""auth.py — Autenticação por Key + HWID via Google Apps Script (POST).

Fluxo:
  1. Plugin checa auth.json local (key + hwid)
  2. Se não existe → frontend exibe tela de ativação
  3. Usuário digita key → Python gera HWID da máquina
  4. Envia POST com key + hwid + secret para o Apps Script
  5. Apps Script valida na planilha Google Sheets
  6. OK → salva auth.json → plugin funciona normalmente
  7. ERRO → bloqueia com mensagem clara

HWID = SHA-256(serial_placa_mãe | uuid_windows | mac_address)
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import threading
from typing import Optional

from config import AUTH_API_URL, AUTH_FILE, AUTH_SECRET
from http_client import get_client
from logger import logger
from paths import backend_path, plugin_dir


# ── HWID ──────────────────────────────────────────────────────────────────────

def _wmi(path: str, field: str) -> str:
    try:
        out = subprocess.check_output(
            ["wmic", path, "get", field, "/value"],
            stderr=subprocess.DEVNULL, timeout=5,
            creationflags=0x08000000,
        ).decode(errors="ignore")
        for line in out.splitlines():
            if "=" in line:
                val = line.split("=", 1)[1].strip()
                if val:
                    return val
    except Exception:
        pass
    return ""


def get_hwid() -> str:
    """HWID estável: placa-mãe + UUID Windows → SHA-256[:32].

    MAC address removido — o Windows pode randomizá-lo a cada reinício
    (MAC Randomization), tornando o HWID instável.
    Serial da placa-mãe e UUID do Windows são persistentes entre reboots.
    """
    parts = []
    if platform.system() == "Windows":
        mb = _wmi("baseboard", "SerialNumber")
        wu = _wmi("csproduct", "UUID")
        bad = {"", "to be filled by o.e.m.", "none", "default string",
               "not applicable", "ffffffff-ffff-ffff-ffff-ffffffffffff"}
        if mb and mb.lower().strip() not in bad:
            parts.append(f"MB:{mb.strip()}")
        if wu and wu.lower().strip() not in bad:
            parts.append(f"UUID:{wu.strip()}")
    # Fallback: hostname (estável entre reboots na maioria dos casos)
    if not parts:
        parts.append(f"HOST:{platform.node()}")
    hwid = hashlib.sha256("|".join(parts).encode()).hexdigest()[:32].upper()
    logger.log(f"Auth: HWID gerado ({len(parts)} componente(s)): {hwid[:8]}...")
    return hwid


# ── Auth local ────────────────────────────────────────────────────────────────

def _auth_path() -> str:
    """Salva o auth.json fora da pasta do plugin — em Steam/config/parzival/.
    Assim nunca é sobrescrito por atualizações do plugin.
    """
    try:
        from steam_utils import get_steam_path
        steam = get_steam_path()
        if steam:
            auth_dir = os.path.join(steam, "config", "parzival")
            os.makedirs(auth_dir, exist_ok=True)
            return os.path.join(auth_dir, AUTH_FILE)
    except Exception as e:
        logger.warn(f"Auth: nao foi possivel usar Steam/config/parzival/: {e}")
    # Fallback: pasta data/ do plugin (comportamento anterior)
    return backend_path("data", AUTH_FILE)


def _load() -> Optional[dict]:
    p = _auth_path()
    if not os.path.exists(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _save(key: str, hwid: str) -> None:
    p = _auth_path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump({"key": key, "hwid": hwid, "valid": True}, f)


def _clear() -> None:
    p = _auth_path()
    if os.path.exists(p):
        os.remove(p)


# ── API ───────────────────────────────────────────────────────────────────────

def _api(action: str, key: str = "", hwid: str = "") -> dict:
    """POST para o Google Apps Script."""
    try:
        client = get_client()
        resp = client.post(
            AUTH_API_URL,
            json={"action": action, "key": key, "hwid": hwid, "secret": AUTH_SECRET},
            timeout=15,
            follow_redirects=True,
        )
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, dict) else {"ok": False, "error": "invalid_response"}
    except Exception as e:
        logger.warn(f"Auth API error: {e}")
        return {"ok": False, "error": f"connection_error: {e}"}


# ── Ponto de entrada público ──────────────────────────────────────────────────

def is_authenticated() -> bool:
    local = _load()
    if not local or not local.get("valid"):
        return False
    if local.get("hwid") != get_hwid():
        logger.warn("Auth: HWID não corresponde — limpando auth local.")
        _clear()
        return False
    return True


def activate(key: str) -> dict:
    key = key.strip().upper()
    if not key:
        return {"success": False, "message": "Key não pode estar vazia."}

    hwid = get_hwid()
    logger.log(f"Auth: ativando key={key[:4]}**** hwid={hwid[:8]}...")

    result = _api("validate", key, hwid)

    if result.get("ok"):
        _save(key, hwid)
        logger.log("Auth: ativação OK — auth.json salvo.")
        return {"success": True, "message": result.get("message", "Ativado com sucesso!")}
    else:
        error = result.get("error", "unknown")
        msgs = {
            "key_not_found":  "Key não encontrada. Verifique e tente novamente.",
            "hwid_mismatch":  "Esta key já está em uso em outro PC.",
            "key_revoked":    "Esta key foi revogada. Contate o suporte.",
            "unauthorized":   "Erro interno. Atualize o plugin.",
            "connection_error": "Sem conexão. Verifique sua internet.",
        }
        # connection_error: mantém qualquer auth local existente
        msg = msgs.get(error) or msgs.get(error.split(":")[0].strip()) or f"Erro: {error}"
        logger.warn(f"Auth: ativação recusada — {error}")
        return {"success": False, "message": msg}


def validate_online() -> dict:
    local = _load()
    if not local:
        return {"success": False, "message": "Não ativado."}

    key  = local.get("key", "")
    hwid = get_hwid()

    if local.get("hwid") != hwid:
        _clear()
        return {"success": False, "message": "HWID alterado. Reative o plugin."}

    result = _api("validate", key, hwid)
    if result.get("ok"):
        return {"success": True, "message": "OK"}

    error = result.get("error", "")
    # Erro de conexão → não invalida (permite uso offline)
    if "connection_error" in error:
        logger.warn("Auth: validação online falhou (sem rede) — mantendo auth local.")
        return {"success": True, "message": "offline_ok"}

    _clear()
    msg = result.get("message", "Licença revogada.")
    logger.warn(f"Auth: validação online falhou — {msg}")
    return {"success": False, "message": msg}


def get_auth_status() -> str:
    local = _load()
    if not local or not local.get("valid"):
        return json.dumps({"authenticated": False, "key": None})
    hwid = get_hwid()
    if local.get("hwid") != hwid:
        _clear()
        return json.dumps({"authenticated": False, "key": None})
    key = local.get("key", "")
    masked = (key[:4] + "****" + key[-4:]) if len(key) > 8 else "****"
    return json.dumps({"authenticated": True, "key": masked})


def _self_destruct(reason: str) -> None:
    import shutil
    pdir = plugin_dir()
    logger.warn(f"Auth: AUTO-DESTRUIÇÃO — {reason}")

    def _delete():
        import time
        time.sleep(2)
        try:
            shutil.rmtree(pdir, ignore_errors=True)
        except Exception as e:
            logger.warn(f"Auth: falha ao deletar pasta: {e}")

    threading.Thread(target=_delete, daemon=True).start()


def check_on_startup():
    """Verifica auth na inicialização.

    Retorna:
      True          → autenticado, plugin funciona normalmente
      "no_license" → nunca ativado, exibe tela de ativação no JS
      False         → auth inválida (revogada/HWID errado), auto-destrói
    """
    local = _load()

    # Nunca ativado → pede ativação, NÃO auto-destrói
    if not local or not local.get("valid"):
        logger.log("Auth: sem licença local — aguardando ativação.")
        return "no_license"

    hwid = get_hwid()

    # HWID diferente → PC trocado sem autorização → auto-destrói
    if local.get("hwid") != hwid:
        logger.warn("Auth: HWID diferente — auto-destruição.")
        _self_destruct("HWID não corresponde")
        return False

    key = local.get("key", "")
    result = _api("validate", key, hwid)

    if result.get("ok"):
        logger.log("Auth: startup OK.")
        return True

    error = result.get("error", "")

    # Sem internet → permite (modo offline)
    if "connection_error" in error:
        logger.warn("Auth: sem rede no startup — modo offline.")
        return True

    # Key revogada ou inválida → auto-destrói
    logger.warn(f"Auth: startup rejeitado — {result.get('error')}")
    _clear()
    _self_destruct(f"key inválida: {result.get('error')}")
    return False
