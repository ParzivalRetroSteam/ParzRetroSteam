"""Configurações centrais do GameFixer."""

PLUGIN_NAME        = "Parzival Retrô Steam"
PLUGIN_VERSION     = "1.8"

# ── Autenticação por Key + HWID ───────────────────────────────────────────────
AUTH_API_URL   = "https://script.google.com/macros/s/AKfycbyWFIj-z9uWFvT-FffpD6qdyKdYWPfN2FvebpAhblUnyIgF6fV8-OplF66VtOi3L9WlCA/exec"
AUTH_FILE      = "auth.json"   # salvo em backend/data/ — guarda key + hwid validados
AUTH_SECRET    = "parz_secret_2025"  # deve ser igual ao Code.gs   # salvo em backend/data/ — guarda key + hwid validados

GITHUB_REPO        = "ParzivalRetroSteam/ParzRetroSteam"
GITHUB_API_RELEASES = f"https://api.github.com/repos/{GITHUB_REPO}/releases"

# OpenSteamTool — dependência externa que o plugin precisa para funcionar.
# Mantida atualizada separadamente (DLLs na raiz da Steam, não dentro do plugin).
OST_GITHUB_REPO       = "OpenSteam001/OpenSteamTool"
OST_GITHUB_API_LATEST = f"https://api.github.com/repos/{OST_GITHUB_REPO}/releases/latest"
OST_FILES             = ["dwmapi.dll", "xinput1_4.dll", "OpenSteamTool.dll"]
OST_VERSION_FILE       = "ost_version.json"  # salvo em backend/data/, guarda a tag instalada

WEBKIT_DIR_NAME    = "ParzivalRetroSteam"
WEB_UI_JS_FILE     = "gamefixer.js"
WEB_UI_ICON_FILE   = "gamefixer-icon.png"

# APIs para download de manifesto Lua
API_JSON_FILE      = "api.json"

# Fixes index (mesmos endpoints do luatools)
FIXES_INDEX_URL    = "https://index.luatools.work/fixes-index.json"
GENERIC_FIX_BASE   = "https://files.luatools.work/GameBypasses/{appid}.zip"
ONLINE_FIX_BASE    = "https://files.luatools.work/OnlineFix1/{appid}.zip"

# DRM que o plugin detecta.
# Cada entrada tem:
#   pattern  — string exata a buscar no JSON da Steam API (lowercase)
#   fields   — lista de campos onde buscar (None = busca em tudo, mais lento e falso-positivo-prone)
#              use ["legal_notice", "drm_notice", "dlc"] para ser preciso
UNSUPPORTED_DRM = [
    {"id": "denuvo",    "name": "Denuvo",              "pattern": "denuvo",             "fields": ["legal_notice", "drm_notice", "name", "detailed_description"]},
    {"id": "ea",        "name": "EA Anti-Cheat",        "pattern": "ea anticheat",       "fields": ["legal_notice", "drm_notice", "detailed_description"]},
    {"id": "eac",       "name": "Easy Anti-Cheat",      "pattern": "easy anti-cheat",    "fields": ["legal_notice", "drm_notice", "detailed_description"]},
    {"id": "battleye",  "name": "BattlEye",             "pattern": "battleye",           "fields": ["legal_notice", "drm_notice", "detailed_description"]},
    {"id": "ubisoft",   "name": "Ubisoft Connect",      "pattern": "ubisoft connect",    "fields": ["legal_notice", "drm_notice", "detailed_description"]},
    {"id": "rockstar",  "name": "Rockstar Launcher",    "pattern": "rockstar games launcher", "fields": ["legal_notice", "drm_notice", "detailed_description"]},
    {"id": "epicgames", "name": "Epic Games Launcher",  "pattern": "epic games launcher","fields": ["legal_notice", "drm_notice", "detailed_description"]},
    {"id": "vac",       "name": "VAC (Valve Anti-Cheat)","pattern": "valve anti-cheat",  "fields": ["legal_notice", "drm_notice", "detailed_description"]},
    {"id": "steamdrm",  "name": "Steam DRM",            "pattern": "steam drm",          "fields": ["drm_notice"]},
]

# DRM detection API (Steam store page tags)
STEAM_APP_DETAILS_URL = "https://store.steampowered.com/api/appdetails?appids={appid}&l=portuguese"

# Temp + data
TEMP_DL_DIR        = "temp_dl"
LOADED_APPS_FILE   = "loadedappids.txt"

# HTTP
HTTP_TIMEOUT       = 20
USER_AGENT         = "discord(dot)gg/luatools"
