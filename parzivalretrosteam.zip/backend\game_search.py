"""Busca de jogos por nome — com catálogo de delistados.

Pipeline otimizado (adaptado do SFF — SteaMidra/Midrags):
  1. storesearch + catálogo rodam em PARALELO
  2. Merge e deduplicação por appid
  3. Preenche imagem via CDN para jogos sem foto

O campo "source" em cada resultado indica a origem:
  "steam"    → veio do storesearch (jogo ativo na loja)
  "catalog"  → veio do catálogo (pode ser delistado)
"""

from __future__ import annotations

import concurrent.futures
import json
import time
from typing import Any, Dict, List, Set
from urllib.parse import quote

from config import STEAM_HEADER_IMG_URL, STEAM_STORESEARCH_URL
from game_list_cache import ensure_loaded, get_cache_info, is_ready, search_in_cache
from http_client import get_client
from logger import logger

# Limite de resultados devolvidos ao frontend
_MAX_RESULTS = 20

# Tempo máximo que uma busca storesearch pode demorar antes de pular pro fallback
_STORESEARCH_TIMEOUT = 12


def _search_storesearch(term: str) -> List[Dict[str, Any]]:
    """Busca jogos ativos via storesearch da Steam."""
    url = STEAM_STORESEARCH_URL.format(term=quote(term))
    try:
        client = get_client()
        resp = client.get(url, timeout=_STORESEARCH_TIMEOUT)
        if resp.status_code != 200:
            return []
        data = resp.json()
    except Exception as e:
        logger.warn(f"GameSearch: erro storesearch: {e}")
        return []

    items = data.get("items", []) if isinstance(data, dict) else []
    games: List[Dict[str, Any]] = []

    for item in items:
        if item.get("type") and item.get("type") != "app":
            continue
        appid = item.get("id")
        name = item.get("name", "").strip()
        if not appid or not name:
            continue
        try:
            appid = int(appid)
        except (TypeError, ValueError):
            continue

        games.append({
            "appid": appid,
            "name": name,
            "image": item.get("tiny_image", ""),
            "source": "steam",
        })

        if len(games) >= _MAX_RESULTS:
            break

    return games


def _search_catalog(term: str) -> List[Dict[str, Any]]:
    """Busca no catálogo completo (inclui jogos delistados)."""
    if not is_ready():
        t0 = time.time()
        ensure_loaded()
        elapsed = time.time() - t0
        logger.log(f"GameSearch: catálogo carregado em {elapsed:.1f}s")

    if not is_ready():
        return []

    return search_in_cache(term, limit=_MAX_RESULTS)


def _fill_missing_images(games: List[Dict[str, Any]]) -> None:
    """Preenche imagem via CDN para jogos sem foto (funciona para delistados)."""
    for g in games:
        if not g.get("image"):
            appid = g.get("appid")
            if appid:
                g["image"] = STEAM_HEADER_IMG_URL.format(appid=appid)


def _merge_results(
    steam_results: List[Dict[str, Any]],
    catalog_results: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Merge: storesearch primeiro, depois catálogo (sem duplicar appid)."""
    seen: Set[int] = set()
    merged: List[Dict[str, Any]] = []

    for g in steam_results:
        appid = g.get("appid")
        if not appid or appid in seen:
            continue
        seen.add(appid)
        merged.append(g)

    for g in catalog_results:
        appid = g.get("appid")
        if not appid or appid in seen:
            continue
        seen.add(appid)
        merged.append(g)

    return merged


def search_games(term: str) -> str:
    """Busca jogos por nome (storesearch + catálogo em PARALELO).

    Retorna JSON: {"success": true, "games": [{appid, name, image, source}]}
    """
    term = (term or "").strip()
    if not term:
        return json.dumps({"success": True, "games": [], "empty_term": True})

    steam_results: List[Dict[str, Any]] = []
    catalog_results: List[Dict[str, Any]] = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        f_steam = pool.submit(_search_storesearch, term)
        f_catalog = pool.submit(_search_catalog, term)

        try:
            steam_results = f_steam.result(timeout=15)
        except Exception as e:
            logger.warn(f"GameSearch: storesearch paralelo falhou: {e}")

        try:
            catalog_results = f_catalog.result(timeout=60)
        except Exception as e:
            logger.warn(f"GameSearch: catálogo paralelo falhou: {e}")

    merged = _merge_results(steam_results, catalog_results)
    _fill_missing_images(merged)
    merged = merged[:_MAX_RESULTS]

    logger.log(
        f"GameSearch: '{term}' → {len(merged)} resultado(s) "
        f"(steam={len(steam_results)}, catalog={len(catalog_results)})"
    )
    return json.dumps({"success": True, "games": merged})


def get_cache_status() -> str:
    """Retorna status do cache do catálogo (para o frontend exibir hint)."""
    info = get_cache_info()
    return json.dumps({
        "success": True,
        **info,
    })
