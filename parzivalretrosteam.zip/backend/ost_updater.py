"""Auto-updater do OpenSteamTool (dependência externa, não faz parte do plugin).

Mantém dwmapi.dll, xinput1_4.dll e OpenSteamTool.dll na raiz da Steam sempre
na versão mais recente publicada em github.com/OpenSteam001/OpenSteamTool.

Diferente do updater.py (que atualiza o próprio plugin), este módulo escreve
fora da pasta do plugin — direto na raiz da instalação da Steam — porque é
onde o OpenSteamTool precisa ficar para funcionar.
"""

from __future__ import annotations

import json
import os
import tempfile
import threading
import zipfile
from typing import Optional

from config import (
    OST_GITHUB_API_LATEST,
    OST_FILES,
    OST_VERSION_FILE,
    HTTP_TIMEOUT,
)
from http_client import get_client
from logger import logger
from paths import backend_path

# ── Estado interno (mesmo padrão do updater.py) ────────────────────────────────

_state: dict = {
    "checking": False,
    "updating": False,
    "update_available": False,
    "current_version": None,
    "latest_version": None,
    "update_applied": False,
    "error": None,
}
_lock = threading.Lock()


def get_ost_update_status() -> str:
    with _lock:
        return json.dumps(_state.copy())


# ── Versão instalada localmente ──────────────────────────────────────────────

def _version_file_path() -> str:
    return backend_path("data", OST_VERSION_FILE)


def _read_installed_version() -> Optional[str]:
    path = _version_file_path()
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("tag")
    except Exception:
        return None


def _write_installed_version(tag: str) -> None:
    path = _version_file_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"tag": tag}, f)
    except Exception as e:
        logger.warn(f"OST Updater: falha ao salvar versão local: {e}")


# ── Busca a última release no GitHub ─────────────────────────────────────────

def _fetch_latest_release() -> Optional[dict]:
    try:
        client = get_client()
        resp = client.get(OST_GITHUB_API_LATEST, timeout=HTTP_TIMEOUT)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.warn(f"OST Updater: erro ao buscar release: {e}")
        return None


def _find_zip_asset(release: dict) -> Optional[str]:
    """Prioriza o asset *-Release.zip (variante sem logging), ignora -Debug."""
    assets = release.get("assets", [])
    for asset in assets:
        name = asset.get("name", "")
        if name.endswith("Release.zip"):
            return asset.get("browser_download_url")
    for asset in assets:
        name = asset.get("name", "")
        if name.endswith(".zip") and "Debug" not in name:
            return asset.get("browser_download_url")
    if assets:
        return assets[0].get("browser_download_url")
    return None


# ── Detecta se o OpenSteamTool já está instalado na Steam ───────────────────

def _is_installed(steam_path: str) -> bool:
    return any(os.path.exists(os.path.join(steam_path, f)) for f in OST_FILES)


# ── Download + substituição dos DLLs ─────────────────────────────────────────

def _apply_update(zip_url: str, tag: str, steam_path: str) -> bool:
    try:
        logger.log(f"OST Updater: baixando {zip_url} ...")
        client = get_client()
        resp = client.get(zip_url, timeout=60)
        resp.raise_for_status()

        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
            tmp.write(resp.content)
            tmp_path = tmp.name

        logger.log("OST Updater: extraindo e instalando DLLs na raiz da Steam...")

        with zipfile.ZipFile(tmp_path, "r") as zf:
            names = zf.namelist()
            installed_any = False
            for target_file in OST_FILES:
                match = next(
                    (n for n in names if os.path.basename(n) == target_file),
                    None,
                )
                if not match:
                    continue
                dest = os.path.join(steam_path, target_file)
                with zf.open(match) as src, open(dest, "wb") as dst:
                    dst.write(src.read())
                logger.log(f"OST Updater: {target_file} atualizado.")
                installed_any = True

        os.unlink(tmp_path)

        if not installed_any:
            logger.warn("OST Updater: nenhum DLL esperado encontrado no zip.")
            return False

        # Garante que config\lua existe (necessário pro OST funcionar)
        lua_dir = os.path.join(steam_path, "config", "lua")
        os.makedirs(lua_dir, exist_ok=True)

        _write_installed_version(tag)
        logger.log(f"OST Updater: OpenSteamTool atualizado para {tag} com sucesso!")
        return True

    except Exception as e:
        logger.warn(f"OST Updater: falha ao aplicar update: {e}")
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
        return False


# ── Ponto de entrada público ──────────────────────────────────────────────────

def check_and_update_ost(silent: bool = True, steam_path: str = "") -> None:
    """Verifica e atualiza o OpenSteamTool em background.

    Se o OpenSteamTool nunca foi instalado por este mecanismo (sem versão
    salva), instala a última versão direto — o plugin depende dele pra
    funcionar. Caso contrário, só atualiza se houver uma tag diferente da
    instalada.
    """

    def _run() -> None:
        with _lock:
            if _state["checking"] or _state["updating"]:
                return
            _state["checking"] = True
            _state["error"] = None

        try:
            if not steam_path:
                with _lock:
                    _state["error"] = "steam_path não informado."
                return

            installed_version = _read_installed_version()
            with _lock:
                _state["current_version"] = installed_version

            release = _fetch_latest_release()
            if release is None:
                with _lock:
                    _state["error"] = "Não foi possível contatar o GitHub do OpenSteamTool."
                return

            tag = release.get("tag_name", "")
            with _lock:
                _state["latest_version"] = tag

            already_installed = _is_installed(steam_path)

            # Já está na versão mais recente conhecida e os DLLs existem → nada a fazer
            if installed_version == tag and already_installed:
                logger.log(f"OST Updater: OpenSteamTool já na versão mais recente ({tag}).")
                with _lock:
                    _state["update_available"] = False
                return

            reason = "instalação inicial" if not already_installed else f"{installed_version or '?'} -> {tag}"
            logger.log(f"OST Updater: atualizando OpenSteamTool ({reason})")
            with _lock:
                _state["update_available"] = True

            zip_url = _find_zip_asset(release)
            if not zip_url:
                with _lock:
                    _state["error"] = "Release do OpenSteamTool sem .zip para download."
                return

            with _lock:
                _state["updating"] = True

            ok = _apply_update(zip_url, tag, steam_path)

            with _lock:
                _state["updating"] = False
                _state["update_applied"] = ok
                if not ok:
                    _state["error"] = "Falha ao aplicar o update do OpenSteamTool."

        finally:
            with _lock:
                _state["checking"] = False

    t = threading.Thread(target=_run, name="ost-updater", daemon=True)
    t.start()
