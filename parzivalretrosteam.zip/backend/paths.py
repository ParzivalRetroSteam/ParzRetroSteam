"""Helpers de caminho para o GameFixer."""

import os


def plugin_dir() -> str:
    """Retorna o diretório raiz do plugin (pasta GameFixer)."""
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def backend_path(*parts: str) -> str:
    return os.path.join(plugin_dir(), "backend", *parts)


def public_path(*parts: str) -> str:
    return os.path.join(plugin_dir(), "public", *parts)
