-- fixes.lua — Parzival Retrô Steam
local m_utils     = require("utils")
local fs          = require("fs")
local http_client = require("http_client")
local logger      = require("plugin_logger")
local utils       = require("plugin_utils")
local paths       = require("paths")
local steam_utils = require("steam_utils")
local cjson       = require("json")
local config      = require("config")

local fixes = {}

function fixes.check_for_fixes(appid)
    appid = tonumber(appid)
    local result = {
        success    = true,
        appid      = appid,
        gameName   = "App " .. tostring(appid),
        genericFix = {status=0, available=false},
        onlineFix  = {status=0, available=false},
    }
    local resp = http_client.get(config.FIXES_INDEX_URL, {timeout=10})
    if resp and resp.status == 200 and resp.body then
        local ok_p, data = pcall(cjson.decode, resp.body)
        if ok_p and data then
            local gen_url = string.format(config.GENERIC_FIX_BASE, appid)
            local onl_url = string.format(config.ONLINE_FIX_BASE,  appid)
            local has_gen, has_onl = false, false
            for _, v in ipairs(data.genericFixes or {}) do
                if tonumber(v) == appid then has_gen = true; break end
            end
            for _, v in ipairs(data.onlineFixes or {}) do
                if tonumber(v) == appid then has_onl = true; break end
            end
            if has_gen then result.genericFix = {status=200, available=true, url=gen_url} end
            if has_onl then result.onlineFix  = {status=200, available=true, url=onl_url} end
        end
    end
    return result
end

local function launch_fix_download(appid, download_url, install_path, state_file, dest_zip)
    local is_windows = (m_utils.getenv("OS") or ""):find("Windows") ~= nil
    m_utils.write_file(state_file, '{"status": "downloading"}')
    if is_windows then
        local ps1 = fs.join(paths.get_plugin_dir(), "backend", "scripts", "downloader.ps1")
        local cmd = string.format(
            'powershell -WindowStyle Hidden -Command "Start-Process -FilePath powershell -WindowStyle Hidden -ArgumentList \'-ExecutionPolicy Bypass -File \\"%s\\" -Url \\"%s\\" -DestPath \\"%s\\" -ExtractDir \\"%s\\" -StateFile \\"%s\\"\'"',
            ps1, download_url, dest_zip, install_path, state_file
        )
        m_utils.exec(cmd)
    else
        local sh = fs.join(paths.get_plugin_dir(), "backend", "scripts", "downloader.sh")
        m_utils.exec('chmod +x "' .. sh .. '"')
        local cmd = string.format(
            'nohup bash "%s" "%s" "%s" "%s" "%s" > /dev/null 2>&1 &',
            sh, download_url, dest_zip, install_path, state_file
        )
        m_utils.exec(cmd)
    end
end

function fixes.apply_game_fix(appid, download_url, install_path, fix_type, game_name)
    local dest_root  = utils.ensure_temp_download_dir()
    local dest_zip   = fs.join(dest_root, "fix_" .. tostring(appid) .. ".zip")
    local state_file = fs.join(dest_root, "fix_" .. tostring(appid) .. "_state.json")
    logger.log("Aplicando fix para appid " .. tostring(appid))
    launch_fix_download(appid, download_url, install_path, state_file, dest_zip)
    return {success=true}
end

function fixes.get_apply_status(appid)
    local dest_root  = utils.ensure_temp_download_dir()
    local state_file = fs.join(dest_root, "fix_" .. tostring(appid) .. "_state.json")
    local dest_zip   = fs.join(dest_root, "fix_" .. tostring(appid) .. ".zip")
    if not fs.exists(state_file) then
        return {success=true, state={status="done"}}
    end
    local content = m_utils.read_file(state_file) or ""
    local ok_p, data = pcall(cjson.decode, content)
    if ok_p and data and data.status then
        if data.status == "extracted" then
            data.status = "done"
            pcall(fs.remove, state_file)
            pcall(fs.remove, dest_zip)
        elseif data.status == "failed" then
            pcall(fs.remove, state_file)
        end
        return {success=true, state=data}
    end
    return {success=true, state={status="downloading"}}
end

function fixes.detect_drm(appid)
    local DRM_LIST = {
        {id="denuvo",    name="Denuvo",              pattern="denuvo"},
        {id="ea",        name="EA Anti-Cheat",        pattern="ea anticheat"},
        {id="eac",       name="Easy Anti-Cheat",      pattern="easy anti%-cheat"},
        {id="battleye",  name="BattlEye",             pattern="battleye"},
        {id="ubisoft",   name="Ubisoft Connect",      pattern="ubisoft connect"},
        {id="rockstar",  name="Rockstar Launcher",    pattern="rockstar games launcher"},
        {id="epicgames", name="Epic Games Launcher",  pattern="epic games launcher"},
        {id="vac",       name="VAC",                  pattern="valve anti%-cheat"},
        {id="steamdrm",  name="Steam DRM",            pattern="steam drm"},
    }
    local detected = {}
    local url  = string.format("https://store.steampowered.com/api/appdetails?appids=%d&l=portuguese", appid)
    local resp = http_client.get(url, {timeout=12})
    if resp and resp.status == 200 and resp.body then
        local ok_p, data = pcall(cjson.decode, resp.body)
        if ok_p and data then
            local app_data = (data[tostring(appid)] or {}).data or {}
            for _, drm in ipairs(DRM_LIST) do
                local found = false
                for _, field in ipairs({"legal_notice","drm_notice","detailed_description","name"}) do
                    local val = app_data[field]
                    if val and type(val) == "string" then
                        if val:lower():find(drm.pattern) then
                            found = true; break
                        end
                    end
                end
                if found then table.insert(detected, {id=drm.id, name=drm.name}) end
            end
        end
    end
    return {success=true, appid=appid, drm=detected}
end

return fixes
