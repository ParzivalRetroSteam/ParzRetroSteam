-- steam_utils.lua — Parzival Retrô Steam
local m_utils   = require("utils")
local millennium = require("millennium")
local fs        = require("fs")
local logger    = require("plugin_logger")

local steam_utils = {}
local STEAM_PATH  = nil

function steam_utils.detect_steam_install_path()
    if STEAM_PATH then return STEAM_PATH end
    local ok, path = pcall(millennium.steam_path)
    if ok and path then
        STEAM_PATH = path
        logger.log("Steam path: " .. tostring(STEAM_PATH))
        return STEAM_PATH
    end
    return ""
end

function steam_utils.has_lua_for_app(appid)
    local base = steam_utils.detect_steam_install_path()
    if not base or base == "" then return false end
    local stplug = fs.join(base, "config", "stplug-in")
    local lua_d  = fs.join(base, "config", "lua")
    local sid    = tostring(appid)
    return fs.exists(fs.join(stplug, sid .. ".lua"))
        or fs.exists(fs.join(stplug, sid .. ".lua.disabled"))
        or fs.exists(fs.join(lua_d,  sid .. ".lua"))
        or fs.exists(fs.join(lua_d,  sid .. ".lua.disabled"))
end

function steam_utils.get_game_install_path_response(appid)
    appid = tostring(appid)
    local steam_path = steam_utils.detect_steam_install_path()
    if not steam_path or steam_path == "" then
        return { success = false, error = "Steam path not found" }
    end
    local vdf_path = fs.join(steam_path, "config", "libraryfolders.vdf")
    if not fs.exists(vdf_path) then
        return { success = false, error = "libraryfolders.vdf not found" }
    end
    local vdf = m_utils.read_file(vdf_path) or ""
    local lib_paths = {}
    for p in vdf:gmatch('"path"%s+"([^"]+)"') do
        table.insert(lib_paths, p:gsub("\\\\", "\\"))
    end
    for _, lib in ipairs(lib_paths) do
        local manifest = fs.join(lib, "steamapps", "appmanifest_" .. appid .. ".acf")
        if fs.exists(manifest) then
            local content = m_utils.read_file(manifest) or ""
            local install_dir = content:match('"installdir"%s+"([^"]+)"')
            if install_dir then
                local full = fs.join(lib, "steamapps", "common", install_dir)
                if fs.exists(full) then
                    return { success = true, installPath = full, path = full }
                end
            end
        end
    end
    return { success = false, error = "menu.error.notInstalled" }
end

function steam_utils.open_game_folder(path)
    if not path or path == "" or not fs.exists(path) then return false end
    path = path:gsub("/", "\\")
    m_utils.exec('explorer "' .. path .. '"')
    return true
end

return steam_utils
