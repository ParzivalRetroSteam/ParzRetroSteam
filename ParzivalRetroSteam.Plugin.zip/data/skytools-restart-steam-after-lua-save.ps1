$ErrorActionPreference = 'SilentlyContinue'
$LogPath = 'c:/program files (x86)/steam\millennium/plugins\ParzivalRetroSteam.Plugin\data\skytools-steam-restart.log'
$TaskName = 'SkyTools.RestartSteamAfterLuaSave'
function Write-RestartLog([string]$Message) {
  try { Add-Content -LiteralPath $LogPath -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Message) -Encoding UTF8 } catch {}
}
Write-RestartLog 'Tarefa destacada iniciada.'
Write-RestartLog 'Encerrando processos da Steam.'
Get-Process -Name 'steam' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Get-Process -Name 'steamwebhelper' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
$Deadline = (Get-Date).AddSeconds(15)
while ((Get-Process -Name 'steam' -ErrorAction SilentlyContinue) -and (Get-Date) -lt $Deadline) { Start-Sleep -Milliseconds 250 }
Write-RestartLog 'Iniciando Steam.exe.'
Start-Process -FilePath 'c:/program files (x86)/steam\steam.exe'
Write-RestartLog 'Steam.exe iniciado.'
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue