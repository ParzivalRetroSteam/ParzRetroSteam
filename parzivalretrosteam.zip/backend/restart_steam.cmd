@echo off
setlocal enableextensions enabledelayedexpansion

rem Resolve Steam install path from registry
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| find "SteamPath"') do set "STEAM_DIR=%%B"

rem Optional: appid passed as first argument triggers auto-install after Steam starts
set "AUTO_APPID=%~1"

echo Restarting Steam...
taskkill /IM steam.exe /F >nul 2>&1
timeout /t 3 /nobreak >nul

if defined STEAM_DIR (
  start "" "%STEAM_DIR%\Steam.exe" -clearbeta
) else (
  start "" steam.exe -clearbeta
)

rem Wait for Steam UI to fully load before opening protocol URLs
timeout /t 12 /nobreak >nul

rem If a specific appid was requested for auto-install, trigger it
if not "!AUTO_APPID!"=="" (
  if not "!AUTO_APPID!"=="0" (
    start "" "steam://install/!AUTO_APPID!"
  )
)

exit
