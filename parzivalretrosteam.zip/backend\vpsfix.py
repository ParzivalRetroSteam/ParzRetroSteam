"""VPS-hosted Ryuu fixes fallback (substitui generator.ryuu.lol que agora exige login)."""

from __future__ import annotations

import time
from typing import Any, Dict, Optional

from http_client import get_client
from logger import logger

VPS_FIX_INDEX_URL = "https://parzivalalicenses.dnsfollowme.uk/api/v1/fixes-index"
VPS_FIX_BASE      = "https://parzivalalicenses.dnsfollowme.uk/api/v1/fixes/{appid}"

_index_cache: Optional[Dict[str, Any]] = None
_index_time: float = 0
_INDEX_TTL = 300


def _load_index() -> Optional[Dict[str, Any]]:
    global _index_cache, _index_time
    now = time.time()
    if _index_cache is not None and (now - _index_time) < _INDEX_TTL:
        return _index_cache
    try:
        client = get_client()
        resp = client.get(VPS_FIX_INDEX_URL, timeout=15)
        if resp.status_code == 200:
            _index_cache = resp.json()
            _index_time = now
            logger.log(f"VPSFix: indice carregado — {len(_index_cache)} jogos")
            return _index_cache
    except Exception as e:
        logger.warn(f"VPSFix: falha ao carregar indice: {e}")
    return _index_cache


def check(appid: int) -> Dict[str, Any]:
    idx = _load_index()
    if idx is None:
        return {"available": False}
    sid = str(appid)
    entry = idx.get(sid)
    if entry:
        filename = entry.get("file", f"{sid}.zip")
        return {
            "available": True,
            "url":       VPS_FIX_BASE.format(appid=sid),
            "filename":  filename,
            "source":    "vpsfix",
        }
    return {"available": False}
