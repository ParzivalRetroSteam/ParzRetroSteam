"""
voicesfix.py — Fonte de fallback: github.com/voicesfix/fix releases.
Arquivos nomeados por AppID: {appid}.zip
Link direto, sem auth, sem captcha, nunca expira.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from http_client import get_client
from logger import logger

GITHUB_USER  = "voicesfix"
GITHUB_REPO  = "fix"
GITHUB_TAG   = "v1.2"   # atualizar se subir nova tag

DOWNLOAD_BASE = f"https://github.com/{GITHUB_USER}/{GITHUB_REPO}/releases/download/{GITHUB_TAG}/{{appid}}.zip"


def check(appid: int) -> Dict[str, Any]:
    """
    Verifica se existe fix para o appid no repositório voicesfix/fix.
    Faz HEAD na URL do release asset — se existir (200/302), está disponível.
    """
    url = DOWNLOAD_BASE.format(appid=appid)
    try:
        client = get_client()
        r = client.head(url, timeout=10, follow_redirects=True)
        if r.status_code == 200:
            return {
                "available": True,
                "url":       url,
                "filename":  f"{appid}.zip",
                "source":    "voicesfix",
            }
        logger.log(f"voicesfix: appid {appid} não encontrado (status={r.status_code})")
    except Exception as e:
        logger.warn(f"voicesfix: erro ao verificar {appid}: {e}")
    return {"available": False}
