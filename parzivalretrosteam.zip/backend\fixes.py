"""Fix genérico, online e Ryuu — download, extração e detecção de DRM."""

from __future__ import annotations

import json
import os
import threading
import time
import zipfile
from typing import Any, Dict, Optional

from config import (
    FIXES_INDEX_URL,
    GENERIC_FIX_BASE,
    ONLINE_FIX_BASE,
    TEMP_DL_DIR,
    UNSUPPORTED_DRM,
    USER_AGENT,
)
from http_client import get_client
from logger import logger
from paths import backend_path
from ryuu import check as ryuu_check
from voicesfix import check as voicesfix_check
from vpsfix import check as vpsfix_check
from steam_utils import get_game_install_path

# ── Estado ────────────────────────────────────────────────────────────────────
_FIX_STATE: Dict[int, Dict[str, Any]] = {}
_FIX_LOCK = threading.Lock()

_index_cache: Optional[Dict] = None
_index_time: float = 0
_INDEX_TTL = 300


def _set(appid: int, upd: dict) -> None:
    with _FIX_LOCK:
        s = _FIX_STATE.get(appid, {})
        s.update(upd)
        _FIX_STATE[appid] = s


def _get(appid: int) -> dict:
    with _FIX_LOCK:
        return _FIX_STATE.get(appid, {}).copy()


def _cancelled(appid: int) -> bool:
    return _get(appid).get("status") == "cancelled"


def _temp_dir() -> str:
    path = backend_path(TEMP_DL_DIR)
    os.makedirs(path, exist_ok=True)
    return path


def _safe_path(base: str, member: str) -> bool:
    abs_base = os.path.abspath(base)
    abs_target = os.path.abspath(os.path.join(base, member))
    return abs_target.startswith(abs_base + os.sep) or abs_target == abs_base


# ── Fixes index ───────────────────────────────────────────────────────────────

def _fetch_index() -> Optional[Dict]:
    global _index_cache, _index_time
    now = time.time()
    if _index_cache is not None and (now - _index_time) < _INDEX_TTL:
        return _index_cache
    try:
        client = get_client()
        resp = client.get(FIXES_INDEX_URL, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            _index_cache = {
                "generic": set(map(str, data.get("genericFixes", []))),
                "online":  set(map(str, data.get("onlineFixes", []))),
            }
            _index_time = time.time()
            return _index_cache
    except Exception as e:
        logger.warn(f"GameFixer: falha ao buscar fixes index: {e}")
    return _index_cache


# ── check_fixes ───────────────────────────────────────────────────────────────

def check_fixes(appid: int, game_name: str = "") -> str:
    """
    Verifica fix disponível em três fontes, nessa ordem:
      1. voicesfix (GitHub releases) — fonte primária
      2. VPS (Ryuu files hospedados) — fallback se voicesfix não tiver o jogo
      3. Ryuu (generator.ryuu.lol) — fallback extremo (pode exigir login)
    """
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    result = {
        "success":  True,
        "appid":    appid,
        "gameName": game_name or f"App {appid}",
        "ryuuFix":  {"available": False},
        "vpsFix":   {"available": False},
        "vfFix":    {"available": False},
    }

    # 1. voicesfix — fonte primária
    vf = voicesfix_check(appid)
    if vf.get("available"):
        result["vfFix"] = vf
        logger.log(f"Fix encontrado no voicesfix para {appid}: {vf.get('filename', '')}")
        return json.dumps(result)

    # 2. VPS fix (Ryuu files hospedados) — segundo fallback
    vps = vpsfix_check(appid)
    if vps.get("available"):
        result["vpsFix"] = vps
        logger.log(f"Fix encontrado no VPS para {appid}: {vps.get('filename', '')}")
        return json.dumps(result)

    # 3. Ryuu original (generator.ryuu.lol) — pode exigir login, fallback extremo
    ryuu = ryuu_check(appid)
    if ryuu.get("available"):
        result["ryuuFix"] = ryuu
        logger.log(f"Fix encontrado no Ryuu (fallback extremo) para {appid}: {ryuu.get('filename', '')}")

    return json.dumps(result)


# ── DRM Detection ─────────────────────────────────────────────────────────────

def detect_drm(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    from config import STEAM_APP_DETAILS_URL
    detected = []
    try:
        client = get_client()
        resp = client.get(STEAM_APP_DETAILS_URL.format(appid=appid), timeout=12)
        if resp.status_code == 200:
            data = resp.json()
            app_data = data.get(str(appid), {}).get("data", {})
            for drm in UNSUPPORTED_DRM:
                pattern = drm["pattern"].lower()
                fields  = drm.get("fields")
                found   = False
                if fields:
                    for field in fields:
                        val = app_data.get(field)
                        if val is None:
                            continue
                        if isinstance(val, str) and pattern in val.lower():
                            found = True; break
                        if isinstance(val, list):
                            for item in val:
                                text = json.dumps(item).lower() if not isinstance(item, str) else item.lower()
                                if pattern in text:
                                    found = True; break
                        if found: break
                else:
                    found = pattern in json.dumps(app_data).lower()
                if found:
                    detected.append({"id": drm["id"], "name": drm["name"]})
    except Exception as e:
        logger.warn(f"GameFixer: erro DRM para {appid}: {e}")

    return json.dumps({"success": True, "appid": appid, "drm": detected})


# ── Extração ──────────────────────────────────────────────────────────────────

def _extract_zip(dest_file: str, install_path: str) -> list:
    extracted = []
    appid_str = os.path.splitext(os.path.basename(dest_file))[0].split("_")[1] if "_" in os.path.basename(dest_file) else ""
    appid_folder = f"{appid_str}/"

    with zipfile.ZipFile(dest_file, "r") as zf:
        all_names = zf.namelist()
        top_levels = {n.split("/")[0] for n in all_names if n.split("/")[0]}

        if len(top_levels) == 1 and appid_str in top_levels:
            for member in all_names:
                if member.startswith(appid_folder) and member != appid_folder:
                    rel = member[len(appid_folder):]
                    if not rel or not _safe_path(install_path, rel):
                        continue
                    target = os.path.join(install_path, rel)
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    if not member.endswith("/"):
                        with zf.open(member) as src, open(target, "wb") as dst:
                            dst.write(src.read())
                        extracted.append(rel)
        else:
            for member in all_names:
                if member.endswith("/") or not _safe_path(install_path, member):
                    continue
                target = os.path.join(install_path, member)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with zf.open(member) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                extracted.append(member)
    return extracted


def _find_extractor_binaries() -> list:
    """Procura 7z/unrar tanto no PATH quanto nos caminhos comuns de instalação
    no Windows, ja que os instaladores do 7-Zip e do WinRAR nao adicionam
    os executaveis ao PATH por padrao."""
    import shutil

    candidatos = []

    # 1) Tenta primeiro pelo PATH (caso o usuario tenha configurado manualmente)
    for nome in ("7z", "7z.exe", "unrar", "unrar.exe", "UnRAR.exe"):
        encontrado = shutil.which(nome)
        if encontrado:
            candidatos.append(encontrado)

    # 2) Caminhos fixos comuns de instalacao no Windows
    caminhos_fixos = [
        r"C:\Program Files\7-Zip\7z.exe",
        r"C:\Program Files (x86)\7-Zip\7z.exe",
        r"C:\Program Files\WinRAR\UnRAR.exe",
        r"C:\Program Files (x86)\WinRAR\UnRAR.exe",
        r"C:\Program Files\WinRAR\Rar.exe",
        r"C:\Program Files (x86)\WinRAR\Rar.exe",
    ]
    for caminho in caminhos_fixos:
        if os.path.isfile(caminho):
            candidatos.append(caminho)

    # Remove duplicados preservando ordem
    vistos = set()
    unicos = []
    for c in candidatos:
        if c not in vistos:
            vistos.add(c)
            unicos.append(c)
    return unicos


def _download_portable_7z(tmp_dir: str) -> str:
    """Baixa o instalador oficial do 7-Zip e instala silenciosamente numa
    pasta temporaria (sem ir pro Program Files, sem menu iniciar, sem
    associacao de arquivos). Retorna o caminho do 7z.exe extraido.
    Levanta RuntimeError se algo falhar."""
    import subprocess
    import time
    from http_client import get_client

    VERSAO_7Z = "26.02"
    nome_arquivo = f"7z{VERSAO_7Z.replace('.', '')}-x64.exe"
    url = f"https://github.com/ip7z/7zip/releases/download/{VERSAO_7Z}/{nome_arquivo}"

    installer_path = os.path.join(tmp_dir, "7z_setup_temp.exe")
    target_dir = os.path.join(tmp_dir, "7zip_portable")

    logger.log("GameFixer: nenhuma ferramenta RAR encontrada, baixando 7-Zip temporario...")

    client = get_client()
    resp = client.get(url, timeout=60)
    resp.raise_for_status()
    with open(installer_path, "wb") as f:
        f.write(resp.content)

    # Instala silenciosamente (/S) numa pasta temporaria (/D=...)
    # Observacao: /D= precisa ser o ultimo parametro e sem aspas.
    subprocess.run(
        [installer_path, "/S", f"/D={target_dir}"],
        timeout=60,
    )

    exe_path = os.path.join(target_dir, "7z.exe")
    # A instalacao silenciosa pode levar um instante pra finalizar os arquivos
    for _ in range(20):
        if os.path.isfile(exe_path):
            return exe_path
        time.sleep(0.5)

    raise RuntimeError("Falha ao instalar o 7-Zip temporario (7z.exe não apareceu).")


def _cleanup_portable_7z(tmp_dir: str) -> None:
    """Desinstala (se possivel) e apaga a pasta temporaria do 7-Zip baixado."""
    import subprocess
    import shutil

    target_dir = os.path.join(tmp_dir, "7zip_portable")
    uninstaller = os.path.join(target_dir, "Uninstall.exe")
    if os.path.isfile(uninstaller):
        try:
            subprocess.run([uninstaller, "/S"], timeout=30)
        except Exception as e:
            logger.warn(f"GameFixer: falha ao desinstalar 7-Zip temporario: {e}")

    try:
        shutil.rmtree(tmp_dir, ignore_errors=True)
    except Exception as e:
        logger.warn(f"GameFixer: falha ao limpar pasta temporaria do 7-Zip: {e}")


def _extract_rar(dest_file: str, install_path: str) -> list:
    """Extrai .rar usando patool (que usa unrar/7z disponível no sistema)."""
    try:
        import patoollib  # type: ignore
        patoollib.extract_archive(dest_file, outdir=install_path, verbosity=-1)
    except ImportError:
        # Fallback: tenta via subprocess, procurando o binario tanto no PATH
        # quanto nos caminhos fixos de instalacao do 7-Zip/WinRAR
        import subprocess
        import tempfile

        binarios = _find_extractor_binaries()
        sucesso = False
        tmp_dir_baixado = None

        if binarios:
            for bin_path in binarios:
                nome = os.path.basename(bin_path).lower()
                if "7z" in nome:
                    cmd = [bin_path, "x", dest_file, f"-o{install_path}", "-y"]
                else:  # unrar / Rar.exe
                    cmd = [bin_path, "x", "-y", dest_file, install_path + os.sep]

                try:
                    result = subprocess.run(cmd, capture_output=True, timeout=120)
                    if result.returncode == 0:
                        sucesso = True
                        break
                except (FileNotFoundError, subprocess.TimeoutExpired):
                    continue

        # Nada instalado no sistema (ou falhou) -> baixa 7-Zip temporario,
        # usa, e depois remove tudo (instalacao + pasta temp)
        if not sucesso:
            tmp_dir_baixado = tempfile.mkdtemp(prefix="gamefixer_7z_")
            try:
                exe_path = _download_portable_7z(tmp_dir_baixado)
                cmd = [exe_path, "x", dest_file, f"-o{install_path}", "-y"]
                result = subprocess.run(cmd, capture_output=True, timeout=120)
                if result.returncode == 0:
                    sucesso = True
            except Exception as e:
                logger.warn(f"GameFixer: falha ao usar 7-Zip temporario: {e}")
            finally:
                _cleanup_portable_7z(tmp_dir_baixado)

        if not sucesso:
            raise RuntimeError(
                "Nenhuma ferramenta de extração RAR encontrada (7z ou unrar), "
                "e o download automático do 7-Zip também falhou. "
                "Instale o 7-Zip (7-zip.org) manualmente e tente novamente."
            )

    # Lista os arquivos extraídos
    extracted = []
    for root, _, files in os.walk(install_path):
        for f in files:
            full = os.path.join(root, f)
            extracted.append(os.path.relpath(full, install_path))
    return extracted


def _detect_format(dest_file: str) -> str:
    """Detecta o formato real pelo magic bytes, independente da extensão."""
    with open(dest_file, "rb") as f:
        header = f.read(8)
    if header[:2] == b"PK":
        return "zip"
    if header[:7] == b"Rar!\x1a\x07":
        return "rar"
    if header[:7] == b"Rar!\x1a\x07\x01":
        return "rar"
    # Fallback: tenta pela extensão do arquivo
    ext = os.path.splitext(dest_file)[1].lower()
    if ext == ".rar":
        return "rar"
    return "zip"


def _extract(dest_file: str, install_path: str) -> list:
    fmt = _detect_format(dest_file)
    if fmt == "zip":
        return _extract_zip(dest_file, install_path)
    elif fmt == "rar":
        return _extract_rar(dest_file, install_path)
    else:
        raise RuntimeError(f"Formato não suportado: {fmt}")


# ── Worker ────────────────────────────────────────────────────────────────────

def _fix_worker(appid: int, url: str, install_path: str, fix_type: str) -> None:
    dest_file = os.path.join(_temp_dir(), f"fix_{appid}_{fix_type}.tmp")
    _set(appid, {"status": "downloading", "bytesRead": 0, "totalBytes": 0, "fixType": fix_type})

    try:
        client = get_client()
        with client.stream("GET", url, headers={"User-Agent": USER_AGENT}, timeout=30) as resp:
            resp.raise_for_status()
            total = int(resp.headers.get("Content-Length", "0") or "0")
            _set(appid, {"totalBytes": total})
            with open(dest_file, "wb") as out:
                for chunk in resp.iter_bytes():
                    if not chunk:
                        continue
                    if _cancelled(appid):
                        raise RuntimeError("cancelled")
                    out.write(chunk)
                    read = _get(appid).get("bytesRead", 0) + len(chunk)
                    _set(appid, {"bytesRead": read})

        _set(appid, {"status": "extracting"})
        extracted = _extract(dest_file, install_path)

        try:
            os.remove(dest_file)
        except Exception:
            pass

        # Salva manifesto de arquivos instalados (para remoção futura)
        try:
            data_dir = backend_path("data")
            os.makedirs(data_dir, exist_ok=True)
            manifest_path = os.path.join(data_dir, f"fix_manifest_{appid}.json")
            with open(manifest_path, "w", encoding="utf-8") as mf:
                json.dump({"appid": appid, "fix_type": fix_type, "files": extracted}, mf)
        except Exception as e:
            logger.warn(f"GameFixer: falha ao salvar manifesto: {e}")

        _set(appid, {"status": "done", "success": True, "extractedFiles": extracted})
        logger.log(f"GameFixer: fix '{fix_type}' aplicado para {appid} ({len(extracted)} arquivos)")

    except RuntimeError as e:
        if "cancelled" in str(e):
            _set(appid, {"status": "cancelled"})
            return
        _set(appid, {"status": "failed", "error": str(e)})
        logger.warn(f"GameFixer: fix falhou para {appid}: {e}")
    except Exception as e:
        try:
            os.remove(dest_file)
        except Exception:
            pass
        _set(appid, {"status": "failed", "error": str(e)})
        logger.warn(f"GameFixer: fix falhou para {appid}: {e}")


# ── API pública ───────────────────────────────────────────────────────────────

def apply_fix(appid: int, fix_type: str) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    install_path = get_game_install_path(appid)
    if not install_path:
        return json.dumps({"success": False, "error": "Caminho de instalação não encontrado"})

    url_map = {
        "generic": GENERIC_FIX_BASE.format(appid=appid),
        "online":  ONLINE_FIX_BASE.format(appid=appid),
    }
    url = url_map.get(fix_type)
    if not url:
        return json.dumps({"success": False, "error": f"Tipo de fix desconhecido: {fix_type}"})

    _set(appid, {"status": "queued", "fixType": fix_type})
    t = threading.Thread(target=_fix_worker, args=(appid, url, install_path, fix_type), daemon=True)
    t.start()
    return json.dumps({"success": True})


def apply_fix_url(appid: int, url: str, fix_type: str) -> str:
    """Aplica fix a partir de URL customizada (usada pelo RyuuFix e outros)."""
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    install_path = get_game_install_path(appid)
    if not install_path:
        return json.dumps({"success": False, "error": "Caminho de instalação não encontrado"})

    _set(appid, {"status": "queued", "fixType": fix_type})
    t = threading.Thread(target=_fix_worker, args=(appid, url, install_path, fix_type), daemon=True)
    t.start()
    return json.dumps({"success": True})


def get_fix_status(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})
    return json.dumps({"success": True, "state": _get(appid)})


def cancel_fix(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})
    _set(appid, {"status": "cancelled"})
    return json.dumps({"success": True})


def remove_fix(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    install_path = get_game_install_path(appid)
    if not install_path:
        return json.dumps({"success": False, "error": "Jogo não encontrado"})

    manifest_path = backend_path("data", f"fix_manifest_{appid}.json")
    removed = []
    errors  = []

    if os.path.exists(manifest_path):
        try:
            with open(manifest_path, "r", encoding="utf-8") as mf:
                manifest = json.load(mf)
            for rel_path in manifest.get("files", []):
                full_path = os.path.join(install_path, rel_path)
                if os.path.exists(full_path):
                    try:
                        os.remove(full_path)
                        removed.append(rel_path)
                    except Exception as e:
                        errors.append(str(e))
            os.remove(manifest_path)
        except Exception as e:
            logger.warn(f"GameFixer: erro ao ler manifesto {appid}: {e}")

    if errors and not removed:
        return json.dumps({"success": False, "error": "; ".join(errors)})

    return json.dumps({
        "success": True,
        "removed": removed,
        "count": len(removed),
        "message": f"{len(removed)} arquivo(s) removido(s)" if removed else "Nenhum arquivo de fix encontrado",
    })