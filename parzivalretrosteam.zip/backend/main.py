"""GameFixer — entry point do plugin Millennium."""

from __future__ import annotations

import json
import os
import shutil

import Millennium  # type: ignore
import PluginUtils  # type: ignore

from config import PLUGIN_NAME, PLUGIN_VERSION, WEBKIT_DIR_NAME, WEB_UI_JS_FILE, WEB_UI_ICON_FILE
from downloads import (
    cancel_download,
    cancel_queue_download,
    delete_lua_for_app,
    dismiss_loaded_apps,
    get_api_list,
    get_download_status,
    has_lua_for_app,
    process_download_queue,
    queue_download_after_restart,
    read_loaded_apps,
    start_download,
)
from fixes import (
    apply_fix,
    apply_fix_url,
    cancel_fix,
    check_fixes,
    detect_drm,
    get_fix_status,
    remove_fix,
)
from http_client import close_client
from logger import logger
from paths import backend_path, public_path, plugin_dir
from steam_utils import get_game_install_path, get_steam_path, restart_steam
from updater import check_and_update, get_update_status
from ost_updater import check_and_update_ost, get_ost_update_status
from auth import activate, get_auth_status, is_authenticated, validate_online, check_on_startup, transfer_license

# Guarda o resultado do check_on_startup para o JS consultar via GetStartupStatus
_startup_auth_status: str = "pending"


# ── JS copy + injection (same pattern as LuaTools) ───────────────────────────

def _steam_ui_path() -> str:
    return os.path.join(Millennium.steam_path(), "steamui", WEBKIT_DIR_NAME)


def _copy_webkit_files() -> None:
    """Copia o JS e ícone para steam/steamui/GameFixer/ antes de injetar."""
    try:
        dest_dir = _steam_ui_path()
        os.makedirs(dest_dir, exist_ok=True)

        js_src = public_path(WEB_UI_JS_FILE)
        js_dst = os.path.join(dest_dir, WEB_UI_JS_FILE)
        if os.path.exists(js_src):
            shutil.copy(js_src, js_dst)
            logger.log(f"{PLUGIN_NAME}: JS copiado para {js_dst}")
        else:
            logger.error(f"{PLUGIN_NAME}: JS não encontrado em {js_src}")

        icon_src = public_path(WEB_UI_ICON_FILE)
        icon_dst = os.path.join(dest_dir, WEB_UI_ICON_FILE)
        if os.path.exists(icon_src):
            shutil.copy(icon_src, icon_dst)
    except Exception as e:
        logger.error(f"{PLUGIN_NAME}: falha ao copiar arquivos: {e}")


def _inject_webkit_files() -> None:
    """Registra o JS no Millennium para injeção nas páginas do Steam."""
    try:
        js_path = os.path.join(WEBKIT_DIR_NAME, WEB_UI_JS_FILE)
        Millennium.add_browser_js(js_path)
        logger.log(f"{PLUGIN_NAME}: JS registrado para injeção: {js_path}")
    except Exception as e:
        logger.error(f"{PLUGIN_NAME}: falha ao registrar JS: {e}")


# ── Download de manifesto Lua ─────────────────────────────────────────────────

def StartDownload(appid: int, game_name: str = "", contentScriptQuery: str = "") -> str:
    return start_download(int(appid), str(game_name))

def GetDownloadStatus(appid: int, contentScriptQuery: str = "") -> str:
    return get_download_status(int(appid))

def CancelDownload(appid: int, contentScriptQuery: str = "") -> str:
    return cancel_download(int(appid))

def GetApiList(contentScriptQuery: str = "") -> str:
    return get_api_list()

def HasLuaForApp(appid: int, contentScriptQuery: str = "") -> str:
    return has_lua_for_app(int(appid))

def ReadLoadedApps(contentScriptQuery: str = "") -> str:
    return read_loaded_apps()

def DismissLoadedApps(contentScriptQuery: str = "") -> str:
    return dismiss_loaded_apps()

# ── Fixes ─────────────────────────────────────────────────────────────────────

def CheckFixes(appid: int, game_name: str = "", contentScriptQuery: str = "") -> str:
    return check_fixes(int(appid), str(game_name))

def ApplyFix(appid: int, fix_type: str, contentScriptQuery: str = "") -> str:
    return apply_fix(int(appid), str(fix_type))

def ApplyFixUrl(appid: int, url: str, fix_type: str, contentScriptQuery: str = "") -> str:
    return apply_fix_url(int(appid), str(url), str(fix_type))

def GetFixStatus(appid: int, contentScriptQuery: str = "") -> str:
    return get_fix_status(int(appid))

def CancelFix(appid: int, contentScriptQuery: str = "") -> str:
    return cancel_fix(int(appid))

# ── DRM ───────────────────────────────────────────────────────────────────────

def DetectDrm(appid: int, contentScriptQuery: str = "") -> str:
    return detect_drm(int(appid))

# ── Steam utils ───────────────────────────────────────────────────────────────

def GetGameInstallPath(appid: int, contentScriptQuery: str = "") -> str:
    path = get_game_install_path(int(appid))
    return json.dumps({"success": bool(path), "installPath": path or ""})

def RestartSteam(appid: int = 0, contentScriptQuery: str = "") -> str:
    ok = restart_steam(auto_install_appid=int(appid) if appid else 0)
    return json.dumps({"success": ok})

def GetPluginInfo(contentScriptQuery: str = "") -> str:
    return json.dumps({"name": PLUGIN_NAME, "version": PLUGIN_VERSION})


def RemoveFix(appid: int, contentScriptQuery: str = "") -> str:
    return remove_fix(int(appid))


def DeleteLuaForApp(appid: int, contentScriptQuery: str = "") -> str:
    """Remove o arquivo .lua do stplug-in (desfaz download de manifesto)."""
    return delete_lua_for_app(int(appid))


def RemoveFixAndRepair(appid: int, contentScriptQuery: str = "") -> str:
    """Remove o fix e agenda repair via Steam após reinício."""
    result = remove_fix(int(appid))
    try:
        data = json.loads(result)
        if data.get("success"):
            repair_queue = os.path.join(os.path.dirname(__file__), "data", "repair_queue.txt")
            os.makedirs(os.path.dirname(repair_queue), exist_ok=True)
            with open(repair_queue, "a", encoding="utf-8") as f:
                f.write(f"{appid}\n")
            data["repairQueued"] = True
            result = json.dumps(data)
    except Exception:
        pass
    return result


def FetchFreeApisNow(contentScriptQuery: str = "") -> str:
    """Atualiza a lista de servidores com o manifesto público de APIs gratuitas."""
    from api_loader import fetch_free_apis_now
    return fetch_free_apis_now()


def QueueDownloadAfterRestart(appid: int, contentScriptQuery: str = "") -> str:
    """Salva o appid na fila de download Lua para ser baixado após reiniciar a Steam."""
    return queue_download_after_restart(int(appid))

def CancelQueueDownload(appid: int, contentScriptQuery: str = "") -> str:
    """Remove o appid da fila de download pós-reinício."""
    return cancel_queue_download(int(appid))


# ── Auto-update ───────────────────────────────────────────────────────────────

def CheckForUpdates(contentScriptQuery: str = "") -> str:
    import Millennium  # type: ignore
    check_and_update(silent=False, steam_path=Millennium.steam_path())
    return json.dumps({"started": True})

def GetUpdateStatus(contentScriptQuery: str = "") -> str:
    return get_update_status()

def CheckForOstUpdates(contentScriptQuery: str = "") -> str:
    """Força verificação manual de update do OpenSteamTool."""
    import Millennium  # type: ignore
    check_and_update_ost(silent=False, steam_path=Millennium.steam_path())
    return json.dumps({"started": True})

def GetOstUpdateStatus(contentScriptQuery: str = "") -> str:
    """Retorna o estado atual do updater do OpenSteamTool."""
    return get_ost_update_status()

# ── Autenticação ──────────────────────────────────────────────────────────────

def GetStartupStatus(contentScriptQuery: str = "") -> str:
    """Retorna o resultado do check_on_startup para o JS tratar hwid_stolen."""
    return json.dumps({"status": _startup_auth_status})

def GetAuthStatus(contentScriptQuery: str = "") -> str:
    """Estado atual de autenticação (autenticado, key mascarada, hwid parcial)."""
    return get_auth_status()

def Activate(key: str, contentScriptQuery: str = "") -> str:
    """Tenta ativar a key nesta máquina. Registra o HWID no Google Sheets."""
    global _startup_auth_status
    result = activate(str(key))
    if result.get("success"):
        _startup_auth_status = "ok"
    return json.dumps(result)

def TransferLicense(key: str, contentScriptQuery: str = "") -> str:
    """Transfere a licença para este PC (PC novo) — chamado após hwid_mismatch."""
    global _startup_auth_status
    result = transfer_license(str(key))
    if result.get("success"):
        _startup_auth_status = "ok"
    return json.dumps(result)

def SelfDestruct(contentScriptQuery: str = "") -> str:
    """Chamado pelo frontend após 5 tentativas erradas — deleta a pasta do plugin."""
    from auth import _self_destruct
    _self_destruct("5 tentativas de ativacao incorretas")
    return json.dumps({"ok": True})


# ── Millennium Plugin lifecycle ───────────────────────────────────────────────

class Plugin:

    def _load(self):
        """Chamado pelo Millennium na inicialização. DEVE chamar Millennium.ready()."""
        logger.log(f"{PLUGIN_NAME} v{PLUGIN_VERSION}: iniciando...")

        # ── CAMINHO DA STEAM ──────────────────────────────────────────────────
        # Precisa vir primeiro: o update do plugin depende de saber onde a
        # Steam (e o plugin) estão instalados.
        try:
            get_steam_path()
        except Exception as e:
            logger.warn(f"{PLUGIN_NAME}: falha ao detectar Steam path: {e}")

        # ── UPDATE DO PLUGIN ──────────────────────────────────────────────────
        # Roda de forma síncrona (join) antes da autenticação — garante que
        # o usuário está sempre na versão mais recente antes de validar a licença.
        # Timeout de 30s: se o GitHub não responder, segue em frente normalmente.
        try:
            update_thread = check_and_update(silent=True, steam_path=Millennium.steam_path())
            update_thread.join(timeout=30)
            if update_thread.is_alive():
                logger.warn(f"{PLUGIN_NAME}: update demorou mais de 30s — seguindo sem esperar.")
        except Exception as e:
            logger.warn(f"{PLUGIN_NAME}: falha ao verificar update: {e}")

        # ── AUTENTICAÇÃO ──────────────────────────────────────────────────────
        # A verificação completa (com auto-destruição) só ativa após a tela de
        # ativação estar implementada no frontend. Por ora, apenas loga o estado.
        try:
            auth_result = check_on_startup()
            global _startup_auth_status
            if auth_result == "no_license":
                _startup_auth_status = "no_license"
                logger.log(f"{PLUGIN_NAME}: sem licença local — aguardando ativação.")
            elif auth_result == "hwid_stolen":
                _startup_auth_status = "hwid_stolen"
                logger.warn(f"{PLUGIN_NAME}: HWID diferente — aguardando reativação pelo usuário.")
            elif not auth_result:
                _startup_auth_status = "invalid"
                logger.warn(f"{PLUGIN_NAME}: autenticação inválida — plugin será removido.")
                Millennium.ready()
                return
            else:
                _startup_auth_status = "ok"
                logger.log(f"{PLUGIN_NAME}: autenticação OK.")
        except Exception as e:
            logger.warn(f"{PLUGIN_NAME}: erro na verificação de autenticação: {e}")

        try:
            _copy_webkit_files()
        except Exception as e:
            logger.warn(f"{PLUGIN_NAME}: falha ao copiar arquivos webkit: {e}")

        try:
            _inject_webkit_files()
        except Exception as e:
            logger.warn(f"{PLUGIN_NAME}: falha ao injetar JS: {e}")

        logger.log(f"{PLUGIN_NAME}: pronto.")

        try:
            check_and_update_ost(silent=True, steam_path=Millennium.steam_path())
        except Exception as e:
            logger.warn(f"{PLUGIN_NAME}: falha ao verificar update do OpenSteamTool: {e}")

        Millennium.ready()

    def _front_end_loaded(self):
        """Chamado quando o frontend do Steam carrega — processa downloads pendentes."""
        try:
            _copy_webkit_files()
        except Exception as e:
            logger.warn(f"{PLUGIN_NAME}: _front_end_loaded copy falhou: {e}")
        try:
            process_download_queue()
        except Exception as e:
            logger.warn(f"{PLUGIN_NAME}: process_download_queue falhou: {e}")

    def _unload(self):
        """Chamado quando o plugin é descarregado."""
        logger.log(f"{PLUGIN_NAME}: descarregando.")
        try:
            close_client()
        except Exception:
            pass
