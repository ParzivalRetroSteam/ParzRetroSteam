"""Logger simples para o GameFixer."""

import Millennium  # type: ignore


class _Logger:
    def log(self, msg: str) -> None:
        try:
            Millennium.log(str(msg))
        except Exception:
            print(str(msg))

    def warn(self, msg: str) -> None:
        try:
            Millennium.log(f"[WARN] {msg}")
        except Exception:
            print(f"[WARN] {msg}")

    def error(self, msg: str) -> None:
        try:
            Millennium.log(f"[ERROR] {msg}")
        except Exception:
            print(f"[ERROR] {msg}")


logger = _Logger()
