"""Utilitários Steam para o GameFixer."""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from typing import Dict, Optional

import Millennium  # type: ignore
from logger import logger

_STEAM_PATH: Optional[str] = None

if sys.platform.startswith("win"):
    try:
        import winreg  # type: ignore
    except Exception:
        winreg = None  # type: ignore
else:
    winreg = None  # type: ignore


def get_steam_path() -> str:
    global _STEAM_PATH
    if _STEAM_PATH:
        return _STEAM_PATH
    path = None
    if sys.platform.startswith("win") and winreg:
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
                path, _ = winreg.QueryValueEx(k, "SteamPath")
        except Exception:
            path = None
    if not path:
        try:
            path = Millennium.steam_path()
        except Exception:
            path = None
    _STEAM_PATH = path or ""
    logger.log(f"GameFixer: Steam path = {_STEAM_PATH}")
    return _STEAM_PATH


def _parse_vdf(content: str) -> Dict:
    result: Dict = {}
    stack = [result]
    current_key = None
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("//"):
            continue
        tokens = re.findall(r'"([^"]*)"', line)
        if line == "{":
            if current_key is not None:
                new = {}
                stack[-1][current_key] = new
                stack.append(new)
                current_key = None
        elif line == "}":
            if len(stack) > 1:
                stack.pop()
        elif len(tokens) == 1:
            current_key = tokens[0]
        elif len(tokens) >= 2:
            stack[-1][tokens[0]] = tokens[1]
            current_key = None
    return result


def _get_library_folders(steam_path: str):
    vdf = os.path.join(steam_path, "steamapps", "libraryfolders.vdf")
    if not os.path.exists(vdf):
        return [steam_path]
    try:
        with open(vdf, "r", encoding="utf-8", errors="replace") as f:
            data = _parse_vdf(f.read())
        folders = [steam_path]
        lf = data.get("libraryfolders") or data.get("LibraryFolders") or {}
        for v in lf.values():
            if isinstance(v, dict):
                p = v.get("path")
                if p and os.path.isdir(p):
                    folders.append(p)
            elif isinstance(v, str) and os.path.isdir(v):
                folders.append(v)
        return folders
    except Exception as e:
        logger.warn(f"GameFixer: erro ao ler libraryfolders: {e}")
        return [steam_path]


def get_game_install_path(appid: int) -> Optional[str]:
    steam = get_steam_path()
    if not steam:
        return None
    for lib in _get_library_folders(steam):
        manifest = os.path.join(lib, "steamapps", f"appmanifest_{appid}.acf")
        if os.path.exists(manifest):
            try:
                with open(manifest, "r", encoding="utf-8", errors="replace") as f:
                    data = _parse_vdf(f.read())
                info = data.get("AppState") or {}
                install_dir = info.get("installdir")
                if install_dir:
                    full = os.path.join(lib, "steamapps", "common", install_dir)
                    if os.path.isdir(full):
                        return full
            except Exception as e:
                logger.warn(f"GameFixer: erro ao ler manifest {appid}: {e}")
    return None


def get_lua_target_manifests(appid: int) -> Dict[str, str]:
    """Parseia o .lua e retorna {depot_id: manifest_id} de setManifestid()."""
    steam = get_steam_path()
    if not steam:
        return {}
    lua_path = os.path.join(steam, "config", "lua", f"{appid}.lua")
    if not os.path.exists(lua_path):
        return {}
    try:
        with open(lua_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        depots = {}
        for m in re.finditer(r'setManifestid\s*\(\s*(\d+)\s*,\s*"(\d+)"\s*\)', content):
            depots[m.group(1)] = m.group(2)
        return depots
    except Exception as e:
        logger.warn(f"GameFixer: erro ao ler lua {lua_path}: {e}")
        return {}


def get_installed_manifests(appid: int) -> Dict[str, str]:
    """Lê o .acf e retorna {depot_id: manifest_id} da seção MountedDepots."""
    steam = get_steam_path()
    if not steam:
        return {}
    for lib in _get_library_folders(steam):
        acf_path = os.path.join(lib, "steamapps", f"appmanifest_{appid}.acf")
        if os.path.exists(acf_path):
            try:
                with open(acf_path, "r", encoding="utf-8", errors="replace") as f:
                    data = _parse_vdf(f.read())
                info = data.get("AppState") or {}
                depots_raw = info.get("MountedDepots") or {}
                depots = {}
                for k, v in depots_raw.items():
                    if isinstance(v, str) and v.isdigit():
                        depots[k] = v
                return depots
            except Exception as e:
                logger.warn(f"GameFixer: erro ao ler .acf {appid}: {e}")
    return {}


def check_game_version(appid: int) -> str:
    """Compara manifests do .lua com os instalados. Retorna JSON."""
    lua = get_lua_target_manifests(appid)
    installed = get_installed_manifests(appid)
    has_lua = bool(lua)

    if not has_lua:
        return json.dumps({"has_lua": False, "match": None, "installed": bool(installed)})

    if not installed:
        return json.dumps({
            "has_lua": True,
            "installed": False,
            "match": None,
            "not_installed": True,
            "total": len(lua),
        })

    mismatches = []
    matches = []
    for depot, target in lua.items():
        current = installed.get(depot)
        if current == target:
            matches.append({"depot": depot})
        else:
            mismatches.append({
                "depot": depot,
                "target": target,
                "current": current or "não instalado",
            })

    return json.dumps({
        "has_lua": True,
        "installed": True,
        "match": len(mismatches) == 0,
        "matches": matches,
        "mismatches": mismatches,
        "total": len(lua),
        "ok": len(matches),
        "diff": len(mismatches),
    })


def restart_steam(auto_install_appid: int = 0) -> bool:
    """Reinicia o Steam via script cmd. Se auto_install_appid > 0, dispara steam://install após reiniciar."""
    from paths import backend_path
    script = backend_path("restart_steam.cmd")
    if not os.path.exists(script):
        logger.error("GameFixer: restart_steam.cmd não encontrado")
        return False
    try:
        CREATE_NO_WINDOW = 0x08000000
        cmd_args = ["cmd", "/C", script]
        if auto_install_appid and int(auto_install_appid) > 0:
            cmd_args.append(str(int(auto_install_appid)))
        subprocess.Popen(cmd_args, creationflags=CREATE_NO_WINDOW)
        logger.log(f"GameFixer: Steam restart iniciado (auto_install={auto_install_appid or 'none'})")
        return True
    except Exception as e:
        logger.error(f"GameFixer: falha ao reiniciar Steam: {e}")
        return False
