"""Lógica de download de manifesto Lua para o GameFixer."""

from __future__ import annotations

import json
import os
import threading
import zipfile
from typing import Any, Dict, Optional

import Millennium  # type: ignore

from api_loader import load_apis
from config import TEMP_DL_DIR, USER_AGENT
from http_client import get_client
from logger import logger
from paths import backend_path
from steam_utils import get_steam_path

# ── Estado de download (por appid) ──────────────────────────────────────────
_DL_STATE: Dict[int, Dict[str, Any]] = {}
_DL_LOCK = threading.Lock()


def _set(appid: int, update: dict) -> None:
    with _DL_LOCK:
        s = _DL_STATE.get(appid, {})
        s.update(update)
        _DL_STATE[appid] = s


def _get(appid: int) -> dict:
    with _DL_LOCK:
        return _DL_STATE.get(appid, {}).copy()


def _cancelled(appid: int) -> bool:
    return _get(appid).get("status") == "cancelled"


def _temp_dir() -> str:
    path = backend_path(TEMP_DL_DIR)
    os.makedirs(path, exist_ok=True)
    return path


def _stplug_dir() -> str:
    steam = get_steam_path()
    d = os.path.join(steam or "", "config", "lua")
    os.makedirs(d, exist_ok=True)
    return d


# ── Download worker ──────────────────────────────────────────────────────────

def _worker(appid: int, morrenus_key: str = "", from_queue: bool = False) -> None:
    client = get_client()
    apis = load_apis(morrenus_key)

    if not apis:
        _set(appid, {"status": "failed", "error": "Nenhuma API disponível"})
        return

    dest_zip = os.path.join(_temp_dir(), f"{appid}.zip")
    _set(appid, {"status": "checking", "currentApi": None, "bytesRead": 0, "totalBytes": 0, "apiStatus": {}})

    # Update api status display
    api_status = {a["name"]: "aguardando" for a in apis}
    _set(appid, {"apiStatus": api_status})

    for api in apis:
        name = api["name"]
        url = api["url"].replace("<appid>", str(appid))
        success_code = int(api.get("success_code", 200))
        unavail_code = int(api.get("unavailable_code", 404))

        if _cancelled(appid):
            return

        api_status = _get(appid).get("apiStatus", {})
        api_status[name] = "verificando"
        _set(appid, {"currentApi": name, "apiStatus": api_status})
        logger.log(f"GameFixer: tentando API '{name}' para appid {appid}")

        try:
            with client.stream("GET", url, headers={"User-Agent": USER_AGENT}, timeout=25) as resp:
                code = resp.status_code
                logger.log(f"GameFixer: API '{name}' → {code}")

                if code == unavail_code:
                    api_status = _get(appid).get("apiStatus", {})
                    api_status[name] = "indisponível"
                    _set(appid, {"apiStatus": api_status})
                    continue

                if code != success_code:
                    api_status = _get(appid).get("apiStatus", {})
                    api_status[name] = f"erro {code}"
                    _set(appid, {"apiStatus": api_status})
                    continue

                # Found — download
                total = int(resp.headers.get("Content-Length", "0") or "0")
                api_status = _get(appid).get("apiStatus", {})
                api_status[name] = "encontrado"
                _set(appid, {"status": "downloading", "bytesRead": 0, "totalBytes": total, "apiStatus": api_status})

                with open(dest_zip, "wb") as out:
                    for chunk in resp.iter_bytes():
                        if not chunk:
                            continue
                        if _cancelled(appid):
                            return
                        out.write(chunk)
                        read = _get(appid).get("bytesRead", 0) + len(chunk)
                        _set(appid, {"bytesRead": read})

                # Validate zip magic bytes
                with open(dest_zip, "rb") as fh:
                    magic = fh.read(4)
                if magic not in (b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"):
                    logger.warn(f"GameFixer: API '{name}' retornou arquivo inválido (magic={magic.hex()})")
                    try:
                        os.remove(dest_zip)
                    except Exception:
                        pass
                    api_status = _get(appid).get("apiStatus", {})
                    api_status[name] = "arquivo inválido"
                    _set(appid, {"apiStatus": api_status})
                    continue

                # Extract to lua
                _set(appid, {"status": "extracting"})
                stplug = _stplug_dir()
                extracted = []

                with zipfile.ZipFile(dest_zip, "r") as zf:
                    for member in zf.namelist():
                        if member.endswith("/"):
                            continue
                        # Only extract .lua files to lua
                        if not member.lower().endswith(".lua"):
                            continue
                        filename = os.path.basename(member)
                        if not filename:
                            continue
                        target = os.path.join(stplug, filename)
                        with zf.open(member) as src, open(target, "wb") as dst:
                            dst.write(src.read())
                        extracted.append(filename)
                        logger.log(f"GameFixer: extraído {filename}")

                if not extracted:
                    # Fallback: extract everything
                    with zipfile.ZipFile(dest_zip, "r") as zf:
                        for member in zf.namelist():
                            if member.endswith("/"):
                                continue
                            filename = os.path.basename(member)
                            if not filename:
                                continue
                            target = os.path.join(stplug, filename)
                            with zf.open(member) as src, open(target, "wb") as dst:
                                dst.write(src.read())
                            extracted.append(filename)

                # Cleanup temp zip
                try:
                    os.remove(dest_zip)
                except Exception:
                    pass

                _set(appid, {"status": "done", "success": True, "extractedFiles": extracted})
                logger.log(f"GameFixer: appid {appid} concluído via API '{name}'")
                return

        except RuntimeError as e:
            if "cancelled" in str(e):
                return
            api_status = _get(appid).get("apiStatus", {})
            api_status[name] = "erro"
            _set(appid, {"apiStatus": api_status})
            logger.warn(f"GameFixer: erro na API '{name}': {e}")
        except Exception as e:
            api_status = _get(appid).get("apiStatus", {})
            api_status[name] = "erro"
            _set(appid, {"apiStatus": api_status})
            logger.warn(f"GameFixer: erro na API '{name}': {e}")

    _set(appid, {"status": "failed", "error": "Nenhuma API encontrou o jogo"})
    logger.warn(f"GameFixer: appid {appid} não encontrado em nenhuma API")


# ── Public API ────────────────────────────────────────────────────────────────

def start_download(appid: int, game_name: str = "", morrenus_key: str = "", from_queue: bool = False) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    _set(appid, {"status": "queued", "gameName": game_name, "bytesRead": 0, "totalBytes": 0, "from_queue": from_queue})
    t = threading.Thread(target=_worker, args=(appid, morrenus_key, from_queue), daemon=True)
    t.start()
    return json.dumps({"success": True})


def get_download_status(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})
    return json.dumps({"success": True, "state": _get(appid)})


def cancel_download(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})
    _set(appid, {"status": "cancelled"})
    return json.dumps({"success": True})


def get_api_list() -> str:
    apis = load_apis()
    return json.dumps({"success": True, "apis": [{"name": a["name"]} for a in apis]})


def delete_lua_for_app(appid: int) -> str:
    """Remove o arquivo .lua do lua para este jogo (como LuaTools faz)."""
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "appid inválido"})

    stplug = _stplug_dir()
    paths_to_try = [
        os.path.join(stplug, f"{appid}.lua"),
        os.path.join(stplug, f"{appid}.lua.disabled"),
    ]
    deleted = []
    for path in paths_to_try:
        try:
            if os.path.exists(path):
                os.remove(path)
                deleted.append(path)
                logger.log(f"GameFixer: removido lua {path}")
        except Exception as e:
            logger.warn(f"GameFixer: falha ao remover {path}: {e}")

    return json.dumps({"success": True, "deleted": deleted, "count": len(deleted)})


def has_lua_for_app(appid: int) -> str:
    """Verifica se já existe .lua no lua para este jogo."""
    try:
        appid = int(appid)
        stplug = _stplug_dir()
        exists = (
            os.path.exists(os.path.join(stplug, f"{appid}.lua")) or
            os.path.exists(os.path.join(stplug, f"{appid}.lua.disabled"))
        )
        return json.dumps({"success": True, "exists": exists})
    except Exception as e:
        return json.dumps({"success": False, "exists": False, "error": str(e)})



