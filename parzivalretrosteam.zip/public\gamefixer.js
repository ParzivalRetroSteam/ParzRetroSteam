// GameFixer — Frontend Plugin v2.1
// Layout: abas inferiores (Adicionar / Corrigir / Gerenciar / Buscar)

(function () {
    'use strict';

    const WEBKIT_DIR_NAME = 'ParzivalRetroSteam';
    const PLUGIN_NAME    = 'Parzival Retrô Steam';
    let PLUGIN_VERSION = '2.1';

    const BACKEND        = 'parzivalretrosteam';

    // Mapeamento de nomes reais de APIs para nomes genéricos (ordem do api.json)
    const API_NAME_MAP = {
        'Ryuu':             'Fonte 1',
        'SkyApi':           'Fonte 2',
        'TwentyTwo Cloud':  'Fonte 3',
        'Sushi':            'Fonte 4',
        'Morrenus':         'Fonte 5',
    };
    function maskApiName(name) {
        if (API_NAME_MAP[name]) return API_NAME_MAP[name];
        // Fallback: gera um nome genérico baseado no índice da API
        return name;
    }

    function call(method, args) {
        return Millennium.callServerMethod(BACKEND, method, Object.assign({ contentScriptQuery: '' }, args || {}));
    }

    function $(sel, ctx)  { return (ctx || document).querySelector(sel); }
    function $$(sel, ctx) { return Array.from((ctx || document).querySelectorAll(sel)); }

    function el(tag, css, html) {
        const e = document.createElement(tag);
        if (css)              e.style.cssText = css;
        if (html !== undefined) e.innerHTML = html;
        return e;
    }
    function div(css, html) { return el('div', css, html); }
    function parseJson(r) { try { return typeof r === 'string' ? JSON.parse(r) : r; } catch (_) { return null; } }

    // ── Estilos ────────────────────────────────────────────────────────────────
    function injectStyles() {
        if (document.getElementById('gf-styles')) return;
        const s = document.createElement('style');
        s.id = 'gf-styles';
        s.textContent = `
            @keyframes gf-up   { from{opacity:0;transform:translateY(16px) scale(.97)} to{opacity:1;transform:none} }
            @keyframes gf-in   { from{opacity:0} to{opacity:1} }
            @keyframes gf-spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }

            .gf-o * { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif !important; box-sizing:border-box; }

            /* ── Modal shell ── */
            .gf-modal {
                background:#0d0d0d;
                border-radius:18px;
                overflow:hidden;
                box-shadow:0 32px 90px rgba(0,0,0,.92), 0 0 0 1px rgba(255,255,255,.055);
                animation:gf-up .2s cubic-bezier(.16,1,.3,1);
                display:flex;
                flex-direction:column;
            }

            /* ── Hero ── */
            .gf-hero { position:relative; height:155px; overflow:hidden; flex-shrink:0; }
            .gf-hero-bg { position:absolute;inset:0; background:linear-gradient(120deg,rgba(80,0,0,.5),rgba(15,0,0,.95)); }
            .gf-hero-gl { position:absolute;inset:0;background:linear-gradient(to right,rgba(13,13,13,.96) 0%,rgba(13,13,13,.5) 60%,rgba(13,13,13,.15) 100%); }
            .gf-hero-gb { position:absolute;bottom:0;left:0;right:0;height:70px;background:linear-gradient(to top,#0d0d0d,transparent); }
            .gf-hero-top { position:absolute;top:0;left:0;right:0;z-index:5;display:flex;align-items:center;justify-content:space-between;padding:13px 16px; }
            .gf-hero-logo { font-size:8.5px;font-weight:900;letter-spacing:4px;color:rgba(255,255,255,.22);text-transform:uppercase; }
            .gf-hero-logo span { color:#dc0000; }
            .gf-hero-info { position:absolute;bottom:14px;left:18px;right:18px;z-index:4; }
            .gf-eyebrow { font-size:8.5px;font-weight:700;letter-spacing:4px;color:rgba(220,0,0,.6);text-transform:uppercase;margin-bottom:4px;display:flex;align-items:center;gap:6px; }
            .gf-eyebrow-line { width:12px;height:1px;background:rgba(220,0,0,.45);display:inline-block; }
            .gf-hero-title { font-size:20px;font-weight:900;color:#fff;letter-spacing:-.4px;line-height:1.08; }
            .gf-hero-meta { font-size:10px;color:rgba(255,255,255,.22);margin-top:4px;display:flex;align-items:center;gap:6px; }
            .gf-dot-green { width:5px;height:5px;border-radius:50%;background:#3cb85e;box-shadow:0 0 5px #3cb85e;display:inline-block; }

            /* ── Pane area ── */
            .gf-pane-area { flex:1; overflow-y:auto; min-height:0; }
            .gf-pane { display:none; animation:gf-in .15s ease; flex-direction:column; }
            .gf-pane.on { display:flex; }

            /* ── Bottom tab bar ── */
            .gf-tabbar {
                display:flex;
                border-top:1px solid rgba(255,255,255,.06);
                background:#080808;
                flex-shrink:0;
                padding:2px 0 0;
            }
            .gf-tab {
                flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center;
                padding:9px 4px 10px;
                font-size:9px; font-weight:800; letter-spacing:1.2px; text-transform:uppercase;
                color:rgba(255,255,255,.22); cursor:pointer; transition:all .14s;
                position:relative; gap:4px; border:none; background:none;
            }
            .gf-tab:hover { color:rgba(255,255,255,.45); }
            .gf-tab.on { color:#fff; }
            .gf-tab.on::before {
                content:'';
                position:absolute;top:0;left:50%;transform:translateX(-50%);
                width:28px;height:2px;background:#dc0000;border-radius:0 0 3px 3px;
            }
            .gf-tab-icon { font-size:16px; line-height:1; }

            /* ── Sections ── */
            .gf-sec { padding:16px 18px; }
            .gf-sec + .gf-sec { border-top:1px solid rgba(255,255,255,.04); }
            .gf-sec-ttl {
                font-size:9px;font-weight:800;letter-spacing:2.5px;text-transform:uppercase;
                color:rgba(255,255,255,.18);margin-bottom:13px;
            }
            .gf-divider { height:1px;background:rgba(255,255,255,.04);flex-shrink:0; }

            /* ── Stat cards ── */
            .gf-stat-grid { display:grid;grid-template-columns:1fr 1fr;gap:8px; }
            .gf-stat-card {
                background:#141414;border:1px solid rgba(255,255,255,.055);border-radius:10px;padding:12px 14px;
            }
            .gf-stat-lbl { font-size:8.5px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,.18);margin-bottom:5px; }
            .gf-stat-val { font-size:14px;font-weight:800;color:#fff; }

            /* ── Big action button ── */
            .gf-big-btn {
                width:100%;padding:13px 0;border-radius:10px;
                background:linear-gradient(135deg,#dc0000,#8b0000);
                color:#fff;font-size:11px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase;
                cursor:pointer;transition:all .15s;border:none;
                box-shadow:0 4px 20px rgba(220,0,0,.35);
            }
            .gf-big-btn:hover { box-shadow:0 7px 28px rgba(220,0,0,.6);transform:translateY(-1px); }
            .gf-big-btn:active { transform:none; }

            /* ── Fix cards ── */
            .gf-fix-grid { display:grid;grid-template-columns:1fr 1fr;gap:8px; }
            .gf-fix-card {
                border-radius:11px;padding:14px;transition:all .17s;
                border:1px solid rgba(255,255,255,.06);background:#141414;position:relative;overflow:hidden;
            }
            .gf-fix-card.av  { background:#0e1710;border-color:rgba(60,184,94,.18);cursor:pointer; }
            .gf-fix-card.av:hover { border-color:rgba(60,184,94,.45);transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,.5); }
            .gf-fix-card.no  { opacity:.3;cursor:not-allowed; }
            .gf-fix-card-top { display:flex;align-items:center;justify-content:space-between;margin-bottom:10px; }
            .gf-fix-ico {
                width:30px;height:30px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:13px;
            }
            .gf-badge {
                font-size:8.5px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;
                padding:2px 7px;border-radius:20px;
            }
            .gf-badge.av { background:rgba(60,184,94,.12);color:rgba(60,184,94,.85); }
            .gf-badge.no { background:rgba(255,255,255,.04);color:rgba(255,255,255,.18); }

            /* ── Action rows ── */
            .gf-act {
                display:flex;align-items:center;gap:13px;padding:13px 18px;cursor:pointer;
                transition:background .12s;border-bottom:1px solid rgba(255,255,255,.04);
            }
            .gf-act:last-child { border-bottom:none; }
            .gf-act:hover { background:rgba(255,255,255,.03); }
            .gf-act-ico {
                width:36px;height:36px;border-radius:9px;display:flex;align-items:center;
                justify-content:center;flex-shrink:0;font-size:17px;
            }
            .gf-act-name { font-size:13px;font-weight:600;color:#fff; }
            .gf-act-sub  { font-size:11px;color:rgba(255,255,255,.27);margin-top:1px; }
            .gf-act-chev { font-size:18px;color:rgba(255,255,255,.14);margin-left:auto; }
            /* ── Progress ── */
            .gf-pw { height:3px;background:rgba(255,255,255,.06);border-radius:3px;overflow:hidden; }
            .gf-pf { height:100%;background:linear-gradient(90deg,#dc0000,#ff3333);border-radius:3px;transition:width .3s;width:0%; }
            .gf-pt { font-size:10px;color:rgba(255,255,255,.28);margin-top:5px;display:flex;justify-content:space-between; }

            /* ── Spinner ── */
            .gf-spinner {
                width:16px;height:16px;border:2px solid rgba(255,255,255,.1);border-top-color:#dc0000;
                border-radius:50%;animation:gf-spin .8s linear infinite;display:inline-block;flex-shrink:0;
            }

            /* ── Empty state ── */
            .gf-empty { text-align:center;padding:32px 20px;color:rgba(255,255,255,.2);font-size:13px;line-height:1.8; }

            /* ── Buttons (modais) ── */
            .gf-btn {
                padding:11px 0;border-radius:9px;font-size:11px;font-weight:800;letter-spacing:1px;
                text-transform:uppercase;cursor:pointer;transition:all .14s;border:none;width:100%;
            }
            .gf-btn.p { background:linear-gradient(135deg,#dc0000,#8b0000);color:#fff;box-shadow:0 4px 18px rgba(220,0,0,.4); }
            .gf-btn.p:hover { box-shadow:0 6px 26px rgba(220,0,0,.65);transform:translateY(-1px); }
            .gf-btn.s { background:#181818;color:rgba(255,255,255,.38);border:1px solid rgba(255,255,255,.07); }
            .gf-btn.s:hover { background:#222;color:rgba(255,255,255,.6); }

            ::-webkit-scrollbar { width:3px; }
            ::-webkit-scrollbar-track { background:transparent; }
            ::-webkit-scrollbar-thumb { background:rgba(220,0,0,.3);border-radius:3px; }

            /* ── Search pane ── */
            .gf-search-wrap { padding:16px 18px; }
            .gf-search-box {
                position:relative; display:flex; align-items:center; gap:9px;
                background:#141414; border:1px solid rgba(255,255,255,.07); border-radius:10px;
                padding:10px 13px; transition:border-color .15s,background .15s;
            }
            .gf-search-box.focused { border-color:rgba(220,0,0,.5); background:#161616; }
            .gf-search-ico { font-size:14px; color:rgba(255,255,255,.3); flex-shrink:0; line-height:1; }
            .gf-search-input {
                flex:1; min-width:0; background:transparent; border:none; outline:none;
                color:#fff; font-size:13px; font-family:inherit;
            }
            .gf-search-input::placeholder { color:rgba(255,255,255,.25); }
            .gf-search-clear {
                display:none; width:20px; height:20px; border-radius:50%;
                background:rgba(255,255,255,.08); border:none; cursor:pointer; flex-shrink:0;
                color:rgba(255,255,255,.5); font-size:11px; line-height:1; align-items:center; justify-content:center;
            }
            .gf-search-clear:hover { background:rgba(220,0,0,.25); color:#fff; }
            .gf-search-clear.visible { display:flex; }

            .gf-search-hint { font-size:10px; color:rgba(255,255,255,.2); margin-top:8px; letter-spacing:.3px; }

            .gf-search-results { margin-top:14px; display:flex; flex-direction:column; gap:6px; }

            .gf-search-row {
                display:flex; align-items:center; gap:11px; padding:8px 10px; border-radius:10px;
                background:rgba(255,255,255,.025); border:1px solid rgba(255,255,255,.05);
                cursor:pointer; transition:all .14s; position:relative; overflow:hidden;
            }
            .gf-search-row::before {
                content:''; position:absolute; left:0; top:0; bottom:0; width:2px;
                background:linear-gradient(to bottom,#dc0000,transparent); opacity:0; transition:opacity .14s;
            }
            .gf-search-row:hover {
                background:rgba(220,0,0,.07); border-color:rgba(220,0,0,.2); transform:translateX(-2px);
            }
            .gf-search-row:hover::before { opacity:1; }

            .gf-search-img {
                width:69px; height:33px; border-radius:5px; object-fit:cover; flex-shrink:0;
                background:#0a0a0a; display:block;
            }
            .gf-search-info { flex:1; min-width:0; }
            .gf-search-name {
                font-size:12px; font-weight:700; color:#fff; line-height:1.25;
                white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
            }
            .gf-search-meta {
                font-size:9.5px; color:rgba(255,255,255,.28); margin-top:3px;
                display:flex; align-items:center; gap:6px; flex-wrap:wrap;
            }
            .gf-search-appid { letter-spacing:.4px; }
            .gf-search-arr { font-size:15px; color:rgba(255,255,255,.12); flex-shrink:0; transition:color .14s; }
            .gf-search-row:hover .gf-search-arr { color:rgba(220,0,0,.7); }

            .gf-search-state {
                text-align:center; padding:30px 18px; color:rgba(255,255,255,.22);
                font-size:12px; line-height:1.7;
            }
            .gf-search-state .gf-search-state-ico { font-size:26px; display:block; margin-bottom:10px; opacity:.5; }
            .gf-search-loading { display:inline-flex; align-items:center; gap:8px; color:rgba(255,255,255,.35); }
        `;
        document.head.appendChild(s);
    }

    // ── Helpers UI ─────────────────────────────────────────────────────────────
    function overlay(z) {
        return div(
            'position:fixed;inset:0;background:rgba(0,0,0,.88);backdrop-filter:blur(22px);' +
            'z-index:' + (z || 99999) + ';display:flex;align-items:center;justify-content:center;'
        );
    }
    function mkBtn(text, pri) {
        const b = el('button');
        b.className = 'gf-btn ' + (pri ? 'p' : 's');
        b.textContent = text;
        return b;
    }
    function xBtn(onClick) {
        const b = div(
            'width:28px;height:28px;border-radius:50%;background:rgba(0,0,0,.55);' +
            'border:1px solid rgba(255,255,255,.08);display:flex;align-items:center;' +
            'justify-content:center;cursor:pointer;transition:all .13s;' +
            'font-size:11px;color:rgba(255,255,255,.45);flex-shrink:0;'
        );
        b.textContent = '✕';
        b.onmouseover = function () { this.style.background = 'rgba(220,0,0,.22)'; this.style.borderColor = 'rgba(220,0,0,.4)'; };
        b.onmouseout  = function () { this.style.background = 'rgba(0,0,0,.55)';   this.style.borderColor = 'rgba(255,255,255,.08)'; };
        b.onclick = onClick;
        return b;
    }

    // ── Game detection ─────────────────────────────────────────────────────────
    function getAppId() {
        const m = window.location.href.match(/\/app\/(\d+)/);
        return m ? parseInt(m[1], 10) : NaN;
    }
    function getGameName() {
        try {
            const e = $('.apphub_AppName') || $('[class*="gameTitle"]') || $('h1');
            return e ? e.textContent.trim() : '';
        } catch (_) { return ''; }
    }

    // ── Hero ───────────────────────────────────────────────────────────────────
    function heroBlock(appid, gameName, onClose) {
        const isApp = !isNaN(appid);
        const wrap = div(''); wrap.className = 'gf-hero';
        const bg = div(''); bg.className = 'gf-hero-bg';
        if (isApp) {
            try {
                const img = $('img.game_header_image_full') || $('[class*="headerImage"] img') || $('img[src*="header"]');
                if (img && img.src) bg.style.background = 'url("' + img.src + '") center/cover';
            } catch (_) {}
        }
        const gl = div(''); gl.className = 'gf-hero-gl';
        const gb = div(''); gb.className = 'gf-hero-gb';
        const top = div(''); top.className = 'gf-hero-top';
        const logo = div(''); logo.className = 'gf-hero-logo';
        logo.innerHTML = '<span>' + PLUGIN_NAME + '</span>';
        top.appendChild(logo);
        top.appendChild(xBtn(onClose));
        const info = div(''); info.className = 'gf-hero-info';
        const eyebrow = div(''); eyebrow.className = 'gf-eyebrow';
        eyebrow.innerHTML = '<span class="gf-eyebrow-line"></span>' + (isApp ? 'Jogo detectado' : 'Configurações');
        const title = div(''); title.className = 'gf-hero-title';
        title.textContent = isApp ? (gameName || 'Jogo ' + appid) : PLUGIN_NAME;
        const meta = div(''); meta.className = 'gf-hero-meta';
        if (isApp) meta.innerHTML = '<span class="gf-dot-green"></span>Instalado';
        else { meta.textContent = 'v' + PLUGIN_VERSION; meta.className += ' gf-ver'; }
        info.appendChild(eyebrow); info.appendChild(title); info.appendChild(meta);
        wrap.appendChild(bg); wrap.appendChild(gl); wrap.appendChild(gb);
        wrap.appendChild(top); wrap.appendChild(info);
        return wrap;
    }

    // ── Dialogs ────────────────────────────────────────────────────────────────
    function showAlert(msg) {
        injectStyles();
        const o = overlay(100002); o.classList.add('gf-o');
        const m = div(''); m.className = 'gf-modal'; m.style.width = '340px';
        const h = div('padding:15px 18px 13px;border-bottom:1px solid rgba(255,255,255,.06);background:linear-gradient(90deg,rgba(220,0,0,.1),transparent 70%);');
        h.innerHTML = '<div style="font-size:10px;font-weight:800;letter-spacing:3px;color:#dc0000;text-transform:uppercase;">' + PLUGIN_NAME + '</div>';
        const b = div('padding:18px;font-size:13px;color:rgba(255,255,255,.55);line-height:1.65;'); b.textContent = msg;
        const f = div('padding:10px 18px 16px;');
        const ok = mkBtn('OK', true); ok.onclick = function () { o.remove(); }; f.appendChild(ok);
        o.addEventListener('click', function (e) { if (e.target === o) o.remove(); });
        m.appendChild(h); m.appendChild(b); m.appendChild(f); o.appendChild(m); document.body.appendChild(o);
    }
    function showConfirm(msg, onYes, confirmLabel) {
        injectStyles();
        const o = overlay(100002); o.classList.add('gf-o');
        const m = div(''); m.className = 'gf-modal'; m.style.width = '340px';
        const h = div('padding:15px 18px 13px;border-bottom:1px solid rgba(255,255,255,.06);background:linear-gradient(90deg,rgba(220,0,0,.1),transparent 70%);');
        h.innerHTML = '<div style="font-size:10px;font-weight:800;letter-spacing:3px;color:#dc0000;text-transform:uppercase;">' + PLUGIN_NAME + '</div>';
        const b = div('padding:18px;font-size:13px;color:rgba(255,255,255,.55);line-height:1.65;'); b.textContent = msg;
        const f = div('padding:10px 18px 16px;display:flex;gap:8px;');
        const c = mkBtn('Cancelar', false); const ok = mkBtn(confirmLabel || 'Confirmar', true);
        c.style.flex = ok.style.flex = '1';
        c.onclick = function () { o.remove(); };
        ok.onclick = function () { o.remove(); onYes(); };
        o.addEventListener('click', function (e) { if (e.target === o) o.remove(); });
        f.appendChild(c); f.appendChild(ok);
        m.appendChild(h); m.appendChild(b); m.appendChild(f); o.appendChild(m); document.body.appendChild(o);
    }

    // ── Download popup — Pipeline de Estágios ───────────────────────────────────
    function showDownloadPopup(appid, gameName) {
        if ($('.gf-dl-o')) return;
        injectStyles();

        // Estilos exclusivos do novo popup
        if (!document.getElementById('gf-pipeline-styles')) {
            var ps = document.createElement('style');
            ps.id = 'gf-pipeline-styles';
            ps.textContent = [
                '@keyframes gf-pip-pulse{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.7);opacity:.3}}',
                '@keyframes gf-pip-border{0%,100%{border-color:rgba(220,50,50,.3)}50%{border-color:rgba(220,50,50,.75)}}',
                '@keyframes gf-pip-scan{0%{opacity:0}50%{opacity:1}100%{opacity:0}}',
                '.gf-pip-modal{background:#111;border-radius:16px;overflow:hidden;',
                '  box-shadow:0 32px 90px rgba(0,0,0,.92),0 0 0 1px rgba(255,255,255,.06);',
                '  animation:gf-up .2s cubic-bezier(.16,1,.3,1);display:flex;flex-direction:column;width:460px;}',

                // Header
                '.gf-pip-head{padding:18px 18px 16px;border-bottom:1px solid rgba(255,255,255,.05);',
                '  display:flex;align-items:flex-start;justify-content:space-between;flex-shrink:0;}',
                '.gf-pip-pill{display:inline-flex;align-items:center;gap:6px;padding:3px 10px;',
                '  border-radius:20px;background:rgba(220,50,50,.1);border:1px solid rgba(220,50,50,.2);margin-bottom:7px;}',
                '.gf-pip-pill-dot{width:5px;height:5px;border-radius:50%;background:#dc3232;',
                '  animation:gf-pip-pulse 1.2s ease-in-out infinite;}',
                '.gf-pip-pill-txt{font-size:9px;font-weight:800;letter-spacing:2.5px;',
                '  text-transform:uppercase;color:rgba(220,60,60,.85);}',
                '.gf-pip-game{font-size:17px;font-weight:800;color:#fff;line-height:1.2;}',
                '.gf-pip-appid{font-size:10px;color:rgba(255,255,255,.2);margin-top:3px;}',

                // Body
                '.gf-pip-body{padding:16px 18px;flex:1;display:flex;flex-direction:column;gap:14px;}',

                // Stages
                '.gf-pip-stages{display:flex;flex-direction:column;gap:6px;}',
                '.gf-pip-stage{display:flex;align-items:center;gap:12px;padding:10px 12px;',
                '  border-radius:10px;border:1px solid rgba(255,255,255,.05);background:rgba(255,255,255,.02);',
                '  transition:border-color .25s,background .25s;}',
                '.gf-pip-stage.pip-done{border-color:rgba(60,184,94,.18);background:rgba(60,184,94,.04);}',
                '.gf-pip-stage.pip-active{border-color:rgba(220,50,50,.3);background:rgba(220,50,50,.05);',
                '  animation:gf-pip-border 1.2s ease-in-out infinite;}',
                '.gf-pip-ico{width:30px;height:30px;border-radius:50%;display:flex;align-items:center;',
                '  justify-content:center;font-size:13px;flex-shrink:0;',
                '  background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);',
                '  color:rgba(255,255,255,.2);transition:all .25s;}',
                '.gf-pip-stage.pip-done .gf-pip-ico{background:rgba(60,184,94,.12);',
                '  border-color:rgba(60,184,94,.3);color:#3cb85e;}',
                '.gf-pip-stage.pip-active .gf-pip-ico{background:rgba(220,50,50,.12);',
                '  border-color:rgba(220,50,50,.35);color:#dc3232;}',
                '.gf-pip-info{flex:1;min-width:0;}',
                '.gf-pip-name{font-size:12px;font-weight:700;color:rgba(255,255,255,.25);transition:color .25s;}',
                '.gf-pip-stage.pip-done .gf-pip-name{color:rgba(255,255,255,.45);}',
                '.gf-pip-stage.pip-active .gf-pip-name{color:#fff;}',
                '.gf-pip-detail{font-size:10px;color:rgba(255,255,255,.15);margin-top:2px;transition:color .25s;}',
                '.gf-pip-stage.pip-active .gf-pip-detail{color:rgba(220,60,60,.6);}',
                '.gf-pip-stage.pip-done .gf-pip-detail{color:rgba(60,184,94,.5);}',

                // Progress bar
                '.gf-pip-bar-wrap{display:none;}',
                '.gf-pip-bar-top{display:flex;justify-content:space-between;',
                '  font-size:10px;color:rgba(255,255,255,.25);margin-bottom:7px;}',
                '.gf-pip-bar-pct{font-size:13px;font-weight:800;color:#fff;}',
                '.gf-pip-track{height:3px;background:rgba(255,255,255,.06);border-radius:2px;',
                '  overflow:hidden;position:relative;}',
                '.gf-pip-fill{height:100%;width:0%;background:linear-gradient(90deg,#dc3232,#ff5555);',
                '  border-radius:2px;transition:width .35s ease;position:relative;}',
                '.gf-pip-fill::after{content:"";position:absolute;right:0;top:0;height:100%;width:32px;',
                '  background:linear-gradient(90deg,transparent,rgba(255,255,255,.45));',
                '  animation:gf-pip-scan .8s linear infinite;}',
                '.gf-pip-bar-stats{display:flex;justify-content:space-between;margin-top:7px;}',
                '.gf-pip-stat{text-align:center;}',
                '.gf-pip-stat-v{font-size:12px;font-weight:700;color:#fff;}',
                '.gf-pip-stat-l{font-size:9px;color:rgba(255,255,255,.18);letter-spacing:1px;',
                '  text-transform:uppercase;margin-top:1px;}',

                // Servers grid
                '.gf-pip-servers{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;}',
                '.gf-pip-srv{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);',
                '  border-radius:8px;padding:8px 10px;transition:border-color .2s,background .2s;}',
                '.gf-pip-srv.srv-checking{border-color:rgba(220,50,50,.3);background:rgba(220,50,50,.06);}',
                '.gf-pip-srv.srv-found{border-color:rgba(60,184,94,.35);background:rgba(60,184,94,.06);}',
                '.gf-pip-srv.srv-miss{opacity:.28;}',
                '.gf-pip-srv-name{font-size:11px;font-weight:700;color:rgba(255,255,255,.4);}',
                '.gf-pip-srv.srv-checking .gf-pip-srv-name{color:rgba(220,60,60,.85);}',
                '.gf-pip-srv.srv-found .gf-pip-srv-name{color:rgba(60,184,94,.9);}',
                '.gf-pip-srv-st{font-size:9px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;',
                '  color:rgba(255,255,255,.18);margin-top:3px;display:flex;align-items:center;gap:4px;}',
                '.gf-pip-srv.srv-checking .gf-pip-srv-st{color:rgba(220,60,60,.6);}',
                '.gf-pip-srv.srv-found .gf-pip-srv-st{color:rgba(60,184,94,.7);}',
                '.gf-pip-srv-dot{width:5px;height:5px;border-radius:50%;background:rgba(255,255,255,.12);',
                '  flex-shrink:0;transition:background .2s;}',
                '.gf-pip-srv.srv-checking .gf-pip-srv-dot{background:rgba(220,50,50,.9);',
                '  animation:gf-pip-pulse 1s ease-in-out infinite;}',
                '.gf-pip-srv.srv-found .gf-pip-srv-dot{background:rgba(60,184,94,.9);}',

                // Footer
                '.gf-pip-foot{padding:10px 18px 16px;flex-shrink:0;}',
            ].join('');
            document.head.appendChild(ps);
        }

        const o = overlay(); o.className = 'gf-o gf-dl-o';
        const m = div(''); m.className = 'gf-pip-modal';

        // ── Header ──
        var head = div(''); head.className = 'gf-pip-head';
        var headLeft = div('');
        var pill = div(''); pill.className = 'gf-pip-pill';
        var pillDot = document.createElement('span'); pillDot.className = 'gf-pip-pill-dot';
        var pillTxt = document.createElement('span'); pillTxt.className = 'gf-pip-pill-txt';
        pillTxt.textContent = 'Preparando jogo';
        pill.appendChild(pillDot); pill.appendChild(pillTxt);
        var gameTitle = div(''); gameTitle.className = 'gf-pip-game';
        gameTitle.textContent = gameName || ('App ' + appid);
        var gameAppid = div(''); gameAppid.className = 'gf-pip-appid';
        gameAppid.textContent = 'APP ' + appid;
        headLeft.appendChild(pill); headLeft.appendChild(gameTitle); headLeft.appendChild(gameAppid);
        head.appendChild(headLeft);
        head.appendChild(xBtn(function () { o.remove(); }));

        // ── Body ──
        var body = div(''); body.className = 'gf-pip-body';

        // Stages
        var stagesWrap = div(''); stagesWrap.className = 'gf-pip-stages';

        function makeStage(ico, name, detail, id) {
            var s = div(''); s.className = 'gf-pip-stage'; s.dataset.stage = id;
            var icoEl = div(''); icoEl.className = 'gf-pip-ico'; icoEl.textContent = ico;
            var info = div(''); info.className = 'gf-pip-info';
            var nameEl = div(''); nameEl.className = 'gf-pip-name'; nameEl.textContent = name;
            var detailEl = div(''); detailEl.className = 'gf-pip-detail'; detailEl.textContent = detail;
            info.appendChild(nameEl); info.appendChild(detailEl);
            s.appendChild(icoEl); s.appendChild(info);
            return s;
        }

        var stageSearch   = makeStage('⊙', 'Verificando servidores', 'Localizando dados do jogo', 'search');
        var stageFound    = makeStage('◈', 'Servidor localizado',    'Aguardando confirmação',    'found');
        var stageDownload = makeStage('↓', 'Baixando',               'Aguardando',                'download');
        var stageInstall  = makeStage('⚙', 'Instalando',             'Aguardando',                'install');

        stagesWrap.appendChild(stageSearch);
        stagesWrap.appendChild(stageFound);
        stagesWrap.appendChild(stageDownload);
        stagesWrap.appendChild(stageInstall);
        body.appendChild(stagesWrap);

        // Progress bar (visível só ao baixar)
        var barWrap = div(''); barWrap.className = 'gf-pip-bar-wrap';
        var barTop = div(''); barTop.className = 'gf-pip-bar-top';
        var barPct = document.createElement('span'); barPct.className = 'gf-pip-bar-pct'; barPct.textContent = '0%';
        var barSize = document.createElement('span'); barSize.textContent = '— / —';
        barTop.appendChild(barPct); barTop.appendChild(barSize);
        var track = div(''); track.className = 'gf-pip-track';
        var fill = div(''); fill.className = 'gf-pip-fill';
        track.appendChild(fill);
        var barStats = div(''); barStats.className = 'gf-pip-bar-stats';
        function makeStat(id, lbl) {
            var s = div(''); s.className = 'gf-pip-stat';
            var v = div(''); v.className = 'gf-pip-stat-v'; v.id = id; v.textContent = '—';
            var l = div(''); l.className = 'gf-pip-stat-l'; l.textContent = lbl;
            s.appendChild(v); s.appendChild(l); return s;
        }
        barStats.appendChild(makeStat('gf-pip-dl', 'Baixado'));
        barStats.appendChild(makeStat('gf-pip-total', 'Total'));
        barStats.appendChild(makeStat('gf-pip-server', 'Servidor'));
        barWrap.appendChild(barTop); barWrap.appendChild(track); barWrap.appendChild(barStats);
        body.appendChild(barWrap);

        // Grid de servidores
        var srvGrid = div(''); srvGrid.className = 'gf-pip-servers';
        body.appendChild(srvGrid);

        // ── Footer ──
        var foot = div(''); foot.className = 'gf-pip-foot';
        var cancelBtn = mkBtn('Cancelar', false);
        cancelBtn.onclick = function () { call('CancelDownload', { appid: appid }); o.remove(); };
        foot.appendChild(cancelBtn);

        m.appendChild(head); m.appendChild(body); m.appendChild(foot);
        o.appendChild(m); document.body.appendChild(o);
        o.addEventListener('click', function (e) { if (e.target === o) o.remove(); });

        // Helpers de estágio
        function setStage(stageEl, state) {
            stageEl.classList.remove('pip-done', 'pip-active');
            if (state === 'done')   stageEl.classList.add('pip-done');
            if (state === 'active') stageEl.classList.add('pip-active');
        }
        function setStageDetail(stageEl, txt) {
            stageEl.querySelector('.gf-pip-detail').textContent = txt;
        }
        function setStageIco(stageEl, ico) {
            stageEl.querySelector('.gf-pip-ico').textContent = ico;
        }

        // Ativa estágio inicial
        setStage(stageSearch, 'active');

        // Monta grid de servidores
        call('GetApiList').then(function (res) {
            try {
                var d = parseJson(res);
                if (d && d.apis) {
                    srvGrid.innerHTML = '';
                    d.apis.forEach(function (api) {
                        var card = div(''); card.className = 'gf-pip-srv';
                        var name = div(''); name.className = 'gf-pip-srv-name';
                        name.textContent = maskApiName(api.name);
                        var st = div(''); st.className = 'gf-pip-srv-st';
                        var dot = document.createElement('span'); dot.className = 'gf-pip-srv-dot';
                        var stTxt = document.createTextNode('Aguardando');
                        st.appendChild(dot); st.appendChild(stTxt);
                        st.dataset.an = api.name;
                        card.appendChild(name); card.appendChild(st);
                        srvGrid.appendChild(card);
                    });
                }
            } catch (_) {}
        }).catch(function () {});

        call('StartDownload', { appid: appid, game_name: gameName || '' });

        var mb = function (b) { return (b / 1048576).toFixed(1) + ' MB'; };

        var lastSt = '';
        var poll = setInterval(function () {
            if (!document.body.contains(o)) { clearInterval(poll); return; }
            call('GetDownloadStatus', { appid: appid }).then(function (res) {
                try {
                    var d = parseJson(res);
                    var state = (d && d.state) ? d.state : {};
                    var st    = state.status || '';
                    var apiSt = state.apiStatus || {};

                    // Atualiza cards de servidor
                    Object.keys(apiSt).forEach(function (name) {
                        var stEl = srvGrid.querySelector('[data-an="' + name + '"]');
                        if (!stEl) return;
                        var card = stEl.parentElement;
                        var dot  = stEl.querySelector('.gf-pip-srv-dot');
                        var s    = apiSt[name];
                        // Remove texto antigo
                        while (stEl.childNodes.length > 1) stEl.removeChild(stEl.lastChild);
                        card.classList.remove('srv-checking', 'srv-found', 'srv-miss');
                        if (s === 'verificando') {
                            card.classList.add('srv-checking');
                            stEl.appendChild(document.createTextNode('Verificando'));
                        } else if (s === 'encontrado') {
                            card.classList.add('srv-found');
                            stEl.appendChild(document.createTextNode('Online'));
                        } else if (s === 'indisponivel' || s === 'indisponível') {
                            card.classList.add('srv-miss');
                            stEl.appendChild(document.createTextNode('Offline'));
                        } else if (s && s.indexOf('erro') !== -1) {
                            card.classList.add('srv-miss');
                            stEl.appendChild(document.createTextNode('Erro'));
                        } else {
                            stEl.appendChild(document.createTextNode('Aguardando'));
                        }
                    });

                    // Atualiza estágios conforme status
                    if (st !== lastSt) {
                        lastSt = st;
                        if (st === 'downloading') {
                            pillTxt.textContent = 'Baixando';
                            setStage(stageSearch,   'done'); setStageDetail(stageSearch, 'Concluído');
                            setStage(stageFound,    'done'); setStageDetail(stageFound,  'Servidor conectado');
                            setStage(stageDownload, 'active');
                            setStageIco(stageDownload, '↓');
                            barWrap.style.display = 'block';
                        } else if (st === 'extracting') {
                            pillTxt.textContent = 'Instalando';
                            setStage(stageSearch,   'done'); setStageDetail(stageSearch,   'Concluído');
                            setStage(stageFound,    'done'); setStageDetail(stageFound,    'Servidor conectado');
                            setStage(stageDownload, 'done'); setStageDetail(stageDownload, 'Download completo');
                            setStageIco(stageDownload, '✓');
                            setStage(stageInstall,  'active');
                            setStageDetail(stageInstall, 'Configurando arquivos do jogo');
                            fill.style.width = '100%';
                            barPct.textContent = '100%';
                        }
                    }

                    if (st === 'downloading') {
                        var total = state.totalBytes || 0, read = state.bytesRead || 0;
                        var pct = total > 0 ? Math.min(100, Math.round(read / total * 100)) : 0;
                        fill.style.width = pct + '%';
                        barPct.textContent = pct + '%';
                        barSize.textContent = mb(read) + ' / ' + (total > 0 ? mb(total) : '?');
                        var dlEl    = document.getElementById('gf-pip-dl');
                        var totEl   = document.getElementById('gf-pip-total');
                        var srvEl   = document.getElementById('gf-pip-server');
                        if (dlEl)  dlEl.textContent  = mb(read);
                        if (totEl) totEl.textContent = total > 0 ? mb(total) : '?';
                        if (srvEl) srvEl.textContent = state.currentApi ? maskApiName(state.currentApi) : '—';
                        setStageDetail(stageDownload, pct + '% — ' + mb(read) + (total > 0 ? ' / ' + mb(total) : ''));
                    }

                    if (st === 'done') {
                        clearInterval(poll); o.remove();
                        showConfirm('Jogo adicionado com sucesso! Deseja instalar o jogo agora?', function () {
                            window.location.href = 'steam://validate/' + appid;
                        }, 'Instalar');
                    } else if (st === 'failed') {
                        clearInterval(poll); o.remove();
                        showAlert('Nenhum servidor encontrou este jogo. Tente novamente mais tarde.');
                    } else if (st === 'cancelled') {
                        clearInterval(poll); o.remove();
                    }
                } catch (_) {}
            }).catch(function () {});
        }, 600);
    }

    // ── Fix progress popup ──────────────────────────────────────────────────────
        // ── Seletor de fix Ryuu (múltiplos disponíveis) ────────────────────────────
    function showRyuuPicker(appid, fixes) {
        if ($('.gf-picker-o')) return;
        injectStyles();
        var o = overlay(); o.className = 'gf-o gf-picker-o';
        var m = div(''); m.className = 'gf-modal'; m.style.width = '420px';

        var h = div('padding:16px 18px 14px;border-bottom:1px solid rgba(255,255,255,.06);background:linear-gradient(90deg,rgba(220,0,0,.1),transparent 70%);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;');
        h.innerHTML = '<div style="font-size:10px;font-weight:800;letter-spacing:3px;color:#dc0000;text-transform:uppercase;">Escolher Fix</div>';
        h.appendChild(xBtn(function () { o.remove(); }));

        var body = div('padding:16px 18px 20px;');

        var best = fixes[0] || {};
        if (best.source === 'voices38') {
            var tip = div('display:flex;align-items:flex-start;gap:10px;padding:11px 13px;border-radius:9px;background:rgba(255,200,0,.07);border:1px solid rgba(255,200,0,.2);margin-bottom:14px;');
            tip.innerHTML =
                '<span style="font-size:16px;flex-shrink:0;">\u2B50</span>' +
                '<div style="font-size:11px;color:rgba(255,210,60,.9);line-height:1.55;">' +
                '<strong style="display:block;margin-bottom:2px;">Fix voices38 dispon\u00edvel</strong>' +
                'O fix do voices38 \u00e9 o mais confi\u00e1vel e recomendado. Prefira-o sempre que poss\u00edvel.' +
                '</div>';
            body.appendChild(tip);
        }

        var subtitle = div('font-size:11px;color:rgba(255,255,255,.35);margin-bottom:12px;');
        subtitle.textContent = 'Selecione qual fix deseja instalar:';
        body.appendChild(subtitle);

        fixes.forEach(function (fix, idx) {
            var isVoices = fix.source === 'voices38';
            var isHyper  = fix.source === 'hypervision';
            var isRec    = fix.recommended === true;

            var row = div('');
            row.style.cssText = 'display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;' +
                'background:' + (isRec ? 'rgba(220,0,0,.08)' : 'rgba(255,255,255,.03)') + ';' +
                'border:1px solid ' + (isRec ? 'rgba(220,0,0,.25)' : 'rgba(255,255,255,.07)') + ';' +
                'cursor:pointer;transition:all .13s;margin-bottom:8px;';

            var ico = div('width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:13px;font-weight:800;color:#fff;');
            if (isVoices)      { ico.style.background = 'rgba(220,0,0,.25)';    ico.textContent = 'v38'; }
            else if (isHyper)  { ico.style.background = 'rgba(80,80,200,.25)';  ico.textContent = 'HV';  }
            else               { ico.style.background = 'rgba(255,255,255,.08)'; ico.textContent = '#' + (idx + 1); }

            var info = div('flex:1;min-width:0;');
            var nameRow = div('display:flex;align-items:center;gap:6px;flex-wrap:wrap;');
            var fname = div('font-size:12px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px;');
            fname.textContent = fix.filename || ('Fix ' + (idx + 1));
            fname.title = fix.filename || '';
            nameRow.appendChild(fname);

            if (isRec) {
                var recBadge = div('font-size:9px;font-weight:800;letter-spacing:1px;padding:2px 6px;border-radius:4px;background:rgba(220,0,0,.3);color:#ff6060;text-transform:uppercase;flex-shrink:0;');
                recBadge.textContent = 'Recomendado';
                nameRow.appendChild(recBadge);
            }
            if (isVoices) {
                var vBadge = div('font-size:9px;font-weight:800;letter-spacing:1px;padding:2px 6px;border-radius:4px;background:rgba(255,200,0,.15);color:rgba(255,210,60,.9);text-transform:uppercase;flex-shrink:0;');
                vBadge.textContent = 'voices38';
                nameRow.appendChild(vBadge);
            }
            info.appendChild(nameRow);

            var meta = div('font-size:10px;color:rgba(255,255,255,.3);margin-top:3px;');
            var parts = [];
            if (fix.badges && fix.badges.length) parts.push(fix.badges.join(' · '));
            if (fix.size) parts.push(fix.size);
            meta.textContent = parts.join('  ·  ');
            info.appendChild(meta);

            var arr = div('font-size:14px;color:rgba(255,255,255,.15);flex-shrink:0;');
            arr.textContent = '▶';

            row.appendChild(ico); row.appendChild(info); row.appendChild(arr);
            row.onmouseover = function () {
                this.style.background = isRec ? 'rgba(220,0,0,.14)' : 'rgba(255,255,255,.06)';
                this.style.borderColor = isRec ? 'rgba(220,0,0,.4)'  : 'rgba(255,255,255,.14)';
                arr.style.color = 'rgba(255,255,255,.5)';
            };
            row.onmouseout = function () {
                this.style.background = isRec ? 'rgba(220,0,0,.08)' : 'rgba(255,255,255,.03)';
                this.style.borderColor = isRec ? 'rgba(220,0,0,.25)' : 'rgba(255,255,255,.07)';
                arr.style.color = 'rgba(255,255,255,.15)';
            };
            var capturedFix = fix;
            row.onclick = function () {
                o.remove();
                var label = capturedFix.source === 'voices38' ? 'voices38' : (capturedFix.filename || 'Fix Ryuu');
                showFixProgress(appid, 'ryuu', 'Fix Ryuu — ' + label, capturedFix.href);
            };
            body.appendChild(row);
        });

        m.appendChild(h); m.appendChild(body);
        o.appendChild(m); document.body.appendChild(o);
    }

        function showFixProgress(appid, fixType, fixLabel, url) {
        if ($('.gf-fix-o')) return;
        injectStyles();
        const o = overlay(); o.className = 'gf-o gf-fix-o';
        const m = div(''); m.className = 'gf-modal'; m.style.width = '400px';

        const h = div('padding:16px 18px 14px;border-bottom:1px solid rgba(255,255,255,.06);background:linear-gradient(90deg,rgba(220,0,0,.1),transparent 70%);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;');
        h.innerHTML = '<div style="font-size:10px;font-weight:800;letter-spacing:3px;color:#dc0000;text-transform:uppercase;">' + fixLabel + '</div>';
        h.appendChild(xBtn(function () { call('CancelFix', { appid: appid }); o.remove(); }));

        const body = div('padding:22px 18px;');
        const sm = div('font-size:13px;color:rgba(255,255,255,.5);margin-bottom:14px;text-align:center;');
        sm.textContent = 'Aplicando ' + fixLabel + '...';
        const pw = div('gf-pw'); const pf = div('gf-pf'); pw.appendChild(pf);
        const pt = div('gf-pt');
        body.appendChild(sm); body.appendChild(pw); body.appendChild(pt);

        const f = div('padding:10px 18px 16px;flex-shrink:0;');
        const cb = mkBtn('Cancelar', false);
        cb.onclick = function () { call('CancelFix', { appid: appid }); o.remove(); };
        f.appendChild(cb);

        m.appendChild(h); m.appendChild(body); m.appendChild(f);
        o.appendChild(m); document.body.appendChild(o);

        if (url) { call('ApplyFixUrl', { appid: appid, url: url, fix_type: fixType }); } else { call('ApplyFix', { appid: appid, fix_type: fixType }); }

        const poll = setInterval(function () {
            if (!document.body.contains(o)) { clearInterval(poll); return; }
            call('GetFixStatus', { appid: appid }).then(function (res) {
                try {
                    const d = parseJson(res);
                    const state = (d && d.state) ? d.state : {};
                    const st = state.status || '';
                    const total = state.totalBytes || 0, read = state.bytesRead || 0;
                    const mb = function (b) { return (b / 1048576).toFixed(1) + ' MB'; };
                    if (st === 'downloading') {
                        const pct = total > 0 ? Math.min(100, Math.round(read / total * 100)) : 0;
                        pf.style.width = pct + '%';
                        pt.innerHTML = '<span>' + pct + '%</span><span>' + mb(read) + ' / ' + (total > 0 ? mb(total) : '?') + '</span>';
                        sm.textContent = 'Baixando ' + fixLabel + '...';
                    } else if (st === 'extracting') {
                        pf.style.width = '100%'; sm.textContent = 'Instalando...';
                    } else if (st === 'done')     { clearInterval(poll); o.remove(); showAlert(fixLabel + ' aplicado com sucesso!'); }
                    else if (st === 'failed')  { clearInterval(poll); o.remove(); showAlert('Falha ao aplicar ' + fixLabel + ': ' + (state.error || 'erro desconhecido')); }
                    else if (st === 'cancelled'){ clearInterval(poll); o.remove(); }
                } catch (_) {}
            }).catch(function () {});
        }, 500);
    }

    // ── Fix cards builder ───────────────────────────────────────────────────────
    function buildFixCards(grid, data, appid, mainOverlay) {
        const ryuu = (data && data.ryuuFix) ? data.ryuuFix : {};
        const vps  = (data && data.vpsFix)  ? data.vpsFix  : {};
        const vf   = (data && data.vfFix)   ? data.vfFix   : {};

        function fixCard(title, sub, avail, onClick) {
            const card = div(''); card.className = 'gf-fix-card ' + (avail ? 'av' : 'no');
            const top = div(''); top.className = 'gf-fix-card-top';
            const ico = div(''); ico.className = 'gf-fix-ico';
            ico.style.background = avail ? 'rgba(60,184,94,.13)' : 'rgba(255,255,255,.04)';
            ico.style.color      = avail ? '#3cb85e' : 'rgba(255,255,255,.18)';
            ico.textContent = avail ? '✓' : '✕';
            const badge = div(''); badge.className = 'gf-badge ' + (avail ? 'av' : 'no');
            badge.textContent = avail ? 'Disponível' : 'Indisponível';
            top.appendChild(ico); top.appendChild(badge);
            const nm = div('font-size:13px;font-weight:700;margin-bottom:2px;');
            nm.style.color = avail ? '#fff' : 'rgba(255,255,255,.22)'; nm.textContent = title;
            const sb = div('font-size:10px;');
            sb.style.color = avail ? 'rgba(60,184,94,.5)' : 'rgba(255,255,255,.2)'; sb.textContent = sub;
            card.appendChild(top); card.appendChild(nm); card.appendChild(sb);
            if (avail) card.onclick = function () { if (mainOverlay) mainOverlay.remove(); onClick(); };
            return card;
        }

        // ── Ordem de prioridade (definida pelo backend): voicesfix → VPS → Ryuu ──
        if (vf.available) {
            var vfSub = (vf.filename || 'Fix') + '  ·  voicesfix';
            grid.appendChild(fixCard('Fix', vfSub, true, function () {
                showFixProgress(appid, 'voicesfix', 'Fix', vf.url);
            }));
        } else if (vps.available) {
            var vpsSub = (vps.filename || 'Fix') + '  ·  VPS (Ryuu)';
            grid.appendChild(fixCard('Fix', vpsSub, true, function () {
                showFixProgress(appid, 'vps', 'Fix VPS', vps.url);
            }));
        } else if (ryuu.available) {
            var ryuuFixes  = ryuu.fixes || [];
            var hasMult    = ryuuFixes.length > 1;
            var best       = ryuuFixes[0] || {};
            var ryuuBadges = (best.badges && best.badges.length) ? best.badges.join(' · ') : '';
            var ryuuSub    = (best.source === 'voices38' ? 'voices38' : best.label || 'Fix') +
                             (ryuuBadges ? ' · ' + ryuuBadges : '') +
                             (best.size   ? ' · ' + best.size   : '') +
                             (hasMult     ? '  (' + ryuuFixes.length + ' opções)' : '') +
                             '  ·  Ryuu';

            grid.appendChild(fixCard('Fix', ryuuSub, true, function () {
                if (hasMult) {
                    showRyuuPicker(appid, ryuuFixes);
                } else {
                    showFixProgress(appid, 'ryuu', 'Fix', best.href);
                }
            }));
        } else {
            grid.appendChild(fixCard('Fix', 'Indisponível', false, function () {}));
        }
    }

    // ── Menu principal ──────────────────────────────────────────────────────────
    function showMainMenu(appid, gameName) {
        if ($('.gf-main-o')) return;
        injectStyles();
        // Atualiza versão ao abrir o plugin
        call('GetPluginInfo').then(function(res) {
            try {
                var i = JSON.parse(res);
                if (i && i.version) _updateVersionDisplays(i.version);
            } catch(e) {}
        }).catch(function() {});
        const isApp = !isNaN(appid);
        const o = overlay(); o.className = 'gf-o gf-main-o';
        const m = div(''); m.className = 'gf-modal';
        m.style.width = '432px';
        m.style.maxHeight = Math.min(window.innerHeight * 0.9, 660) + 'px';

        // Hero
        m.appendChild(heroBlock(appid, gameName, function () { o.remove(); }));

        // Pane area
        const paneArea = div(''); paneArea.className = 'gf-pane-area';

        // ══ ABA 1: ADICIONAR ═════════════════════════════════════════════════
        const p1 = div(''); p1.className = 'gf-pane';

        if (isApp) {
            // ── Botão Adicionar / Remover (depende se .lua já existe) ────────
            const s1 = div(''); s1.className = 'gf-sec';
            const s1ttl = div(''); s1ttl.className = 'gf-sec-ttl'; s1ttl.textContent = 'Adicionar jogo';
            const addBtn = el('button'); addBtn.className = 'gf-big-btn'; addBtn.textContent = 'Verificando...';
            addBtn.disabled = true; addBtn.style.opacity = '0.5';
            // Verifica se o jogo já foi adicionado
            call('HasLuaForApp', { appid: appid }).then(function (res) {
                try {
                    var d = parseJson(res);
                    if (d && d.exists) {
                        // Jogo já adicionado — mostrar botão de remover
                        addBtn.textContent = 'Remover da biblioteca';
                        addBtn.style.background = 'rgba(220,0,0,.15)';
                        addBtn.style.borderColor = 'rgba(220,0,0,.35)';
                        addBtn.style.color = 'rgba(255,80,80,.9)';
                        addBtn.disabled = false; addBtn.style.opacity = '';
                        addBtn.onclick = function () {
                            showConfirm('Remover "' + (gameName || 'este jogo') + '" da biblioteca?', function () {
                                call('DeleteLuaForApp', { appid: appid }).then(function (r) {
                                    try {
                                        var rd = parseJson(r);
                                        if (rd && rd.success && rd.count > 0) {
                                            addBtn.textContent = 'Adicionar';
                                            addBtn.style.background = '';
                                            addBtn.style.borderColor = '';
                                            addBtn.style.color = '';
                                            addBtn.onclick = function () { o.remove(); showDownloadPopup(appid, gameName); };
                                            showAlert('Jogo removido com sucesso.');
                                        } else {
                                            showAlert('Nenhum arquivo encontrado para remover.');
                                        }
                                    } catch (_) { showAlert('Erro ao remover.'); }
                                });
                            }, 'Remover');
                        };
                    } else {
                        // Jogo não adicionado — botão de adicionar normal
                        addBtn.textContent = 'Adicionar';
                        addBtn.disabled = false; addBtn.style.opacity = '';
                        addBtn.onclick = function () { o.remove(); showDownloadPopup(appid, gameName); };
                    }
                } catch (_) {
                    addBtn.textContent = 'Adicionar';
                    addBtn.disabled = false; addBtn.style.opacity = '';
                    addBtn.onclick = function () { o.remove(); showDownloadPopup(appid, gameName); };
                }
            }).catch(function () {
                addBtn.textContent = 'Adicionar';
                addBtn.disabled = false; addBtn.style.opacity = '';
                addBtn.onclick = function () { o.remove(); showDownloadPopup(appid, gameName); };
            });

            const restartBtn2 = el('button');
            restartBtn2.style.cssText =
                'width:100%;margin-top:9px;padding:11px 0;border-radius:10px;' +
                'background:rgba(255,200,0,.08);border:1px solid rgba(255,200,0,.22);' +
                'color:rgba(255,210,0,.8);font-size:11px;font-weight:800;letter-spacing:1px;' +
                'text-transform:uppercase;cursor:pointer;transition:all .14s;';
            restartBtn2.textContent = '↺  Reiniciar Steam';
            restartBtn2.onmouseover = function () { this.style.background = 'rgba(255,200,0,.15)'; this.style.borderColor = 'rgba(255,200,0,.4)'; this.style.color = 'rgba(255,220,0,.95)'; };
            restartBtn2.onmouseout  = function () { this.style.background = 'rgba(255,200,0,.08)'; this.style.borderColor = 'rgba(255,200,0,.22)'; this.style.color = 'rgba(255,210,0,.8)'; };
            restartBtn2.onclick = function () {
                showConfirm('Deseja reiniciar o Steam agora?', function () {
                    call('RestartSteam', { appid: 0 });
                }, 'Reiniciar Steam');
            };

            s1.appendChild(s1ttl); s1.appendChild(addBtn); s1.appendChild(restartBtn2);
            // ── Avisos especiais por launcher/franquia (aba Adicionar) ─────
            (function () {
                var gn = (gameName || '').toLowerCase();

                // COD AppIDs conhecidos
                var COD_APPIDS = [42700,42710,202990,209160,209080,311210,476600,476620,1100448,1227430,1743720,1174180,1938090,2744370,2835570];
                var isCOD = COD_APPIDS.indexOf(appid) !== -1 ||
                    ['call of duty','modern warfare','black ops','warzone','vanguard','cold war'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isRockstar = ['grand theft auto','gta','red dead','rdr','max payne','l.a. noire','bully','midnight club'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isEA = ['battlefield','mass effect','dragon age','need for speed','fifa','ea fc','apex legends',
                    'star wars jedi','the sims','plants vs zombies','titanfall','anthem','dead space',
                    'it takes two','a way out','wild hearts','immortals of aveum'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isUbisoft = ['assassin','assassins creed','far cry','watch dogs','watch_dogs','rainbow six',
                    'for honor','the crew','riders republic','anno','just dance','immortals fenyx',
                    'skull and bones','avatar frontiers','prince of persia'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isBattlenet = ['overwatch','diablo','world of warcraft','starcraft','hearthstone',
                    'heroes of the storm','call of duty'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isMicrosoft = ['halo','forza','sea of thieves','gears of war','gears 5','age of empires',
                    'minecraft','flight simulator','pentiment','grounded','psychonauts','hi-fi rush',
                    'ori and','fable'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isSony = ['god of war','spider-man','spiderman','the last of us','horizon',
                    'ghost of tsushima','uncharted','returnal','ratchet','sackboy','days gone',
                    'gran turismo','helldivers'].some(function(k){ return gn.indexOf(k) !== -1; });

                var isNintendo = ['mario','zelda','pokemon','kirby','metroid','donkey kong','splatoon',
                    'animal crossing','fire emblem','xenoblade','pikmin','smash bros'].some(function(k){ return gn.indexOf(k) !== -1; });

                var is2K = ['borderlands','bioshock','civilization','xcom','mafia','nba 2k','wwe 2k',
                    'tiny tina','the quarry','midnight suns','kerbal'].some(function(k){ return gn.indexOf(k) !== -1; });

                // Warn cards: múltiplos podem aparecer ao mesmo tempo
                var warnings = [];

                // Cor única padronizada para todos os avisos
                var WC = { bg: 'rgba(255,160,0,.06)', border: 'rgba(255,160,0,.22)', titleColor: 'rgba(255,185,0,.95)' };

                if (isCOD) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Call of Duty detectado',
                    body: 'Jogos de COD utilizam anti-cheat RICOCHET. Mesmo com fix aplicado, o jogo pode não iniciar ou ser bloqueado. <b style="color:rgba(255,200,80,.7);">Prossiga por sua conta e risco.</b>'
                });
                if (isRockstar) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Rockstar Games detectado',
                    body: 'Jogos da Rockstar exigem o <b style="color:rgba(255,200,80,.7);">Rockstar Games Launcher</b>. Além do fix do Steam, pode ser necessário um fix externo compatível com o launcher para que o jogo funcione.'
                });
                if (isEA && !isCOD) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'EA App detectado',
                    body: 'Jogos da EA exigem o <b style="color:rgba(255,200,80,.7);">EA App</b> instalado. O fix do Steam pode não ser suficiente — um fix externo compatível com o EA App pode ser necessário.'
                });
                if (isUbisoft) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Ubisoft Connect detectado',
                    body: 'Jogos da Ubisoft exigem o <b style="color:rgba(255,200,80,.7);">Ubisoft Connect</b> instalado. Mesmo com fix aplicado, um fix externo compatível com o launcher pode ser necessário.'
                });
                if (isBattlenet && !isCOD) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Battle.net detectado',
                    body: 'Jogos do Battle.net exigem o <b style="color:rgba(255,200,80,.7);">Battle.net</b> instalado e autenticado. Mesmo com fix aplicado, o jogo pode não funcionar sem a plataforma ativa.'
                });
                if (isMicrosoft) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Microsoft / Xbox Game Studios detectado',
                    body: 'Jogos da Microsoft podem exigir o <b style="color:rgba(255,200,80,.7);">Xbox App</b> ou conta Microsoft ativa. Mesmo com fix, o jogo pode não funcionar sem a plataforma.'
                });
                if (isSony) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Sony / PlayStation Studios detectado',
                    body: 'Alguns jogos da Sony exigem conta <b style="color:rgba(255,200,80,.7);">PlayStation Network (PSN)</b>. Mesmo com fix, funcionalidades ou o próprio jogo podem não funcionar sem conta PSN.'
                });
                if (isNintendo) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: 'Nintendo detectado',
                    body: 'Jogos da Nintendo raramente estão disponíveis no Steam. Verifique se é um port ou versão oficial. Mesmo com fix, a compatibilidade pode ser limitada.'
                });
                if (is2K) warnings.push({
                    bg: WC.bg, border: WC.border, titleColor: WC.titleColor,
                    icon: '⚠', title: '2K Games detectado',
                    body: 'Alguns jogos da 2K utilizam launcher próprio da <b style="color:rgba(255,200,80,.7);">2K</b>. Mesmo com fix do Steam, o launcher pode bloquear a execução do jogo.'
                });

                if (warnings.length === 0) return;

                warnings.forEach(function(w) {
                    var warn = div('');
                    warn.style.cssText = 'margin:10px 0 0;padding:12px 14px;border-radius:10px;border:1px solid;font-size:11px;line-height:1.6;' +
                        'background:' + w.bg + ';border-color:' + w.border + ';';
                    warn.innerHTML =
                        '<div style="font-weight:800;color:' + w.titleColor + ';margin-bottom:5px;font-size:12px;">' + w.icon + ' ' + w.title + '</div>' +
                        '<div style="color:rgba(255,255,255,.45);">' + w.body + '</div>';
                    s1.appendChild(warn);
                });
            })();
            p1.appendChild(s1);

            p1.appendChild(div('gf-divider'));

            // ── Status real de instalação ────────────────────────────────────
            const s2 = div(''); s2.className = 'gf-sec';
            const s2ttl = div(''); s2ttl.className = 'gf-sec-ttl'; s2ttl.textContent = 'Status';
            const ig = div(''); ig.className = 'gf-stat-grid';

            function statCard(lbl, val, col) {
                const c = div(''); c.className = 'gf-stat-card';
                const l = div(''); l.className = 'gf-stat-lbl'; l.textContent = lbl;
                const v = div(''); v.className = 'gf-stat-val'; v.style.color = col || '#fff'; v.textContent = val;
                c.appendChild(l); c.appendChild(v); return c;
            }

            const appIdCard  = statCard('App ID', appid, '#dc0000');
            const statusCard = statCard('Instalado', '...', 'rgba(255,255,255,.3)');
            ig.appendChild(appIdCard); ig.appendChild(statusCard);
            s2.appendChild(s2ttl); s2.appendChild(ig);
            p1.appendChild(s2);

            // Verificar instalação real via backend
            call('GetGameInstallPath', { appid: appid }).then(function (res) {
                try {
                    const d = parseJson(res);
                    const installed = d && d.success === true;
                    const sv = statusCard.querySelector('.gf-stat-val');
                    if (sv) {
                        sv.textContent = installed ? 'Sim' : 'Não';
                        sv.style.color  = installed ? '#3cb85e' : 'rgba(255,255,255,.35)';
                    }
                } catch (_) {}
            }).catch(function () {
                const sv = statusCard.querySelector('.gf-stat-val');
                if (sv) { sv.textContent = '?'; sv.style.color = 'rgba(255,255,255,.25)'; }
            });

            p1.appendChild(div('gf-divider'));

            // ── Proteção do jogo (DRM) ───────────────────────────────────────
            const s3 = div(''); s3.className = 'gf-sec';
            const s3ttl = div(''); s3ttl.className = 'gf-sec-ttl'; s3ttl.textContent = 'Proteção';
            const drmBox = div('');
            drmBox.innerHTML = '<div style="display:flex;align-items:center;gap:7px;color:rgba(255,255,255,.2);font-size:12px;">' +
                '<span class="gf-spinner" style="width:12px;height:12px;border-width:1.5px;"></span>Verificando proteções...</div>';
            s3.appendChild(s3ttl); s3.appendChild(drmBox);
            p1.appendChild(s3);

            // DRM info map: proteção → { can_fix, can_online }
            const DRM_COMPAT = {
                'Steam DRM':     { fixOk: true,  onlineOk: true,  note: 'Proteção leve, compatível com fixes.' },
                'Denuvo':        { fixOk: false, onlineOk: false, note: 'Proteção forte, fixes podem não funcionar.' },
                'EasyAntiCheat': { fixOk: true,  onlineOk: false, note: 'Fix offline funciona, online pode falhar.' },
                'BattlEye':      { fixOk: true,  onlineOk: false, note: 'Fix offline funciona, online bloqueado.' },
                'CEG':           { fixOk: true,  onlineOk: true,  note: 'Compatível com fixes na maioria dos casos.' },
                'SecuROM':       { fixOk: true,  onlineOk: true,  note: 'Geralmente compatível com fixes.' },
                'SKIDROW':       { fixOk: true,  onlineOk: true,  note: 'Compatível.' },
                'VMProtect':     { fixOk: false, onlineOk: false, note: 'Proteção avançada, fixes raramente funcionam.' },
            };

            call('DetectDrm', { appid: appid }).then(function (res) {
                try {
                    const data = parseJson(res);
                    drmBox.innerHTML = '';

                    if (!data || !data.drm || data.drm.length === 0) {
                        // Nenhuma proteção detectada
                        const ok = div('background:rgba(60,184,94,.07);border:1px solid rgba(60,184,94,.2);border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:10px;');
                        ok.innerHTML = '<div style="font-size:18px;line-height:1;">✓</div>' +
                            '<div>' +
                            '<div style="font-size:13px;font-weight:700;color:#3cb85e;margin-bottom:2px;">Sem proteção detectada</div>' +
                            '<div style="font-size:11px;color:rgba(255,255,255,.35);line-height:1.5;">Este jogo deve funcionar normalmente com os fixes disponíveis.</div>' +
                            '</div>';
                        drmBox.appendChild(ok);
                        return;
                    }

                    data.drm.forEach(function (d) {
                        const name = d.name || 'Desconhecida';
                        const compat = DRM_COMPAT[name] || { fixOk: null, onlineOk: null, note: 'Compatibilidade desconhecida com fixes.' };

                        const card = div('background:#141414;border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:13px 14px;margin-bottom:8px;');

                        // Header
                        const hdr = div('display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;');
                        const nameEl = div('font-size:13px;font-weight:700;color:#fff;display:flex;align-items:center;gap:7px;');
                        nameEl.innerHTML = '<span style="font-size:15px;">🔒</span>' + name;
                        hdr.appendChild(nameEl);

                        // Compatibilidade badges
                        const badges = div('display:flex;gap:5px;flex-wrap:wrap;margin-bottom:7px;');
                        function mkCompBadge(label, ok) {
                            const b = div('font-size:9px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;padding:3px 8px;border-radius:20px;');
                            if (ok === true) {
                                b.style.background = 'rgba(60,184,94,.12)'; b.style.color = 'rgba(60,184,94,.85)';
                                b.textContent = '✓ ' + label;
                            } else if (ok === false) {
                                b.style.background = 'rgba(220,60,60,.1)'; b.style.color = 'rgba(220,100,100,.8)';
                                b.textContent = '✕ ' + label;
                            } else {
                                b.style.background = 'rgba(255,255,255,.05)'; b.style.color = 'rgba(255,255,255,.3)';
                                b.textContent = '? ' + label;
                            }
                            return b;
                        }
                        badges.appendChild(mkCompBadge('Fix Offline', compat.fixOk));
                        badges.appendChild(mkCompBadge('Fix Online',  compat.onlineOk));

                        // Nota
                        const note = div('font-size:11px;color:rgba(255,255,255,.35);line-height:1.55;');
                        note.textContent = compat.note;

                        card.appendChild(hdr); card.appendChild(badges); card.appendChild(note);
                        drmBox.appendChild(card);
                    });
                } catch (_) {
                    drmBox.innerHTML = '<div style="font-size:12px;color:rgba(255,255,255,.2);padding:4px 0;">Não foi possível verificar as proteções.</div>';
                }
            }).catch(function () {
                drmBox.innerHTML = '<div style="font-size:12px;color:rgba(255,255,255,.2);padding:4px 0;">Sem conexão para verificar proteções.</div>';
            });

        } else {
            p1.innerHTML = '<div class="gf-empty">Abra a página de um jogo<br>na Steam Store para<br>adicionar o jogo.</div>';
        }

        // ══ ABA 2: CORRIGIR ══════════════════════════════════════════════════
        const p2 = div(''); p2.className = 'gf-pane';

        if (isApp) {
            const s3 = div(''); s3.className = 'gf-sec';
            const s3ttl = div(''); s3ttl.className = 'gf-sec-ttl'; s3ttl.textContent = 'Fixes Disponíveis';

            const grid = div(''); grid.className = 'gf-fix-grid';
            grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:26px 0;color:rgba(255,255,255,.2);font-size:12px;display:flex;align-items:center;justify-content:center;gap:8px;"><span class="gf-spinner"></span>Verificando...</div>';
            s3.appendChild(s3ttl); s3.appendChild(grid);
            p2.appendChild(s3);

            call('CheckFixes', { appid: appid, game_name: gameName || '' }).then(function (res) {
                try {
                    const data = parseJson(res);
                    grid.innerHTML = '';
                    buildFixCards(grid, data, appid, o);
                } catch (_) {
                    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:24px 0;color:rgba(220,60,60,.55);font-size:12px;">Erro ao verificar.</div>';
                }
            }).catch(function () {
                grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:24px 0;color:rgba(220,60,60,.55);font-size:12px;">Sem conexão com os servidores.</div>';
            });

            // ── Botões de fix externos ────────────────────────────────────────
            p2.appendChild(div('gf-divider'));
            var secExtFix = div(''); secExtFix.className = 'gf-sec';
            var secExtTitle = div(''); secExtTitle.className = 'gf-sec-ttl'; secExtTitle.textContent = 'Fixes Externos';
            var extDesc = div('font-size:11px;color:rgba(255,255,255,.32);line-height:1.55;margin-bottom:12px;');
            extDesc.textContent = 'Para jogos não suportados pelos servidores acima, você pode buscar manualmente nesses sites:';
            secExtFix.appendChild(secExtTitle);
            secExtFix.appendChild(extDesc);

            function extFixBtn(label, sub, url, color) {
                var btn = div('');
                btn.style.cssText = 'display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);cursor:pointer;transition:all .14s;margin-bottom:8px;';
                var ico = div('width:34px;height:34px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:16px;');
                ico.style.background = color;
                ico.textContent = '🔗';
                var txt = div('flex:1;');
                txt.innerHTML = '<div style="font-size:13px;font-weight:700;color:#fff;">' + label + '</div>' +
                    '<div style="font-size:10px;color:rgba(255,255,255,.3);margin-top:1px;">' + sub + '</div>';
                var arr = div('font-size:16px;color:rgba(255,255,255,.15);');
                arr.textContent = '↗';
                btn.appendChild(ico); btn.appendChild(txt); btn.appendChild(arr);
                btn.onmouseover = function () { this.style.background = 'rgba(255,255,255,.07)'; this.style.borderColor = 'rgba(255,255,255,.14)'; arr.style.color = 'rgba(255,255,255,.4)'; };
                btn.onmouseout  = function () { this.style.background = 'rgba(255,255,255,.04)'; this.style.borderColor = 'rgba(255,255,255,.07)'; arr.style.color = 'rgba(255,255,255,.15)'; };
                btn.onclick = function () {
                    // Abre no navegador externo da pessoa (não no browser da Steam)
                    try {
                        if (window.SteamClient && window.SteamClient.System && window.SteamClient.System.OpenLocalURL) {
                            window.SteamClient.System.OpenLocalURL(url);
                        } else {
                            window.open('steam://openurl/' + url, '_self');
                        }
                    } catch (_) {
                        try { window.open('steam://openurl/' + url, '_self'); } catch (__) {}
                    }
                };
                return btn;
            }

            secExtFix.appendChild(extFixBtn('Online Fix', 'online-fix.me — fixes multiplayer e online', 'https://online-fix.me', 'rgba(60,120,255,.15)'));
            // Fix Ryuu agora é automático nos cards acima — botão externo removido
            p2.appendChild(secExtFix);

            // Avisos de franquia movidos para aba Adicionar (p1)

            // ── Botão Remover, Fixar e Reparar ─────────────────────────────
            p2.appendChild(div('gf-divider'));
            const sRepair = div(''); sRepair.className = 'gf-sec';
            const sRepairTtl = div(''); sRepairTtl.className = 'gf-sec-ttl'; sRepairTtl.textContent = 'Remover Fix';
            sRepair.appendChild(sRepairTtl);

            const repairBtn = el('button');
            repairBtn.style.cssText =
                'width:100%;padding:13px 0;border-radius:10px;' +
                'background:rgba(255,140,0,.08);border:1px solid rgba(255,140,0,.22);' +
                'color:rgba(255,160,0,.85);font-size:11px;font-weight:800;letter-spacing:1px;' +
                'text-transform:uppercase;cursor:pointer;transition:all .14s;display:flex;' +
                'align-items:center;justify-content:center;gap:8px;';
            repairBtn.innerHTML = '<span style="font-size:14px;">🔧</span><span>Remover Fix</span>';
            repairBtn.onmouseover = function () {
                this.style.background = 'rgba(255,140,0,.15)';
                this.style.borderColor = 'rgba(255,160,0,.4)';
                this.style.color = 'rgba(255,180,0,.95)';
            };
            repairBtn.onmouseout = function () {
                this.style.background = 'rgba(255,140,0,.08)';
                this.style.borderColor = 'rgba(255,140,0,.22)';
                this.style.color = 'rgba(255,160,0,.85)';
            };
            repairBtn.onclick = function () {
                showConfirm(
                    'Remover Fix de "' + (gameName || 'este jogo') + '"?\n\n' +
                    'Os arquivos do fix serão removidos e a Steam iniciará a verificação de integridade automaticamente.',
                    function () {
                        repairBtn.disabled = true;
                        repairBtn.style.opacity = '0.5';
                        repairBtn.innerHTML = '<span class="gf-spinner" style="width:13px;height:13px;border-width:2px;"></span><span>Removendo...</span>';
                        Promise.all([
                            call('RemoveFix', { appid: appid }),
                            call('DeleteLuaForApp', { appid: appid })
                        ]).then(function (results) {
                            try {
                                var d = parseJson(results[0]);
                                var luaD = parseJson(results[1]);
                                var parts = [];
                                if (d && d.count > 0) parts.push(d.count + ' arquivo(s) de fix removido(s)');
                                if (luaD && luaD.count > 0) parts.push(luaD.count + ' arquivo(s) de jogo removido(s)');
                                var msg = parts.length > 0 ? parts.join(', ') + '.' : 'Nenhum arquivo encontrado.';
                                // Abre verificação de integridade diretamente — mesmo jeito que o LuaTools faz
                                try { window.location.href = 'steam://validate/' + appid; } catch (_) {}
                                showAlert(msg + '\n\nA verificação de integridade foi iniciada na Steam.');
                            } catch (_) {
                                try { window.location.href = 'steam://validate/' + appid; } catch (__) {}
                                showAlert('Verificação de integridade iniciada na Steam.');
                            }
                            repairBtn.disabled = false;
                            repairBtn.style.opacity = '';
                            repairBtn.innerHTML = '<span style="font-size:14px;">🔧</span><span>Remover Fix</span>';
                        }).catch(function () {
                            try { window.location.href = 'steam://validate/' + appid; } catch (_) {}
                            showAlert('Verificação de integridade iniciada na Steam.');
                            repairBtn.disabled = false;
                            repairBtn.style.opacity = '';
                            repairBtn.innerHTML = '<span style="font-size:14px;">🔧</span><span>Remover Fix</span>';
                        });
                    },
                    'Confirmar'
                );
            };
            sRepair.appendChild(repairBtn);
            p2.appendChild(sRepair);

        } else {
            p2.innerHTML = '<div class="gf-empty">Abra a página de um jogo<br>para ver os fixes disponíveis.</div>';
        }

        // ══ ABA 3: GERENCIAR ═════════════════════════════════════════════════
        const p3 = div(''); p3.className = 'gf-pane';

        function actRow(bg, icon, name, sub, onClick) {
            const r = div(''); r.className = 'gf-act';
            const ic = div(''); ic.className = 'gf-act-ico'; ic.style.background = bg; ic.textContent = icon;
            const tx = div('flex:1;');
            tx.innerHTML = '<div class="gf-act-name">' + name + '</div><div class="gf-act-sub">' + sub + '</div>';
            const ch = div(''); ch.className = 'gf-act-chev'; ch.textContent = '›';
            r.appendChild(ic); r.appendChild(tx); r.appendChild(ch);
            r.onclick = onClick;
            return r;
        }

        const s4 = div(''); s4.className = 'gf-sec';
        const s4ttl = div(''); s4ttl.className = 'gf-sec-ttl'; s4ttl.textContent = 'Ferramentas';
        s4.appendChild(s4ttl);
        if (isApp) {
            s4.appendChild(actRow('rgba(220,0,0,.1)', '⬇', 'Adicionar jogo', 'Buscar e instalar via servidores', function () {
                o.remove(); showDownloadPopup(appid, gameName);
            }));

        }
        s4.appendChild(actRow('rgba(255,200,0,.1)', '↺', 'Reiniciar Steam', 'Aplicar alterações pendentes', function () {
            showConfirm('Deseja reiniciar o Steam agora?', function () { call('RestartSteam'); });
        }));
        s4.appendChild(actRow('rgba(60,130,255,.1)', '⟳', 'Atualizar Servidores', 'Busca e atualiza a lista de servidores disponíveis', function () {
            const btn = this;
            btn.style.opacity = '0.5'; btn.style.pointerEvents = 'none';
            call('FetchFreeApisNow').then(function (res) {
                btn.style.opacity = ''; btn.style.pointerEvents = '';
                try {
                    var d = parseJson(res);
                    if (d && d.success) {
                        showAlert('Servidores atualizados! ' + (d.count || 0) + ' servidor(es) disponível(is).');
                    } else {
                        showAlert('Falha ao atualizar servidores: ' + (d && d.error ? d.error : 'erro desconhecido'));
                    }
                } catch (_) { showAlert('Erro ao processar resposta dos servidores.'); }
            }).catch(function () {
                btn.style.opacity = ''; btn.style.pointerEvents = '';
                showAlert('Sem conexão com os servidores. Tente novamente.');
            });
        }));
        if (isApp) {
            s4.appendChild(actRow('rgba(220,60,60,.1)', '🗑', 'Remover jogo da biblioteca', 'Remove o jogo adicionado pelo plugin', function () {
                showConfirm(
                    'Remover "' + (gameName || 'este jogo') + '" da biblioteca?\n\nO jogo será desvinculado da sua conta Steam.',
                    function () {
                        call('DeleteLuaForApp', { appid: appid }).then(function (res) {
                            try {
                                var d = parseJson(res);
                                if (d && d.success && d.count > 0) {
                                    showAlert('Jogo removido da biblioteca.');
                                } else if (d && d.success) {
                                    showAlert('Nenhum arquivo encontrado para este jogo.');
                                } else {
                                    showAlert('Não foi possível remover: ' + (d && d.error ? d.error : 'erro desconhecido'));
                                }
                            } catch (_) {
                                showAlert('Ocorreu um erro ao remover o jogo.');
                            }
                        }).catch(function () {
                            showAlert('Sem conexão com o backend. Tente novamente.');
                        });
                    },
                    'Remover'
                );
            }));
        }
        p3.appendChild(s4);

        p3.appendChild(div('gf-divider'));

        // Info do plugin na aba Gerenciar
        const s4b = div(''); s4b.className = 'gf-sec';
        const s4bttl = div(''); s4bttl.className = 'gf-sec-ttl'; s4bttl.textContent = 'Informações';
        const infoGrid2 = div(''); infoGrid2.className = 'gf-stat-grid';
        function infoCard(lbl, val, col) {
            const c = div(''); c.className = 'gf-stat-card';
            const l = div(''); l.className = 'gf-stat-lbl'; l.textContent = lbl;
            const v = div(''); v.className = 'gf-stat-val'; v.style.color = col || 'rgba(255,255,255,.6)'; v.textContent = val;
            c.appendChild(l); c.appendChild(v); return c;
        }
        var _vi = infoCard('Versão', 'v' + PLUGIN_VERSION); infoGrid2.appendChild(_vi); try { _vi.querySelectorAll('div')[1].className += ' gf-ver'; } catch(e) {}
        infoGrid2.appendChild(infoCard('Idioma', 'PT-BR'));
        s4b.appendChild(s4bttl); s4b.appendChild(infoGrid2);
        p3.appendChild(s4b);

        // Aba Config removida — informações movidas para Gerenciar

        // ══ ABA 4: BUSCAR ══════════════════════════════════════════════════
        // Busca jogos por nome em qualquer página (não depende de estar numa
        // página de jogo). O usuário digita → lista resultados com capa → clica
        // → reutiliza o fluxo de download existente (showDownloadPopup).
        var defaultPaneClass = isApp ? '' : ' on';
        const p4 = div(''); p4.className = 'gf-pane' + defaultPaneClass;

        const searchWrap = div(''); searchWrap.className = 'gf-search-wrap';

        // ── Status do catálogo ──
        var catalogStatus = div('');
        catalogStatus.style.cssText = 'font-size:10px;color:rgba(255,255,255,.2);margin-bottom:10px;display:flex;align-items:center;gap:6px;';
        var catalogDot = document.createElement('span');
        catalogDot.style.cssText = 'width:6px;height:6px;border-radius:50%;background:rgba(255,200,0,.5);flex-shrink:0;';
        var catalogText = document.createTextNode('Catálogo de jogos: carregando...');
        catalogStatus.appendChild(catalogDot);
        catalogStatus.appendChild(catalogText);
        searchWrap.appendChild(catalogStatus);

        var sep = div('');
        sep.style.cssText = 'height:1px;background:rgba(255,255,255,.04);margin:2px 0 10px;';
        searchWrap.appendChild(sep);

        // Caixa de busca
        const searchBox = div(''); searchBox.className = 'gf-search-box';
        const searchIco = div(''); searchIco.className = 'gf-search-ico';
        searchIco.textContent = '⌕';
        const searchInput = document.createElement('input');
        searchInput.className = 'gf-search-input';
        searchInput.type = 'text';
        searchInput.placeholder = 'Buscar jogo por nome...';
        searchInput.autocomplete = 'off';
        searchInput.spellcheck = false;
        const searchClear = document.createElement('button');
        searchClear.className = 'gf-search-clear';
        searchClear.innerHTML = '✕';
        searchClear.title = 'Limpar';
        searchBox.appendChild(searchIco);
        searchBox.appendChild(searchInput);
        searchBox.appendChild(searchClear);

        const searchHint = div(''); searchHint.className = 'gf-search-hint';
        searchHint.textContent = 'Digite o nome e selecione o jogo para baixar o .lua.';

        searchWrap.appendChild(searchBox);
        searchWrap.appendChild(searchHint);

        // ── Verifica status do catálogo ──
        (function checkCatalog() {
            call('GetCacheStatus').then(function (res) {
                try {
                    var d = parseJson(res);
                    if (d && d.ready) {
                        catalogDot.style.background = 'rgba(60,184,94,.7)';
                        catalogText.textContent = 'Catálogo de jogos: pronto (' + new Date().toLocaleDateString('pt-BR') + ')';
                        catalogStatus.title = 'Catálogo carregado — inclui jogos delistados';
                    } else if (d && d.loading) {
                        catalogDot.style.background = 'rgba(255,200,0,.5)';
                        catalogText.textContent = 'Catálogo de jogos: carregando (primeira vez pode levar alguns segundos)';
                        setTimeout(checkCatalog, 3000);
                    } else {
                        catalogDot.style.background = 'rgba(220,60,60,.5)';
                        catalogText.textContent = 'Catálogo de jogos: indisponível (buscas em jogos delistados podem falhar)';
                        catalogStatus.title = 'Tente novamente mais tarde ou use a busca por AppID';
                    }
                } catch (_) { setTimeout(checkCatalog, 3000); }
            }).catch(function () { setTimeout(checkCatalog, 3000); });
        })();

        // Área de resultados
        const searchResults = div(''); searchResults.className = 'gf-search-results';

        function renderSearchEmpty(msg, ico) {
            searchResults.innerHTML = '';
            var s = div(''); s.className = 'gf-search-state';
            s.innerHTML = '<span class="gf-search-state-ico">' + (ico || '🔎') + '</span>' + msg;
            searchResults.appendChild(s);
        }
        renderSearchEmpty('Digite o nome de um jogo<br>para buscar na Steam.', '🎮');

        searchInput.addEventListener('focus', function () { searchBox.classList.add('focused'); });
        searchInput.addEventListener('blur',  function () { searchBox.classList.remove('focused'); });

        // Debounce de busca + token para descartar resultados antigos
        var searchTimer = null;
        var searchToken = 0;

        function runSearch(term) {
            var myToken = ++searchToken;
            searchClear.classList.toggle('visible', !!term);

            if (!term) {
                if (searchTimer) { clearTimeout(searchTimer); searchTimer = null; }
                renderSearchEmpty('Digite o nome de um jogo<br>para buscar na Steam.', '🎮');
                return;
            }

            // Estado de carregamento
            searchResults.innerHTML = '';
            var loading = div(''); loading.className = 'gf-search-state';
            var ll = div(''); ll.className = 'gf-search-loading';
            var sp = div('gf-spinner');
            sp.style.width = '13px'; sp.style.height = '13px'; sp.style.borderWidth = '2px';
            ll.appendChild(sp);
            ll.appendChild(document.createTextNode('Buscando jogos...'));
            loading.appendChild(ll);
            searchResults.appendChild(loading);

            call('SearchSteamGames', { term: term }).then(function (res) {
                // Resultado descartado se uma busca mais nova já começou
                if (myToken !== searchToken) return;
                var d = parseJson(res);
                if (!d || !d.success) {
                    renderSearchEmpty('Não foi possível buscar agora.<br>Verifique sua conexão.', '⚠️');
                    return;
                }
                var games = d.games || [];
                if (!games.length) {
                    renderSearchEmpty('Nenhum jogo encontrado para<br>"' + term + '".', '😕');
                    return;
                }
                renderSearchResults(games);
            }).catch(function () {
                if (myToken !== searchToken) return;
                renderSearchEmpty('Sem conexão com a Steam.<br>Tente novamente.', '⚠️');
            });
        }

        function renderSearchResults(games) {
            searchResults.innerHTML = '';
            games.forEach(function (g) {
                var row = div(''); row.className = 'gf-search-row';

                var img = document.createElement('img');
                img.className = 'gf-search-img';
                img.alt = '';
                img.loading = 'lazy';
                if (g.image) {
                    img.src = g.image;
                } else {
                    img.style.opacity = '0.3';
                }
                img.onerror = function () { this.style.opacity = '0.15'; this.removeAttribute('src'); };

                var info = div(''); info.className = 'gf-search-info';
                var name = div(''); name.className = 'gf-search-name';
                name.textContent = g.name;
                name.title = g.name;

                var meta = div(''); meta.className = 'gf-search-meta';
                var appidSpan = div(''); appidSpan.className = 'gf-search-appid';
                appidSpan.textContent = 'APP ' + g.appid;
                meta.appendChild(appidSpan);

                info.appendChild(name);
                info.appendChild(meta);

                var arr = div(''); arr.className = 'gf-search-arr';
                arr.textContent = '›';

                row.appendChild(img);
                row.appendChild(info);
                row.appendChild(arr);

                var pickedAppid = g.appid;
                var pickedName = g.name;
                row.onclick = function () {
                    o.remove();
                    showDownloadPopup(pickedAppid, pickedName);
                };

                searchResults.appendChild(row);
            });
        }

        searchInput.addEventListener('input', function () {
            var val = searchInput.value.trim();
            searchClear.classList.toggle('visible', !!val);
            if (searchTimer) clearTimeout(searchTimer);
            searchTimer = setTimeout(function () { runSearch(val); }, 450);
        });

        searchInput.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                if (searchTimer) { clearTimeout(searchTimer); searchTimer = null; }
                runSearch(searchInput.value.trim());
            }
        });

        searchClear.addEventListener('click', function () {
            searchInput.value = '';
            searchClear.classList.remove('visible');
            searchInput.focus();
            runSearch('');
        });

        p4.appendChild(searchWrap);
        p4.appendChild(searchResults);

        // ── Montar estrutura ─────────────────────────────────────────────────
        paneArea.appendChild(p1);
        paneArea.appendChild(p2);
        paneArea.appendChild(p3);
        paneArea.appendChild(p4);

        // ── Tab bar inferior ─────────────────────────────────────────────────
        const tabBar = div(''); tabBar.className = 'gf-tabbar';

        const tabDefs = [
            { icon: '＋', label: 'Adicionar', pane: p1 },
            { icon: '⚒', label: 'Corrigir',  pane: p2 },
            { icon: '☰', label: 'Gerenciar', pane: p3 },
            { icon: '⌕', label: 'Buscar',    pane: p4 },
        ];

        tabDefs.forEach(function (td, i) {
            const tab = div(''); tab.className = 'gf-tab';
            tab.innerHTML = '<div class="gf-tab-icon">' + td.icon + '</div><div>' + td.label + '</div>';
            // Se não há jogo detectado, abre na aba Buscar (índice 3)
            var defaultTab = isApp ? 0 : 3;
            if (i === defaultTab) tab.classList.add('on');
            tab.onclick = function () {
                $$('.gf-tab', tabBar).forEach(function (t) { t.classList.remove('on'); });
                [p1, p2, p3, p4].forEach(function (p) { p.classList.remove('on'); });
                tab.classList.add('on');
                td.pane.classList.add('on');
            };
            // Garante que o pane correto esteja visível se for o default
            if (i === defaultTab) td.pane.classList.add('on');
            tabBar.appendChild(tab);
        });

        m.appendChild(paneArea);
        m.appendChild(tabBar);
        o.appendChild(m);
        document.body.appendChild(o);
        o.addEventListener('click', function (e) { if (e.target === o) o.remove(); });
    }

    // ── Botão injetado ─────────────────────────────────────────────────────────
    var _lu = '', _hdrIns = false;

    function injectButton() {
        const url = window.location.href;
        if (url !== _lu) { _lu = url; _hdrIns = false; }

        injectStyles();

        // ── Botão no header (em QUALQUER página, igual ao LuaTools) ──────────
        // Container: ._1wn1lBlAzl3HMRqS1llwie — barra de topo da Steam Store
        if (!_hdrIns) {
            const hdrContainer = document.querySelector('._1wn1lBlAzl3HMRqS1llwie');
            if (hdrContainer && !document.querySelector('.gf-hdr-btn')) {
                _hdrIns = true;

                const hdrBtn = document.createElement('a');
                hdrBtn.href = '#';
                hdrBtn.className = 'gf-hdr-btn';

                // Botão com nome completo do plugin visível
                hdrBtn.innerHTML =
                    '<span style="font-size:11px;font-weight:900;letter-spacing:.4px;' +
                    'color:#fff;text-shadow:0 1px 4px rgba(0,0,0,.5);white-space:nowrap;">' +
                    PLUGIN_NAME + '</span>';

                // Match altura e alinhamento dos outros botões do header Steam
                var hdrParentH = hdrBtn.parentElement ? hdrBtn.parentElement.offsetHeight : 0;
                hdrBtn.style.cssText =
                    'position:relative;display:inline-flex;align-items:center;justify-content:center;' +
                    'padding:0 14px;height:36px;border-radius:6px;cursor:pointer;flex-shrink:0;' +
                    'background:linear-gradient(135deg,#dc0000,#8b0000);' +
                    'border:1px solid rgba(255,255,255,.12);' +
                    'box-shadow:0 2px 10px rgba(220,0,0,.4);' +
                    'transition:all .15s;text-decoration:none;' +
                    'align-self:center;margin-top:0;line-height:1;';

                hdrBtn.onmouseover = function () {
                    this.style.background = 'linear-gradient(135deg,#f50000,#a00000)';
                    this.style.boxShadow = '0 4px 20px rgba(220,0,0,.7),0 2px 6px rgba(0,0,0,.5)';
                    this.style.transform = 'translateY(-1px)';
                };
                hdrBtn.onmouseout = function () {
                    this.style.background = 'linear-gradient(135deg,#dc0000,#8b0000)';
                    this.style.boxShadow = '0 2px 12px rgba(220,0,0,.45),0 1px 3px rgba(0,0,0,.4)';
                    this.style.transform = 'none';
                };
                hdrBtn.onclick = function (e) {
                    e.preventDefault();
                    showMainMenu(getAppId(), getGameName());
                };

                // Centraliza no container: insere como primeiro filho
                // O container usa flex row; inserindo antes dos outros filhos
                // e com margin:auto ele fica visualmente centrado
                hdrContainer.insertBefore(hdrBtn, hdrContainer.firstChild);
            }
        }
    }


    // ── Auto-update: versão dinâmica + banner ─────────────────────────────────
    function showUpdateBanner() {
        if (document.querySelector('.gf-update-banner')) return;
        var b = document.createElement('div');
        b.className = 'gf-update-banner';
        b.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:99999;' +
            'background:linear-gradient(135deg,#1a1a2e,#16213e);' +
            'border:1px solid rgba(220,0,0,.5);border-radius:12px;' +
            'padding:16px 18px;min-width:320px;max-width:400px;' +
            'box-shadow:0 8px 32px rgba(0,0,0,.6);' +
            'display:flex;align-items:flex-start;gap:12px;';

        var bIcon = document.createElement('div');
        bIcon.style.cssText = 'font-size:22px;line-height:1;margin-top:2px;';
        bIcon.textContent = '🔄';

        var bBody = document.createElement('div');
        bBody.style.cssText = 'flex:1;';

        // Nome do plugin
        var bPlugin = document.createElement('div');
        bPlugin.style.cssText = 'color:rgba(220,0,0,.9);font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;margin-bottom:4px;';
        bPlugin.textContent = PLUGIN_NAME;

        var bTitle = document.createElement('div');
        bTitle.style.cssText = 'color:#fff;font-weight:700;font-size:13px;margin-bottom:4px;';
        bTitle.textContent = 'Plugin atualizado!';

        var bText = document.createElement('div');
        bText.style.cssText = 'color:rgba(255,255,255,.65);font-size:12px;line-height:1.5;margin-bottom:10px;';
        bText.textContent = 'Uma nova versão foi instalada. Reinicie o Steam para aplicar.';

        // Botões lado a lado
        var bBtns = document.createElement('div');
        bBtns.style.cssText = 'display:flex;gap:8px;';

        var bRestart = document.createElement('button');
        bRestart.style.cssText = 'flex:1;padding:7px 10px;border-radius:6px;border:none;cursor:pointer;' +
            'background:linear-gradient(135deg,#dc0000,#8b0000);color:#fff;font-size:12px;font-weight:700;';
        bRestart.textContent = 'Reiniciar agora';
        bRestart.onclick = function() {
            b.remove();
            call('RestartSteam').catch(function() {});
        };

        var bLater = document.createElement('button');
        bLater.style.cssText = 'flex:1;padding:7px 10px;border-radius:6px;border:none;cursor:pointer;' +
            'background:rgba(255,255,255,.08);color:rgba(255,255,255,.7);font-size:12px;font-weight:600;';
        bLater.textContent = 'Deixar pra depois';
        bLater.onclick = function() { b.remove(); };

        bBtns.appendChild(bRestart);
        bBtns.appendChild(bLater);

        bBody.appendChild(bPlugin);
        bBody.appendChild(bTitle);
        bBody.appendChild(bText);
        bBody.appendChild(bBtns);
        b.appendChild(bIcon);
        b.appendChild(bBody);
        document.body.appendChild(b);
    }

    function _updateVersionDisplays(ver) {
        PLUGIN_VERSION = ver;
        document.querySelectorAll('.gf-ver').forEach(function(el) {
            el.textContent = 'v' + ver;
        });
    }

    function startUpdatePolling() {
        // Busca versão real do backend
        call('GetPluginInfo').then(function(res) {
            try { var i = JSON.parse(res); if (i && i.version) _updateVersionDisplays(i.version); } catch(e) {}
        }).catch(function() {});

        // Checa status de update a cada 10s por 5 minutos
        var tries = 0;
        var poll = setInterval(function() {
            if (++tries > 30) { clearInterval(poll); return; }
            call('GetUpdateStatus').then(function(res) {
                try {
                    var s = JSON.parse(res);
                    if (s && s.update_applied) {
                        clearInterval(poll);
                        showUpdateBanner();
                        if (s.latest_version) _updateVersionDisplays(s.latest_version.replace(/^v/, ''));
                    }
                } catch(e) {}
            }).catch(function() {});
        }, 10000);
    }

    // ── Init ───────────────────────────────────────────────────────────────────
    // ── Tela de Ativação ────────────────────────────────────────────────────────
    function showActivationScreen(onSuccess) {
        injectStyles();
        // Remove qualquer tela anterior
        var old = document.getElementById('gf-activation-overlay');
        if (old) old.remove();

        var o = document.createElement('div');
        o.id = 'gf-activation-overlay';
        o.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;' +
            'background:rgba(0,0,0,0.92);z-index:99999;display:flex;' +
            'align-items:center;justify-content:center;';

        var box = document.createElement('div');
        box.style.cssText = 'background:#111;border:1px solid rgba(220,0,0,.3);' +
            'border-radius:14px;width:360px;overflow:hidden;' +
            'box-shadow:0 0 40px rgba(220,0,0,.15);';

        // Header
        var hdr = document.createElement('div');
        hdr.style.cssText = 'padding:20px 22px 16px;' +
            'background:linear-gradient(135deg,rgba(220,0,0,.15),rgba(0,0,0,0));' +
            'border-bottom:1px solid rgba(255,255,255,.06);text-align:center;';
        hdr.innerHTML =
            '<div style="font-size:10px;font-weight:800;letter-spacing:4px;' +
            'color:#dc0000;text-transform:uppercase;margin-bottom:6px;">Parzival Retrô Steam</div>' +
            '<div style="font-size:13px;font-weight:700;color:#fff;">Ativação de Licença</div>' +
            '<div style="font-size:11px;color:rgba(255,255,255,.35);margin-top:4px;">Digite sua key de acesso para continuar</div>';

        // Body
        var body = document.createElement('div');
        body.style.cssText = 'padding:22px;';

        var inputWrap = document.createElement('div');
        inputWrap.style.cssText = 'position:relative;margin-bottom:14px;';

        var inp = document.createElement('input');
        inp.type = 'text';
        inp.placeholder = 'PRZV-XXXX-XXXX-XXXX';
        inp.style.cssText = 'width:100%;box-sizing:border-box;' +
            'background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);' +
            'border-radius:8px;padding:11px 14px;color:#fff;font-size:13px;' +
            'font-family:monospace;letter-spacing:1px;outline:none;' +
            'text-transform:uppercase;transition:border .15s;';
        inp.onfocus = function() { this.style.borderColor = 'rgba(220,0,0,.5)'; };
        inp.onblur  = function() { this.style.borderColor = 'rgba(255,255,255,.1)'; };
        inp.oninput = function() { this.value = this.value.toUpperCase(); };
        inputWrap.appendChild(inp);

        var msg = document.createElement('div');
        msg.style.cssText = 'font-size:11px;min-height:16px;margin-bottom:14px;' +
            'text-align:center;color:rgba(255,80,80,.9);display:none;';

        var btn = document.createElement('button');
        btn.textContent = 'Ativar';
        btn.style.cssText = 'width:100%;padding:11px;border:none;border-radius:8px;' +
            'background:linear-gradient(135deg,#dc0000,#a00000);color:#fff;' +
            'font-size:13px;font-weight:700;cursor:pointer;letter-spacing:1px;' +
            'transition:opacity .15s;';
        btn.onmouseover = function() { this.style.opacity = '.85'; };
        btn.onmouseout  = function() { this.style.opacity = '1'; };

        var loading = false;
        var tentativas = 0;
        var MAX_TENTATIVAS = 5;

        function bloquearPlugin() {
            // Bloqueia a tela e dispara auto-destruição no backend
            inp.disabled = true;
            btn.disabled = true;
            btn.style.opacity = '.4';
            btn.style.cursor = 'not-allowed';
            btn.textContent = 'Bloqueado';
            btn.style.background = 'linear-gradient(135deg,#333,#111)';
            msg.style.color = 'rgba(255,80,80,.9)';
            msg.textContent = 'Número máximo de tentativas atingido. Plugin removido.';
            msg.style.display = 'block';
            inp.style.borderColor = 'rgba(220,0,0,.8)';
            // Avisa o backend para se auto-destruir
            call('SelfDestruct').catch(function() {});
        }

        btn.onclick = function() {
            if (loading) return;
            var key = inp.value.trim();
            if (!key) {
                msg.textContent = 'Digite sua key antes de continuar.';
                msg.style.display = 'block';
                return;
            }
            loading = true;
            btn.textContent = 'Verificando...';
            btn.style.opacity = '.6';
            btn.style.cursor = 'not-allowed';
            msg.style.display = 'none';

            call('Activate', { key: key }).then(function(res) {
                var d = parseJson(res);
                if (d && d.success) {
                    // Sucesso — mostra mensagem e fecha
                    msg.style.color = 'rgba(60,220,100,.9)';
                    msg.textContent = d.message || 'Ativado com sucesso!';
                    msg.style.display = 'block';
                    btn.textContent = '✓ Ativado!';
                    btn.style.background = 'linear-gradient(135deg,#1a8c3a,#0f5c26)';
                    setTimeout(function() {
                        o.remove();
                        if (onSuccess) onSuccess();
                    }, 1500);
                } else if (d && d.error === 'hwid_mismatch') {
                    // Key em uso em outro PC — oferece transferência
                    loading = false;
                    btn.textContent = 'Ativar';
                    btn.style.opacity = '1';
                    btn.style.cursor = 'pointer';
                    showTransferConfirm(key, o, onSuccess);
                } else {
                    // Erro — incrementa tentativas
                    tentativas++;
                    var restantes = MAX_TENTATIVAS - tentativas;
                    loading = false;

                    if (tentativas >= MAX_TENTATIVAS) {
                        bloquearPlugin();
                        return;
                    }

                    btn.textContent = 'Ativar';
                    btn.style.opacity = '1';
                    btn.style.cursor = 'pointer';
                    msg.style.color = 'rgba(255,80,80,.9)';
                    var erroBase = (d && d.message) ? d.message : 'Key inválida.';
                    msg.textContent = erroBase + ' (' + restantes + ' tentativa' + (restantes > 1 ? 's' : '') + ' restante' + (restantes > 1 ? 's' : '') + ')';
                    msg.style.display = 'block';
                    inp.style.borderColor = 'rgba(220,0,0,.6)';
                    inp.focus();
                }
            }).catch(function() {
                tentativas++;
                var restantes = MAX_TENTATIVAS - tentativas;
                loading = false;

                if (tentativas >= MAX_TENTATIVAS) {
                    bloquearPlugin();
                    return;
                }

                btn.textContent = 'Ativar';
                btn.style.opacity = '1';
                btn.style.cursor = 'pointer';
                msg.style.color = 'rgba(255,80,80,.9)';
                msg.textContent = 'Sem conexão com o servidor. (' + restantes + ' tentativa' + (restantes > 1 ? 's' : '') + ' restante' + (restantes > 1 ? 's' : '') + ')';
                msg.style.display = 'block';
            });
        };

        // Enter para ativar
        inp.onkeydown = function(e) { if (e.key === 'Enter') btn.click(); };

        // ── Botão Trial ────────────────────────────────────────────────────
        var sep = el('div');
        sep.style.cssText = 'text-align:center;font-size:10px;color:rgba(255,255,255,.2);margin:12px 0 8px;';
        sep.textContent = '— ou —';
        var trialBtn = document.createElement('button');
        trialBtn.textContent = 'Teste Grátis por 3 Dias';
        trialBtn.style.cssText = 'width:100%;padding:11px;border:1px solid rgba(255,255,255,.12);border-radius:8px;' +
            'background:transparent;color:rgba(255,255,255,.7);font-size:12px;font-weight:600;cursor:pointer;' +
            'letter-spacing:.5px;transition:all .15s;';
        trialBtn.onmouseover = function() { this.style.borderColor = 'rgba(255,255,255,.3)'; this.style.color = '#fff'; };
        trialBtn.onmouseout  = function() { this.style.borderColor = 'rgba(255,255,255,.12)'; this.style.color = 'rgba(255,255,255,.7)'; };
        trialBtn.onclick = function() {
            trialBtn.disabled = true;
            trialBtn.textContent = 'Iniciando...';
            trialBtn.style.opacity = '.5';
            call('StartTrial').then(function(res) {
                var d = parseJson(res);
                if (d && d.success) {
                    o.remove();
                    if (onSuccess) onSuccess();
                } else {
                    var errMsg = (d && d.message) ? d.message : 'Erro ao iniciar teste.';
                    if (d && d.error === 'trial_already_used') errMsg = 'Você já utilizou seu teste grátis. Adquira uma licença.';
                    msg.textContent = errMsg;
                    msg.style.display = 'block';
                    trialBtn.disabled = false;
                    trialBtn.textContent = 'Teste Grátis por 3 Dias';
                    trialBtn.style.opacity = '1';
                }
            }).catch(function() {
                msg.textContent = 'Sem conexão com o servidor.';
                msg.style.display = 'block';
                trialBtn.disabled = false;
                trialBtn.textContent = 'Teste Grátis por 3 Dias';
                trialBtn.style.opacity = '1';
            });
        };

        body.appendChild(inputWrap);
        body.appendChild(msg);
        body.appendChild(btn);
        body.appendChild(sep);
        body.appendChild(trialBtn);
        box.appendChild(hdr);
        box.appendChild(body);
        o.appendChild(box);
        document.body.appendChild(o);
        setTimeout(function() { inp.focus(); }, 100);
    }

    // ── Modal de confirmação de transferência de licença ─────────────────────
    // Chamado automaticamente quando activate() retorna hwid_mismatch.
    // Roda no PC NOVO. Não fecha a tela de ativação — fica por cima dela.
    function showTransferConfirm(key, activationOverlay, onSuccess) {
        var old = document.getElementById('gf-transfer-overlay');
        if (old) old.remove();

        var o = document.createElement('div');
        o.id = 'gf-transfer-overlay';
        o.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;' +
            'background:rgba(0,0,0,0.88);z-index:100000;display:flex;' +
            'align-items:center;justify-content:center;';

        var box = document.createElement('div');
        box.style.cssText = 'background:#111;border:1px solid rgba(255,160,0,.35);' +
            'border-radius:14px;width:370px;overflow:hidden;' +
            'box-shadow:0 0 40px rgba(255,140,0,.12);';

        // Header
        var hdr = document.createElement('div');
        hdr.style.cssText = 'padding:20px 22px 16px;' +
            'background:linear-gradient(135deg,rgba(255,140,0,.14),rgba(0,0,0,0));' +
            'border-bottom:1px solid rgba(255,255,255,.06);text-align:center;';
        hdr.innerHTML =
            '<div style="font-size:22px;margin-bottom:8px;">⚠️</div>' +
            '<div style="font-size:13px;font-weight:700;color:#fff;margin-bottom:4px;">Key em uso em outro PC</div>' +
            '<div style="font-size:11px;color:rgba(255,255,255,.4);">Deseja transferir a licença para este PC?</div>';

        // Body
        var body = document.createElement('div');
        body.style.cssText = 'padding:20px 22px;';

        var info = document.createElement('div');
        info.style.cssText = 'background:rgba(255,140,0,.07);border:1px solid rgba(255,140,0,.18);' +
            'border-radius:8px;padding:12px 14px;margin-bottom:18px;' +
            'font-size:11px;color:rgba(255,255,255,.55);line-height:1.7;';
        info.innerHTML =
            '<strong style="color:rgba(255,180,0,.9);">O que vai acontecer:</strong><br>' +
            '• Esta máquina ficará <strong style="color:#fff;">ativa</strong> com a key <code style="color:rgba(255,180,0,.8);font-size:10px;">' + key.substring(0,4) + '-****-****-****</code><br>' +
            '• O PC anterior <strong style="color:#fff;">perderá o acesso</strong> na próxima verificação<br>' +
            '• A transferência é <strong style="color:#fff;">imediata</strong> e não pode ser desfeita';

        var msg = document.createElement('div');
        msg.style.cssText = 'font-size:11px;min-height:16px;margin-bottom:14px;' +
            'text-align:center;display:none;';

        var btnRow = document.createElement('div');
        btnRow.style.cssText = 'display:flex;gap:10px;';

        var cancelBtn = document.createElement('button');
        cancelBtn.textContent = 'Cancelar';
        cancelBtn.style.cssText = 'flex:1;padding:11px;border:1px solid rgba(255,255,255,.12);' +
            'border-radius:8px;background:transparent;color:rgba(255,255,255,.55);' +
            'font-size:13px;font-weight:600;cursor:pointer;transition:all .15s;';
        cancelBtn.onmouseover = function() {
            this.style.background = 'rgba(255,255,255,.06)';
            this.style.color = '#fff';
        };
        cancelBtn.onmouseout = function() {
            this.style.background = 'transparent';
            this.style.color = 'rgba(255,255,255,.55)';
        };
        cancelBtn.onclick = function() { o.remove(); };

        var confirmBtn = document.createElement('button');
        confirmBtn.textContent = 'Sim, transferir';
        confirmBtn.style.cssText = 'flex:1;padding:11px;border:none;border-radius:8px;' +
            'background:linear-gradient(135deg,#d47800,#8c4e00);color:#fff;' +
            'font-size:13px;font-weight:700;cursor:pointer;transition:opacity .15s;';
        confirmBtn.onmouseover = function() { this.style.opacity = '.85'; };
        confirmBtn.onmouseout  = function() { this.style.opacity = '1'; };

        var transferring = false;

        confirmBtn.onclick = function() {
            if (transferring) return;
            transferring = true;
            confirmBtn.textContent = 'Transferindo...';
            confirmBtn.style.opacity = '.6';
            confirmBtn.style.cursor = 'not-allowed';
            cancelBtn.disabled = true;
            cancelBtn.style.opacity = '.3';
            msg.style.display = 'none';

            call('TransferLicense', { key: key }).then(function(res) {
                var d = parseJson(res);
                if (d && d.success) {
                    msg.style.color = 'rgba(60,220,100,.9)';
                    msg.textContent = '✓ ' + (d.message || 'Licença transferida com sucesso!');
                    msg.style.display = 'block';
                    confirmBtn.textContent = '✓ Feito!';
                    confirmBtn.style.background = 'linear-gradient(135deg,#1a8c3a,#0f5c26)';
                    confirmBtn.style.opacity = '1';
                    // Fecha o modal de transferência e a tela de ativação
                    setTimeout(function() {
                        o.remove();
                        if (activationOverlay) activationOverlay.remove();
                        if (onSuccess) onSuccess();
                    }, 2000);
                } else {
                    transferring = false;
                    confirmBtn.textContent = 'Sim, transferir';
                    confirmBtn.style.opacity = '1';
                    confirmBtn.style.cursor = 'pointer';
                    cancelBtn.disabled = false;
                    cancelBtn.style.opacity = '1';
                    msg.style.color = 'rgba(255,80,80,.9)';
                    msg.textContent = (d && d.message) ? d.message : 'Erro ao transferir. Tente novamente.';
                    msg.style.display = 'block';
                }
            }).catch(function() {
                transferring = false;
                confirmBtn.textContent = 'Sim, transferir';
                confirmBtn.style.opacity = '1';
                confirmBtn.style.cursor = 'pointer';
                cancelBtn.disabled = false;
                cancelBtn.style.opacity = '1';
                msg.style.color = 'rgba(255,80,80,.9)';
                msg.textContent = 'Sem conexão. Verifique sua internet e tente novamente.';
                msg.style.display = 'block';
            });
        };

        btnRow.appendChild(cancelBtn);
        btnRow.appendChild(confirmBtn);

        body.appendChild(info);
        body.appendChild(msg);
        body.appendChild(btnRow);
        box.appendChild(hdr);
        box.appendChild(body);
        o.appendChild(box);
        document.body.appendChild(o);
    }

    // ── Tela de HWID roubado ──────────────────────────────────────────────────
    // Aparece no PC 1 quando detecta que a licença foi transferida para outro PC.
    // Dá 60 segundos para reativar. Se não reativar, auto-destrói.
    function showHwidStolenScreen(onSuccess) {
        injectStyles();
        var old = document.getElementById('gf-stolen-overlay');
        if (old) old.remove();

        var TIMER_SECONDS = 60;
        var timerInterval = null;
        var remaining = TIMER_SECONDS;
        var destructTriggered = false;

        var o = document.createElement('div');
        o.id = 'gf-stolen-overlay';
        o.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;' +
            'background:rgba(0,0,0,0.95);z-index:99999;display:flex;' +
            'align-items:center;justify-content:center;';

        var box = document.createElement('div');
        box.style.cssText = 'background:#111;border:1px solid rgba(220,0,0,.4);' +
            'border-radius:14px;width:380px;overflow:hidden;' +
            'box-shadow:0 0 60px rgba(220,0,0,.2);';

        // Header
        var hdr = document.createElement('div');
        hdr.style.cssText = 'padding:22px 22px 18px;' +
            'background:linear-gradient(135deg,rgba(220,0,0,.18),rgba(0,0,0,0));' +
            'border-bottom:1px solid rgba(255,255,255,.06);text-align:center;';
        hdr.innerHTML =
            '<div style="font-size:28px;margin-bottom:10px;">🔐</div>' +
            '<div style="font-size:14px;font-weight:800;color:#ff4444;margin-bottom:6px;letter-spacing:.5px;">' +
                'Ativação duplicada detectada' +
            '</div>' +
            '<div style="font-size:11px;color:rgba(255,255,255,.4);line-height:1.5;">' +
                'Esta licença foi ativada em outro PC.<br>Reative aqui para recuperar o acesso.' +
            '</div>';

        // Body
        var body = document.createElement('div');
        body.style.cssText = 'padding:20px 22px 22px;';

        // Timer bar + texto
        var timerWrap = document.createElement('div');
        timerWrap.style.cssText = 'margin-bottom:18px;';

        var timerLabel = document.createElement('div');
        timerLabel.style.cssText = 'font-size:11px;color:rgba(255,255,255,.4);' +
            'text-align:center;margin-bottom:8px;';
        timerLabel.textContent = 'Plugin será removido em ' + remaining + ' segundos';

        var barBg = document.createElement('div');
        barBg.style.cssText = 'height:4px;background:rgba(255,255,255,.08);' +
            'border-radius:2px;overflow:hidden;';

        var bar = document.createElement('div');
        bar.style.cssText = 'height:100%;width:100%;background:#dc0000;' +
            'border-radius:2px;transition:width 1s linear,background .5s;';

        barBg.appendChild(bar);
        timerWrap.appendChild(timerLabel);
        timerWrap.appendChild(barBg);

        // Input
        var inputWrap = document.createElement('div');
        inputWrap.style.cssText = 'margin-bottom:14px;';

        var inp = document.createElement('input');
        inp.type = 'text';
        inp.placeholder = 'PRZV-XXXX-XXXX-XXXX (sua key)';
        inp.style.cssText = 'width:100%;box-sizing:border-box;' +
            'background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);' +
            'border-radius:8px;padding:11px 14px;color:#fff;font-size:13px;' +
            'font-family:monospace;letter-spacing:1px;outline:none;' +
            'text-transform:uppercase;transition:border .15s;';
        inp.onfocus = function() { this.style.borderColor = 'rgba(220,0,0,.5)'; };
        inp.onblur  = function() { this.style.borderColor = 'rgba(255,255,255,.1)'; };
        inp.oninput = function() { this.value = this.value.toUpperCase(); };
        inputWrap.appendChild(inp);

        var msg = document.createElement('div');
        msg.style.cssText = 'font-size:11px;min-height:16px;margin-bottom:14px;' +
            'text-align:center;display:none;';

        var btn = document.createElement('button');
        btn.textContent = 'Reativar agora';
        btn.style.cssText = 'width:100%;padding:12px;border:none;border-radius:8px;' +
            'background:linear-gradient(135deg,#dc0000,#a00000);color:#fff;' +
            'font-size:13px;font-weight:700;cursor:pointer;letter-spacing:1px;' +
            'transition:opacity .15s;';
        btn.onmouseover = function() { if (!btn.disabled) this.style.opacity = '.85'; };
        btn.onmouseout  = function() { if (!btn.disabled) this.style.opacity = '1'; };

        // Timer
        function triggerDestruct() {
            if (destructTriggered) return;
            destructTriggered = true;
            clearInterval(timerInterval);

            inp.disabled = true;
            btn.disabled = true;
            btn.style.opacity = '.3';
            btn.style.cursor = 'not-allowed';
            btn.textContent = 'Removendo plugin...';
            btn.style.background = 'linear-gradient(135deg,#333,#111)';
            timerLabel.style.color = 'rgba(255,80,80,.8)';
            timerLabel.textContent = 'Tempo esgotado. Removendo plugin...';
            bar.style.width = '0%';
            bar.style.background = '#333';
            msg.style.display = 'none';

            call('SelfDestruct').catch(function() {});
        }

        timerInterval = setInterval(function() {
            remaining--;
            var pct = (remaining / TIMER_SECONDS * 100) + '%';
            bar.style.width = pct;

            // Muda cor conforme o tempo diminui
            if (remaining <= 15) {
                bar.style.background = '#ff2200';
                timerLabel.style.color = 'rgba(255,80,80,.85)';
            } else if (remaining <= 30) {
                bar.style.background = '#e05500';
            }

            timerLabel.textContent = 'Plugin será removido em ' + remaining + ' segundo' + (remaining !== 1 ? 's' : '');

            if (remaining <= 0) triggerDestruct();
        }, 1000);

        var activating = false;
        btn.onclick = function() {
            if (activating || destructTriggered) return;
            var key = inp.value.trim();
            if (!key) {
                msg.style.color = 'rgba(255,80,80,.9)';
                msg.textContent = 'Digite sua key para reativar.';
                msg.style.display = 'block';
                return;
            }

            activating = true;
            clearInterval(timerInterval); // pausa o timer durante a request
            btn.textContent = 'Verificando...';
            btn.style.opacity = '.6';
            btn.style.cursor = 'not-allowed';
            msg.style.display = 'none';
            timerLabel.textContent = 'Verificando...';

            call('Activate', { key: key }).then(function(res) {
                var d = parseJson(res);
                if (d && d.success) {
                    // Reativado com sucesso
                    msg.style.color = 'rgba(60,220,100,.9)';
                    msg.textContent = '✓ ' + (d.message || 'Reativado com sucesso!');
                    msg.style.display = 'block';
                    btn.textContent = '✓ Ativado!';
                    btn.style.background = 'linear-gradient(135deg,#1a8c3a,#0f5c26)';
                    btn.style.opacity = '1';
                    bar.style.width = '100%';
                    bar.style.background = '#1a8c3a';
                    timerLabel.style.color = 'rgba(60,220,100,.7)';
                    timerLabel.textContent = 'Licença reativada neste PC!';
                    setTimeout(function() {
                        o.remove();
                        if (onSuccess) onSuccess();
                    }, 1800);
                } else if (d && d.error === 'hwid_mismatch') {
                    // Key em uso em OUTRO PC além do PC2 — oferece transferência
                    activating = false;
                    showTransferConfirm(key, o, onSuccess);
                } else {
                    // Erro — retoma o timer
                    activating = false;
                    btn.textContent = 'Reativar agora';
                    btn.style.opacity = '1';
                    btn.style.cursor = 'pointer';
                    msg.style.color = 'rgba(255,80,80,.9)';
                    msg.textContent = (d && d.message) ? d.message : 'Key inválida. Tente novamente.';
                    msg.style.display = 'block';
                    inp.style.borderColor = 'rgba(220,0,0,.6)';
                    // Retoma o timer de onde parou
                    timerInterval = setInterval(function() {
                        remaining--;
                        bar.style.width = (remaining / TIMER_SECONDS * 100) + '%';
                        timerLabel.textContent = 'Plugin será removido em ' + remaining + ' segundo' + (remaining !== 1 ? 's' : '');
                        if (remaining <= 15) {
                            bar.style.background = '#ff2200';
                            timerLabel.style.color = 'rgba(255,80,80,.85)';
                        }
                        if (remaining <= 0) triggerDestruct();
                    }, 1000);
                }
            }).catch(function() {
                activating = false;
                btn.textContent = 'Reativar agora';
                btn.style.opacity = '1';
                btn.style.cursor = 'pointer';
                msg.style.color = 'rgba(255,80,80,.9)';
                msg.textContent = 'Sem conexão. Verifique sua internet.';
                msg.style.display = 'block';
                // Retoma timer
                timerInterval = setInterval(function() {
                    remaining--;
                    bar.style.width = (remaining / TIMER_SECONDS * 100) + '%';
                    timerLabel.textContent = 'Plugin será removido em ' + remaining + ' segundo' + (remaining !== 1 ? 's' : '');
                    if (remaining <= 0) triggerDestruct();
                }, 1000);
            });
        };

        inp.onkeydown = function(e) { if (e.key === 'Enter') btn.click(); };

        body.appendChild(timerWrap);
        body.appendChild(inputWrap);
        body.appendChild(msg);
        body.appendChild(btn);
        box.appendChild(hdr);
        box.appendChild(body);
        o.appendChild(box);
        document.body.appendChild(o);
        setTimeout(function() { inp.focus(); }, 100);
    }

    function showChangelog() {
        call('GetPendingUpdate').then(function(res) {
            var d = parseJson(res);
            if (!d || !d.has_update) return;
            var o = overlay();
            var box = div('background:#0d0d0d;border-radius:18px;overflow:hidden;box-shadow:0 32px 90px rgba(0,0,0,.92);max-width:560px;width:92%;max-height:80vh;display:flex;flex-direction:column;animation:gf-up .2s cubic-bezier(.16,1,.3,1);');
            var hdr = div('padding:18px 20px 12px;border-bottom:1px solid rgba(255,255,255,.06);display:flex;align-items:center;justify-content:space-between;');
            var hTtl = el('span');
            hTtl.style.cssText = 'font-size:14px;font-weight:900;letter-spacing:.5px;color:#fff;';
            hTtl.textContent = 'Atualizado para ' + (d.version || '');
            var hClose = xBtn(function() { document.body.removeChild(o); });
            hdr.appendChild(hTtl); hdr.appendChild(hClose);

            var body = div('padding:16px 20px 20px;overflow-y:auto;flex:1;font-size:12px;color:rgba(255,255,255,.7);line-height:1.7;white-space:pre-wrap;');
            body.textContent = d.changelog || 'Nenhum detalhe disponível para esta versão.';

            var btn = mkBtn('Fechar', true);
            btn.style.margin = '0 20px 18px';
            btn.onclick = function() { document.body.removeChild(o); };

            box.appendChild(hdr); box.appendChild(body); box.appendChild(btn);
            o.appendChild(box); document.body.appendChild(o);
        }).catch(function() {});
    }

    function showTrialScreen(cb) {
        call('GetTrialStatus').then(function(res) {
            var d = parseJson(res);
            var remaining = d && d.remaining_seconds ? d.remaining_seconds : 259200;
            var expires_at = d && d.expires_at ? d.expires_at : '';
            var o = overlay();
            var box = div('background:#0d0d0d;border-radius:18px;overflow:hidden;box-shadow:0 32px 90px rgba(0,0,0,.92);max-width:480px;width:92%;animation:gf-up .2s cubic-bezier(.16,1,.3,1);');
            var pad = 'padding:28px 24px 24px';
            var body = div(pad + ';text-align:center;');
            var icon = el('div');
            icon.textContent = '🎮';
            icon.style.cssText = 'font-size:48px;margin-bottom:8px;';
            var ttl = el('div');
            ttl.style.cssText = 'font-size:18px;font-weight:900;color:#fff;margin-bottom:6px;';
            ttl.textContent = 'Modo Teste Grátis';
            var sub = el('div');
            sub.style.cssText = 'font-size:12px;color:rgba(255,255,255,.5);margin-bottom:18px;';
            sub.textContent = 'Você está avaliando o Parzival Retro Steam gratuitamente.';
            var timer = el('div');
            timer.style.cssText = 'font-size:13px;color:#ffb347;font-weight:700;margin-bottom:20px;';
            function updateTimer() {
                if (remaining <= 0) { timer.textContent = 'Tempo esgotado! Reinicie o plugin.'; return; }
                var h = Math.floor(remaining / 3600);
                var m = Math.floor((remaining % 3600) / 60);
                var s = remaining % 60;
                timer.textContent = (h > 0 ? h + 'h ' : '') + m + 'm ' + s + 's restantes';
                remaining--;
            }
            updateTimer();
            setInterval(updateTimer, 1000);
            var inp = el('input');
            inp.type = 'text';
            inp.placeholder = 'Cole sua key aqui...';
            inp.style.cssText = 'width:100%;padding:10px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:#fff;font-size:13px;outline:none;box-sizing:border-box;margin-bottom:10px;';
            var err = el('div');
            err.style.cssText = 'font-size:11px;color:#e74c3c;margin-bottom:10px;display:none;';
            var btn = mkBtn('Ativar Licença', true);
            btn.style.margin = '0';
            btn.onclick = function() {
                var key = inp.value.trim();
                if (!key) { err.textContent = 'Digite sua key.'; err.style.display = ''; return; }
                err.style.display = 'none';
                btn.textContent = 'Ativando...';
                btn.disabled = true;
                call('ConvertTrial', { key: key }).then(function(r) {
                    var rd = parseJson(r);
                    if (rd && rd.success) {
                        document.body.removeChild(o);
                        if (cb) cb();
                    } else {
                        err.textContent = rd && rd.message ? rd.message : 'Erro ao ativar.';
                        err.style.display = '';
                        btn.textContent = 'Ativar Licença';
                        btn.disabled = false;
                    }
                }).catch(function() {
                    err.textContent = 'Sem conexão com o servidor.';
                    err.style.display = '';
                    btn.textContent = 'Ativar Licença';
                    btn.disabled = false;
                });
            };
            body.appendChild(icon); body.appendChild(ttl); body.appendChild(sub);
            body.appendChild(timer); body.appendChild(inp); body.appendChild(err); body.appendChild(btn);
            box.appendChild(body); o.appendChild(box); document.body.appendChild(o);
        }).catch(function() { if (cb) cb(); });
    }

    function showTrialExpiredScreen() {
        var o = overlay();
        var box = div('background:#0d0d0d;border-radius:18px;overflow:hidden;box-shadow:0 32px 90px rgba(0,0,0,.92);max-width:420px;width:92%;animation:gf-up .2s cubic-bezier(.16,1,.3,1);');
        var body = div('padding:32px 24px;text-align:center;');
        var icon = el('div');
        icon.textContent = '⏰';
        icon.style.cssText = 'font-size:48px;margin-bottom:8px;';
        var ttl = el('div');
        ttl.style.cssText = 'font-size:18px;font-weight:900;color:#fff;margin-bottom:6px;';
        ttl.textContent = 'Teste Grátis Expirado';
        var sub = el('div');
        sub.style.cssText = 'font-size:12px;color:rgba(255,255,255,.5);margin-bottom:20px;';
        sub.textContent = 'Seu período de avaliação acabou. Adquira uma licença para continuar usando.';
        var inp = el('input');
        inp.type = 'text';
        inp.placeholder = 'Cole sua key aqui...';
        inp.style.cssText = 'width:100%;padding:10px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:#fff;font-size:13px;outline:none;box-sizing:border-box;margin-bottom:10px;';
        var err = el('div');
        err.style.cssText = 'font-size:11px;color:#e74c3c;margin-bottom:10px;display:none;';
        var btn = mkBtn('Ativar Licença', true);
        btn.onclick = function() {
            var key = inp.value.trim();
            if (!key) { err.textContent = 'Digite sua key.'; err.style.display = ''; return; }
            err.style.display = 'none';
            btn.textContent = 'Ativando...';
            btn.disabled = true;
            call('Activate', { key: key }).then(function(r) {
                var rd = parseJson(r);
                if (rd && rd.success) {
                    document.body.removeChild(o);
                    _startPlugin();
                } else {
                    err.textContent = rd && rd.message ? rd.message : 'Erro ao ativar.';
                    err.style.display = '';
                    btn.textContent = 'Ativar Licença';
                    btn.disabled = false;
                }
            }).catch(function() {
                err.textContent = 'Sem conexão com o servidor.';
                err.style.display = '';
                btn.textContent = 'Ativar Licença';
                btn.disabled = false;
            });
        };
        body.appendChild(icon); body.appendChild(ttl); body.appendChild(sub);
        body.appendChild(inp); body.appendChild(err); body.appendChild(btn);
        box.appendChild(body); o.appendChild(box); document.body.appendChild(o);
    }

    function _startPlugin() {
        injectButton();
        startUpdatePolling();
        showChangelog();
        var obs = new MutationObserver(function () { injectButton(); });
        obs.observe(document.body, { childList: true, subtree: true });
        setTimeout(injectButton, 6000);
    }

    function init() {
        injectStyles();

        // Tenta verificar auth até 20x com delay crescente
        // (backend pode demorar a ficar pronto após o JS injetar)
        var attempts = 0;
        var maxAttempts = 20;

        function checkAuth() {
            attempts++;
            call('GetStartupStatus').then(function(res) {
                var d = parseJson(res);

                // Backend ainda inicializando — sempre tenta de novo, sem limite fixo
                // (nunca cai no fallback só porque o backend demorou)
                if (!d || !d.status || d.status === 'pending') {
                    setTimeout(checkAuth, 800);
                    return;
                }

                if (d.status === 'ok') {
                    _startPlugin();
                } else if (d.status === 'hwid_stolen') {
                    showHwidStolenScreen(function() { _startPlugin(); });
                } else if (d.status === 'trial') {
                    showTrialScreen(function() { _startPlugin(); });
                } else if (d.status === 'trial_expired') {
                    showTrialExpiredScreen();
                } else {
                    // no_license: nunca ativado, ou hwid_stolen já limpou o auth local
                    showActivationScreen(function() { _startPlugin(); });
                }
            }).catch(function() {
                // Erro de conexão com o backend — tenta de novo sem limite
                setTimeout(checkAuth, 800);
            });
        }

        // Primeira tentativa após 1s (dá tempo ao backend iniciar)
        setTimeout(checkAuth, 1000);
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();

})();
