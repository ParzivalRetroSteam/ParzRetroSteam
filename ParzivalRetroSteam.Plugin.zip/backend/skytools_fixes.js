// ParzivalRetroSteam GitHub fix-source lookup helper for Windows Script Host.
(function () {
  var fso = new ActiveXObject("Scripting.FileSystemObject");
  // Fonte de fixes — apenas Sky
  var fixSources = [
    {
      releaseApiUrl: "https://api.github.com/repos/skyflarefox/fix/releases/tags/fix",
      repoRawRoot:   "https://github.com/skyflarefox/fix/releases/download/fix/",
      label: "Sky"
    }
  ];
  // Retrocompatibilidade
  var repoRawRoot   = fixSources[0].repoRawRoot;
  var releaseApiUrl = fixSources[0].releaseApiUrl;

  function arg(index) {
    return WScript.Arguments.length > index ? String(WScript.Arguments.Item(index)) : "";
  }

  function ensureDir(path) {
    if (!path || fso.FolderExists(path)) return;
    var parent = fso.GetParentFolderName(path);
    if (parent && !fso.FolderExists(parent)) ensureDir(parent);
    if (!fso.FolderExists(path)) fso.CreateFolder(path);
  }

  function writeText(path, text) {
    ensureDir(fso.GetParentFolderName(path));
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = "utf-8";
    stream.Open();
    stream.WriteText(String(text || ""));
    stream.SaveToFile(path, 2);
    stream.Close();
  }

  function jsonEscape(value) {
    return String(value == null ? "" : value)
      .replace(/\\/g, "\\\\")
      .replace(/"/g, "\\\"")
      .replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\t/g, "\\t");
  }

  function cleanName(value, appid) {
    var text = String(value || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
    if (!text || /^appid\s+\d+$/i.test(text) || text === String(appid || "")) {
      return "AppID " + String(appid || "");
    }
    return text;
  }

  function typeLabel(kind) {
    return kind === "online" ? "Online" : "Gen\u00e9rica";
  }

  function formatSize(bytes) {
    var value = Number(bytes || 0);
    if (!isFinite(value) || value <= 0) return "";
    var mb = value / 1024 / 1024;
    return mb.toFixed(1).replace(".", ",") + " MB";
  }

  function requestJson(url) {
    var separator = url.indexOf("?") >= 0 ? "&" : "?";
    var http = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
    http.setTimeouts(5000, 5000, 15000, 15000);
    http.open("GET", url + separator + "skytools=" + new Date().getTime(), false);
    http.setRequestHeader("User-Agent", "ParzivalRetroSteamPlugin/1.0");
    http.setRequestHeader("Accept", "application/vnd.github+json");
    http.setRequestHeader("Cache-Control", "no-cache");
    http.setRequestHeader("Pragma", "no-cache");
    http.send();
    if (http.status < 200 || http.status >= 300) {
      throw new Error("GitHub respondeu HTTP " + http.status + " ao atualizar as correções.");
    }
    return eval("(" + String(http.responseText || "{}") + ")");
  }

  function headArchive(url) {
    var http = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
    http.setTimeouts(5000, 5000, 12000, 12000);
    http.open("HEAD", url + "?skytools=" + new Date().getTime(), false);
    http.setRequestHeader("User-Agent", "ParzivalRetroSteamPlugin/1.0");
    http.setRequestHeader("Accept", "application/zip,*/*");
    http.setRequestHeader("Cache-Control", "no-cache");
    http.setRequestHeader("Pragma", "no-cache");
    http.send();
    if (http.status < 200 || http.status >= 300) return null;
    var length = http.getResponseHeader("Content-Length") || "";
    return { sizeBytes: Number(length) || 0 };
  }

  function sourceJson(item) {
    return "{"
      + "\"name\":\"" + jsonEscape(item.name) + "\","
      + "\"displayName\":\"" + jsonEscape(item.displayName) + "\","
      + "\"type\":\"" + jsonEscape(item.type) + "\","
      + "\"kind\":\"" + jsonEscape(item.kind) + "\","
      + "\"provider\":\"" + jsonEscape(item.provider || "Sky") + "\","
      + "\"downloadUrl\":\"" + jsonEscape(item.downloadUrl) + "\","
      + "\"fileName\":\"" + jsonEscape(item.fileName) + "\","
      + "\"size\":\"" + jsonEscape(item.size) + "\","
      + "\"sizeBytes\":" + String(item.sizeBytes || 0) + ","
      + "\"action\":\"apply\""
      + "}";
  }

  function requestJsonGeneric(url) {
    var separator = url.indexOf("?") >= 0 ? "&" : "?";
    var http = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
    http.setTimeouts(5000, 5000, 15000, 15000);
    http.open("GET", url + separator + "skytools=" + new Date().getTime(), false);
    http.setRequestHeader("User-Agent", "ParzivalRetroSteamPlugin/1.0");
    http.setRequestHeader("Accept", "application/json");
    http.setRequestHeader("Cache-Control", "no-cache");
    http.setRequestHeader("Pragma", "no-cache");
    http.send();
    if (http.status < 200 || http.status >= 300) {
      throw new Error("Servidor respondeu HTTP " + http.status);
    }
    return eval("(" + String(http.responseText || "{}") + ")");
  }

  // Fonte "Voices": release fixa v1.2, um zip por appid (sem sufixo online/generic).
  var VOICESFIX_BASE = "https://github.com/voicesfix/fix/releases/download/v1.2/";

  function checkVoicesFix(appid) {
    var url = VOICESFIX_BASE + String(appid) + ".zip";
    try {
      var archive = headArchive(url);
      if (!archive) return null;
      return { url: url, fileName: String(appid) + ".zip", sizeBytes: archive.sizeBytes };
    } catch (_) {
      return null;
    }
  }

  // Fonte "VPS": indice JSON com os appids disponiveis, baixado uma vez por
  // execucao do helper e reutilizado nas checagens de catalogo.
  var VPS_INDEX_URL = "https://parzivalalicenses.dnsfollowme.uk/api/v1/fixes-index";
  var VPS_FIX_BASE = "https://parzivalalicenses.dnsfollowme.uk/api/v1/fixes/";
  var vpsIndexCache = null;
  var vpsIndexTried = false;

  function loadVpsIndex() {
    if (vpsIndexTried) return vpsIndexCache;
    vpsIndexTried = true;
    try {
      vpsIndexCache = requestJsonGeneric(VPS_INDEX_URL);
    } catch (_) {
      vpsIndexCache = null;
    }
    return vpsIndexCache;
  }

  function checkVpsFix(appid) {
    var idx = loadVpsIndex();
    if (!idx) return null;
    var entry = idx[String(appid)];
    if (!entry) return null;
    var fileName = (entry && entry.file) ? String(entry.file) : (String(appid) + ".zip");
    return { url: VPS_FIX_BASE + String(appid), fileName: fileName, sizeBytes: 0 };
  }

  function findSkyFixes(appid, gameName, requestedKind) {
    var kinds = requestedKind === "online" || requestedKind === "generic"
      ? [requestedKind]
      : ["online", "generic"];
    var name = cleanName(gameName, appid);
    var sources = [];

    // Ordem de prioridade pedida: Voices -> VPS -> Sky (skyfoxfix).
    try {
      var voices = checkVoicesFix(appid);
      if (voices) {
        var vLabel = typeLabel("generic");
        var vSize = formatSize(voices.sizeBytes);
        sources.push({
          name: name,
          displayName: name + " - " + vLabel + (vSize ? " - " + vSize : "") + " (Voices)",
          type: vLabel,
          kind: "generic",
          provider: "Voices",
          downloadUrl: voices.url,
          fileName: voices.fileName,
          size: vSize,
          sizeBytes: voices.sizeBytes,
          action: "apply"
        });
      }
    } catch (_) {}

    try {
      var vps = checkVpsFix(appid);
      if (vps) {
        var pLabel = typeLabel("generic");
        sources.push({
          name: name,
          displayName: name + " - " + pLabel + " (VPS)",
          type: pLabel,
          kind: "generic",
          provider: "VPS",
          downloadUrl: vps.url,
          fileName: vps.fileName,
          size: "",
          sizeBytes: 0,
          action: "apply"
        });
      }
    } catch (_) {}

    // Tenta todas as fontes de fix "Sky" em ordem
    for (var s = 0; s < fixSources.length; s += 1) {
      var src = fixSources[s];
      for (var i = 0; i < kinds.length; i += 1) {
        var kind = kinds[i];
        var fileName = String(appid) + "_" + kind + ".zip";
        var url = src.repoRawRoot + fileName;
        try {
          var archive = headArchive(url);
          if (!archive) continue;
          var label = typeLabel(kind);
          var size = formatSize(archive.sizeBytes);
          // Evitar duplicatas (mesmo appid+kind já encontrado)
          var duplicate = false;
          for (var d = 0; d < sources.length; d += 1) {
            if (sources[d].kind === kind && sources[d].provider === src.label) { duplicate = true; break; }
          }
          if (duplicate) continue;
          sources.push({
            name: name,
            displayName: name + " - " + label + (size ? " - " + size : "") + " (" + src.label + ")",
            type: label,
            kind: kind,
            provider: src.label,
            downloadUrl: url,
            fileName: fileName,
            size: size,
            sizeBytes: archive.sizeBytes,
            action: "apply"
          });
        } catch (_) {}
      }
    }
    return sources;
  }

  function catalogAssetJson(asset) {
    return "{"
      + "\"fileName\":\"" + jsonEscape(asset.fileName) + "\","
      + "\"kind\":\"" + jsonEscape(asset.kind) + "\","
      + "\"downloadUrl\":\"" + jsonEscape(asset.downloadUrl) + "\","
      + "\"sizeBytes\":" + String(asset.sizeBytes || 0) + ","
      + "\"size\":\"" + jsonEscape(formatSize(asset.sizeBytes)) + "\""
      + "}";
  }

  function catalogGameJson(game) {
    var assets = [];
    for (var i = 0; i < game.assets.length; i += 1) {
      assets.push(catalogAssetJson(game.assets[i]));
    }
    return "{"
      + "\"appId\":\"" + jsonEscape(game.appId) + "\","
      + "\"hasAvailableFix\":true,"
      + "\"assets\":[" + assets.join(",") + "]"
      + "}";
  }

  function loadFixCatalog() {
    var byAppId = {};
    var totalAssets = 0;
    var lastTag = "fix";
    var lastUpdatedAt = "";

    // Itera em todas as fontes e mescla os catalogs
    for (var s = 0; s < fixSources.length; s += 1) {
      var src = fixSources[s];
      var release;
      try {
        release = requestJson(src.releaseApiUrl);
      } catch (_) {
        continue;
      }
      if (!release) continue;
      if (s === 0) {
        lastTag = release.tag_name || "fix";
        lastUpdatedAt = release.updated_at || "";
      }
      var releaseAssets = release.assets instanceof Array ? release.assets : [];
      for (var i = 0; i < releaseAssets.length; i += 1) {
        var asset = releaseAssets[i] || {};
        var fileName = String(asset.name || "");
        var match = /^(\d+)_(online|generic)\.(zip|rar|7z)$/i.exec(fileName);
        if (!match) continue;
        var appId = match[1];
        var kind = String(match[2] || "").toLowerCase();
        var key = appId + "_" + kind;
        // Não sobrescreve se já tem (fonte primária tem prioridade)
        if (byAppId[key]) continue;
        if (!byAppId[appId + "_entry"]) byAppId[appId + "_entry"] = { appId: appId, assets: [] };
        byAppId[appId + "_entry"].assets.push({
          fileName: fileName,
          kind: kind,
          downloadUrl: String(asset.browser_download_url || (src.repoRawRoot + fileName)),
          sizeBytes: Number(asset.size || 0) || 0
        });
        byAppId[key] = true;
        totalAssets += 1;
      }
    }

    var appIds = [];
    for (var id in byAppId) {
      if (byAppId.hasOwnProperty(id) && id.indexOf("_entry") >= 0) {
        appIds.push(id.replace("_entry", ""));
      }
    }
    appIds.sort(function (left, right) { return Number(left) - Number(right); });

    var games = [];
    var availableIds = [];
    for (var index = 0; index < appIds.length; index += 1) {
      var entryId = appIds[index];
      var entry = byAppId[entryId + "_entry"];
      if (!entry) continue;
      games.push(catalogGameJson(entry));
      availableIds.push("\"" + jsonEscape(entryId) + "\"");
    }

    return "{"
      + "\"success\":true,"
      + "\"data\":{"
      + "\"tag\":\"" + jsonEscape(lastTag) + "\"," 
      + "\"releaseUpdatedAt\":\"" + jsonEscape(lastUpdatedAt) + "\"," 
      + "\"fetchedAt\":" + String(new Date().getTime()) + ","
      + "\"fixAssetCount\":" + String(totalAssets) + ","
      + "\"availableAppIds\":[" + availableIds.join(",") + "],"
      + "\"games\":[" + games.join(",") + "]"
      + "},"
      + "\"error\":\"\"" 
      + "}";
  }



  try {
    var resultPath = arg(0);
    var appid = arg(1);
    var gameName = arg(2);
    var kind = String(arg(3) || "").toLowerCase();
    if (kind === "__catalog__") {
      writeText(resultPath, loadFixCatalog());
      return;
    }
    var sources = findSkyFixes(appid, gameName, kind);
    var parts = [];
    for (var i = 0; i < sources.length; i += 1) parts.push(sourceJson(sources[i]));
    writeText(resultPath, "{\"success\":true,\"data\":{\"sources\":[" + parts.join(",") + "]},\"error\":\"\"}");
  } catch (error) {
    writeText(arg(0), "{\"success\":false,\"error\":\"" + jsonEscape(error && error.message ? error.message : String(error)) + "\"}");
  }
})();
